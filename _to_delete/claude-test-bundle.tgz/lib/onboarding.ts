import bcrypt from "bcryptjs";
import ExcelJS from "exceljs";
import { AttendanceStatus, ExamWorkflowStatus, InvoiceStatus, Prisma, type Role } from "@prisma/client";
import { randomUUID } from "node:crypto";
import { can, type AccessUser } from "./permissions";
import { prisma } from "./prisma";
import { normalizeMobile } from "./phone";
import { ensureAccessRoles, roleIdBySlug } from "./roles";
import { parseClassLabel, parseCsv, parsePathTags } from "./sheet";
import { readUpload } from "./uploads";
import { parseWeekdays } from "./schedule";
import { formatSubjectLabel } from "./subject-code";
import { examPlanWeight, parseExamPlan } from "./exams";
import { currentTenantOrg, runWithoutTenant } from "./tenant-context";
import { admissionFormFields, parentAdmissionContact, staffOnboardingFormFields, type AdmissionFormField } from "./admission-form";
import { configuredAdmissionFormJson, configuredFormJson } from "./admission-form-config";
import { assignStudentRollNumber } from "./student-rolls";
import { feePeriodAfter } from "./fees";

const ONBOARDING_STATE_ID = "school";
function onboardingStateId(orgId: string) {
  return `${ONBOARDING_STATE_ID}:${orgId}`;
}

export const IMPORT_KINDS = ["classes", "students", "teachers", "class_teachers", "attendance", "staff_attendance", "exam_marks", "opening_balances"] as const;
export type ImportKind = (typeof IMPORT_KINDS)[number];
type ImportRow = Record<string, string> & { _row: string };
type OnboardingDb = Prisma.TransactionClient;
type OnboardingSetupArea = "school" | "teaching" | "exams" | "money";
type OnboardingStepKey =
  | "school"
  | "sessions"
  | "classes"
  | "admission_form"
  | "students"
  | "student_id_document"
  | "student_admit_card_document"
  | "admission_confirmation_document"
  | "teachers"
  | "staff_id_document"
  | "salary_slip_document"
  | "working_days"
  | "holiday_calendar"
  | "attendance"
  | "staff_attendance"
  | "exam_plan"
  | "exam_history"
  | "exam_marks"
  | "report_card_document"
  | "exam_date_sheet_document"
  | "consolidated_report_document"
  | "class_teachers"
  | "collection_account"
  | "fee_invoice_document"
  | "payment_receipt_document"
  | "opening_balances"
  | "recurring_fees"
  | "review";
type OnboardingPlanState = { modules: string[]; manualSteps: string[]; configuredSteps: string[] };
type OnboardingTarget = { href: string; label: string };

const TEMPLATE_DETAILS: Record<ImportKind, { sheet: string; file: string; title: string }> = {
  classes: { sheet: "Classes", file: "anekio-classes.csv", title: "Classes and sections" },
  students: { sheet: "Students", file: "anekio-students.csv", title: "Students and parents" },
  teachers: { sheet: "Staff", file: "anekio-staff.csv", title: "Staff" },
  class_teachers: { sheet: "Class teachers", file: "anekio-class-teachers.csv", title: "Class teacher assignments" },
  attendance: { sheet: "Student attendance", file: "anekio-student-attendance.csv", title: "Student attendance history" },
  staff_attendance: { sheet: "Staff attendance", file: "anekio-staff-attendance.csv", title: "Staff attendance history" },
  exam_marks: { sheet: "Exam marks", file: "anekio-exam-marks.csv", title: "Exam marks history" },
  opening_balances: { sheet: "First time fees", file: "anekio-first-time-fees.csv", title: "First time fee import" },
};
const DEFAULT_ONBOARDING_MODULES = ["school", "teaching", "exams", "money"];
const ONBOARDING_STEP_KEYS = new Set<OnboardingStepKey>([
  "school",
  "sessions",
  "classes",
  "admission_form",
  "students",
  "student_id_document",
  "student_admit_card_document",
  "admission_confirmation_document",
  "teachers",
  "staff_id_document",
  "salary_slip_document",
  "working_days",
  "holiday_calendar",
  "attendance",
  "staff_attendance",
  "exam_plan",
  "exam_history",
  "exam_marks",
  "report_card_document",
  "exam_date_sheet_document",
  "consolidated_report_document",
  "class_teachers",
  "collection_account",
  "fee_invoice_document",
  "payment_receipt_document",
  "opening_balances",
  "recurring_fees",
  "review",
]);

function parsePlanState(value: string | null | undefined): OnboardingPlanState {
  try {
    const parsed = JSON.parse(value || "null") as unknown;
    if (Array.isArray(parsed)) return { modules: DEFAULT_ONBOARDING_MODULES, manualSteps: [], configuredSteps: [] };
    if (parsed && typeof parsed === "object") {
      const row = parsed as Partial<OnboardingPlanState>;
      return {
        modules: DEFAULT_ONBOARDING_MODULES,
        manualSteps: Array.isArray(row.manualSteps) ? row.manualSteps.map(String).filter((key) => ONBOARDING_STEP_KEYS.has(key as OnboardingStepKey)) : [],
        configuredSteps: Array.isArray(row.configuredSteps) ? row.configuredSteps.map(String).filter((key) => /^(working_days|sessions:[a-z0-9_-]+|exam_plan:[a-z0-9_-]+)$/.test(key)) : [],
      };
    }
  } catch {
    // Keep onboarding usable if an older or broken state value is present.
  }
  return { modules: DEFAULT_ONBOARDING_MODULES, manualSteps: [], configuredSteps: [] };
}

function serializePlanState(state: OnboardingPlanState) {
  return JSON.stringify({
    modules: DEFAULT_ONBOARDING_MODULES,
    manualSteps: [...new Set(state.manualSteps.filter((key) => ONBOARDING_STEP_KEYS.has(key as OnboardingStepKey)))],
    configuredSteps: [...new Set(state.configuredSteps)],
  });
}

function need(user: AccessUser) {
  if (!can(user, "onboarding.manage")) throw new Error("No access.");
}

function asKind(value: unknown): ImportKind {
  const kind = String(value || "") as ImportKind;
  if (!IMPORT_KINDS.includes(kind)) throw new Error("Choose a valid onboarding template.");
  return kind;
}

function normalizeHeader(value: unknown) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function dateText(value: Date) {
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function cellText(value: ExcelJS.CellValue): string {
  if (value == null) return "";
  if (value instanceof Date) return dateText(value);
  if (typeof value === "object") {
    if ("result" in value && value.result != null) return cellText(value.result as ExcelJS.CellValue);
    if ("richText" in value) return value.richText.map((part) => part.text).join("");
    if ("text" in value) return String(value.text || "");
  }
  return String(value).trim();
}

function validDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  return !Number.isNaN(new Date(`${value}T00:00:00`).getTime());
}

function currentMonthPeriod(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function admissionLookupKey(value: string) {
  return value.trim().toLowerCase();
}

function parseOpeningBacklogAmount(raw: string): { error: string } | { amount: number } {
  const text = raw.trim();
  if (!text) return { error: "backlog invoice amount is required." };
  if (!/^\d+$/.test(text)) return { error: "backlog invoice amount must be a whole number of rupees." };
  const amount = Number(text);
  if (!Number.isFinite(amount) || amount < 0) return { error: "backlog invoice amount must be zero or more." };
  return { amount };
}

async function publishedFeeDocumentTypes(orgId: string) {
  const rows = await prisma.documentTemplate.findMany({
    where: { orgId, status: "ACTIVE", type: { in: ["FEE_INVOICE", "PAYMENT_RECEIPT"] } },
    select: { type: true },
  });
  return new Set(rows.map((row) => row.type));
}

async function openingDocumentErrors(orgId: string) {
  const published = await publishedFeeDocumentTypes(orgId);
  const errors: string[] = [];
  if (!published.has("FEE_INVOICE")) errors.push("Publish the fee invoice template before importing opening balances.");
  if (!published.has("PAYMENT_RECEIPT")) errors.push("Publish the payment receipt template before importing opening balances.");
  return errors;
}

async function findStudentForOpening(db: OnboardingDb | typeof prisma, input: { studentId: string; admissionNo: string; orgId?: string | null }) {
  if (input.studentId) {
    return db.student.findUnique({ where: { id: input.studentId } });
  }
  const wanted = admissionLookupKey(input.admissionNo);
  if (!wanted) return null;
  const students = await db.student.findMany({
    where: { orgId: input.orgId ?? null },
    select: { id: true, admissionNo: true, classId: true },
  });
  const match = students.find((row) => admissionLookupKey(row.admissionNo) === wanted);
  if (!match) return null;
  return db.student.findUnique({ where: { id: match.id } });
}

function addDaysYmd(value: string, days: number) {
  const date = new Date(`${value}T00:00:00`);
  date.setDate(date.getDate() + days);
  return dateText(date);
}

function dateRange(from: string, to: string, limit = 430) {
  const dates: string[] = [];
  if (!validDate(from) || !validDate(to) || from > to) return dates;
  let date = from;
  while (date <= to && dates.length < limit) {
    dates.push(date);
    date = addDaysYmd(date, 1);
  }
  return dates;
}

function parseClass(value: string) {
  const parsed = parseClassLabel(value);
  if (parsed) return parsed;
  const parts = value.trim().split(/\s*[-/]\s*/);
  if (parts.length >= 2 && parts[0] && parts[1]) return { name: parts[0], section: parts.slice(1).join("-").toUpperCase() };
  return null;
}

function classFromImportRow(row: ImportRow, fields: AdmissionFormField[]) {
  const classText = configuredImportValue(row, fields, "classWanted", "Class");
  const section = sheetCell(row, "Section").toUpperCase();
  const parsed = parseClass(classText);
  if (parsed) return section ? { name: parsed.name, section } : parsed;
  if (classText && section) return parseClass(`${classText}-${section}`);
  return parsed;
}

function sheetCell(row: ImportRow, ...keys: string[]) {
  for (const key of keys) {
    const value = row[normalizeHeader(key)];
    if (value) return value.trim();
  }
  return "";
}

type CsvCell = string | number;
type StaffImportRole = Pick<Role, "id" | "name" | "slug" | "portal">;
type AttendanceImportMark = AttendanceStatus | "HOLIDAY";
type StaffAttendancePerson = { kind: "teacher" | "staff"; id: string; employeeId: string; name: string; role: string };
type ExamMarkColumn = { key: string; examId: string; classId: string; classLabel: string; maxMarks: number; label: string };
type OpeningBalanceStudent = Prisma.StudentGetPayload<{ include: { class: true } }>;
type OpeningBalanceInvoice = Prisma.FeeInvoiceGetPayload<{ include: { payments: true } }>;
const OPENING_BALANCE_HEADERS = ["Admission number", "Student name", "Class", "Backlog invoice amount", "Due date", "Example only"];

type ConfiguredImportForms = {
  admission: AdmissionFormField[];
  staff: AdmissionFormField[];
};

function visibleFields(fields: AdmissionFormField[]) {
  return fields.filter((field) => field.visible && field.type !== "file");
}

function uniqueHeaders(headers: string[]) {
  const used = new Map<string, number>();
  return headers.map((header) => {
    const clean = String(header || "").trim() || "Field";
    const key = normalizeHeader(clean);
    const count = used.get(key) || 0;
    used.set(key, count + 1);
    return count ? `${clean} ${count + 1}` : clean;
  });
}

function configuredImportValue(row: ImportRow, fields: AdmissionFormField[], id: string, ...fallbacks: string[]) {
  const field = fields.find((item) => item.id === id);
  return sheetCell(row, ...(field?.label ? [field.label] : []), ...fallbacks);
}

async function configuredImportForms(): Promise<ConfiguredImportForms> {
  const config = await prisma.schoolConfig.findUnique({
    where: { id: "school" },
    select: { admissionFormJson: true, staffOnboardingFormJson: true },
  });
  return {
    admission: admissionFormFields(await configuredAdmissionFormJson(config?.admissionFormJson)),
    staff: staffOnboardingFormFields(await configuredFormJson("staff", config?.staffOnboardingFormJson)),
  };
}

async function requireSchoolAdmissionFormSetup() {
  const config = await prisma.schoolConfig.findUnique({ where: { id: "school" }, select: { admissionFormJson: true } });
  if (!admissionFormFields(config?.admissionFormJson).length) {
    throw new Error("Save this school's admission form in School setup → Forms & Templates before downloading the student sheet.");
  }
}

type StudentColumnKey = "roll" | "studentName" | "dob" | "classWanted" | "interests" | "billingStartPeriod" | "guardianName" | "phone" | "email";

/**
 * Student sheet columns follow the school's admission form: a hidden field (e.g. Parent mobile) is left out,
 * and a shown one (e.g. Billing starts from) is included. Locked student fields keep the same required star.
 */
function studentBuiltinColumns(fields: AdmissionFormField[]) {
  const byId = new Map(fields.map((field) => [field.id, field]));
  const shown = (id: string) => !fields.length || Boolean(byId.get(id)?.visible);
  const label = (id: string, fallback: string) => byId.get(id)?.label || fallback;
  const required = (id: string) => !fields.length || Boolean(byId.get(id)?.visible && byId.get(id)?.required);
  const columns: { key: StudentColumnKey; header: string; required: boolean; reason: string }[] = [];
  if (shown("rollNumber")) {
    columns.push({
      key: "roll",
      header: label("rollNumber", "Roll no"),
      required: required("rollNumber"),
      reason: required("rollNumber")
        ? "Required. Use a whole number of 1 or more. Each roll must be unique in the class."
        : "Optional; blank assigns the next roll in that class.",
    });
  }
  columns.push(
    { key: "studentName", header: label("studentName", "Student name"), required: true, reason: "Required to create a student." },
  );
  if (shown("dateOfBirth")) {
    columns.push({
      key: "dob",
      header: label("dateOfBirth", "Date of birth"),
      required: required("dateOfBirth"),
      reason: required("dateOfBirth") ? "Required by this school's admission form; use YYYY-MM-DD." : "Optional; use YYYY-MM-DD.",
    });
  }
  columns.push({
    key: "classWanted",
    header: label("classWanted", "Class"),
    required: true,
    reason: "Required to place the student in a class, such as 1-A.",
  });
  if (shown("billingStartPeriod")) {
    columns.push({
      key: "billingStartPeriod",
      header: label("billingStartPeriod", "Billing starts from"),
      required: required("billingStartPeriod"),
      reason: "Month the first fee is billed, as YYYY-MM (e.g. 2026-04).",
    });
  }
  if (shown("guardianName")) {
    columns.push({
      key: "guardianName",
      header: label("guardianName", "Parent name"),
      required: required("guardianName"),
      reason: required("guardianName")
        ? "Required by this school's admission form."
        : "Optional; leave parent columns blank to import the student without a parent profile.",
    });
  }
  if (shown("phone")) {
    columns.push({
      key: "phone",
      header: label("phone", "Parent mobile"),
      required: required("phone"),
      reason: required("phone")
        ? "Required to create or match a parent; use a 10-digit mobile number."
        : "Optional; a mobile or email creates the parent login. Blank imports the student without a parent.",
    });
  }
  if (shown("email")) {
    columns.push({
      key: "email",
      header: label("email", "Parent email"),
      required: required("email"),
      reason: required("email")
        ? "Required by this school's admission form."
        : "Optional; with a parent name, a mobile or email creates the parent login.",
    });
  }
  return columns;
}

function studentCustomFields(fields: AdmissionFormField[]) {
  return visibleFields(fields).filter((field) => !field.builtin || field.id === "message");
}

function requiredSheetHeader(header: string, required: boolean) {
  const base = String(header || "").replace(/\s*\*$/, "").trim();
  return required ? `${base} *` : base;
}

export function studentImportHeaders(fields: AdmissionFormField[]) {
  return uniqueHeaders([
    ...studentBuiltinColumns(fields).map((column) => requiredSheetHeader(column.header, column.required)),
    ...studentCustomFields(fields).map((field) => requiredSheetHeader(field.label, field.required)),
    "Example only",
  ]);
}

export function studentImportColumnGuide(fields: AdmissionFormField[]) {
  const headers = studentImportHeaders(fields);
  const specs = [
    ...studentBuiltinColumns(fields).map(({ required, reason }) => ({ required, reason })),
    ...studentCustomFields(fields).map((field) => ({
      required: field.required,
      reason: field.required ? "Required by this school's admission form." : "Optional in this school's admission form.",
    })),
  ];
  return headers.map((header, index) => ({ header, ...(specs[index] || { required: false, reason: "Example row marker; leave blank for real records." }) }));
}

export function parseRollNumber(raw: string) {
  const text = String(raw || "").trim();
  if (!text) return { ok: true as const, value: null as number | null };
  if (!/^\d{1,4}$/.test(text)) return { ok: false as const, value: null };
  const value = Number(text);
  if (!Number.isInteger(value) || value < 1) return { ok: false as const, value: null };
  return { ok: true as const, value };
}

/**
 * Roll numbers for a student sheet, in sheet order:
 * - a roll typed in the sheet is used as-is;
 * - blank, and the student is already in that class → keeps their current roll;
 * - blank otherwise → the larger of (sheet row − 1) and (last roll in that class + 1).
 * So an empty class with no rolls typed gets 1, 2, 3… down the sheet.
 */
export function planStudentRolls(
  rows: { row: string; classKey: string; studentId: string; typed: number | null }[],
  enrollments: { studentId: string; classKey: string; rollNumber: number }[]
) {
  const rolls = new Map<string, number>();
  const errors: string[] = [];
  const last = new Map<string, number>();
  const owner = new Map<string, string>();
  const current = new Map<string, number>();
  for (const row of enrollments) {
    last.set(row.classKey, Math.max(last.get(row.classKey) || 0, row.rollNumber));
    owner.set(`${row.classKey}:${row.rollNumber}`, row.studentId);
    current.set(`${row.classKey}:${row.studentId}`, row.rollNumber);
  }
  for (const item of rows) {
    if (!item.classKey) continue;
    const mine = item.studentId ? current.get(`${item.classKey}:${item.studentId}`) : undefined;
    const sheetRow = Number(String(item.row).match(/(\d+)$/)?.[1] || 0);
    const roll = item.typed ?? mine ?? Math.max(sheetRow - 1, (last.get(item.classKey) || 0) + 1);
    const who = item.studentId || `row:${item.row}`;
    const taken = owner.get(`${item.classKey}:${roll}`);
    if (taken && taken !== who) {
      errors.push(`Row ${item.row}: roll ${roll} is already used in ${item.classKey}${taken.startsWith("row:") ? ` by row ${taken.slice(4)}` : ""}.`);
      continue;
    }
    if (mine && mine !== roll) owner.delete(`${item.classKey}:${mine}`);
    owner.set(`${item.classKey}:${roll}`, who);
    last.set(item.classKey, Math.max(last.get(item.classKey) || 0, roll));
    rolls.set(item.row, roll);
  }
  return { rolls, errors };
}

/** "2026-04", "2026-04-01" or "Apr 2026" → "2026-04"; "" when blank; null when not a month. */
export function parseBillingMonth(raw: string) {
  const text = String(raw || "").trim();
  if (!text) return "";
  const iso = text.match(/^(\d{4})-(0[1-9]|1[0-2])(?:-\d{2})?/);
  if (iso) return `${iso[1]}-${iso[2]}`;
  const months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  const named = text.toLowerCase().match(/^([a-z]{3})[a-z]*[\s-]+(\d{4})$/);
  if (named && months.includes(named[1])) return `${named[2]}-${String(months.indexOf(named[1]) + 1).padStart(2, "0")}`;
  return null;
}

function currentBillingMonth() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export function studentTemplateRow(
  fields: AdmissionFormField[],
  values: {
    rollNumber?: CsvCell;
    name: CsvCell;
    dob: CsvCell;
    classLabel: CsvCell;
    billingStart?: CsvCell;
    interests?: CsvCell;
    parentName: CsvCell;
    parentMobile: CsvCell;
    parentEmail: CsvCell;
    message?: CsvCell;
    custom?: Record<string, CsvCell>;
    example?: CsvCell;
  }
) {
  const byKey: Record<StudentColumnKey, CsvCell> = {
    roll: values.rollNumber ?? "",
    studentName: values.name,
    dob: values.dob,
    classWanted: values.classLabel,
    interests: values.interests ?? "",
    billingStartPeriod: values.billingStart ?? "",
    guardianName: values.parentName,
    phone: values.parentMobile,
    email: values.parentEmail,
  };
  const custom = studentCustomFields(fields).map((field) =>
    field.id === "message" ? (values.message || "") : (values.custom?.[field.id] || "")
  );
  return [...studentBuiltinColumns(fields).map((column) => byKey[column.key]), ...custom, values.example || ""];
}

function staffImportColumns(fields: AdmissionFormField[]) {
  const columns: { id: string; header: string; required: boolean }[] = [];
  for (const field of visibleFields(fields)) {
    columns.push({
      id: field.id,
      header: requiredSheetHeader(field.label, field.required),
      required: field.required,
    });
    if (field.id === "role") {
      columns.push({ id: "classTeacherOf", header: "Class teacher of", required: false });
    }
  }
  if (!columns.some((column) => column.id === "classTeacherOf")) {
    columns.push({ id: "classTeacherOf", header: "Class teacher of", required: false });
  }
  columns.push({ id: "example", header: "Example only", required: false });
  return columns;
}

export function staffImportHeaders(fields: AdmissionFormField[]) {
  return uniqueHeaders(staffImportColumns(fields).map((column) => column.header));
}

export function sheetColumnSummary(headers: string[]) {
  return headers.filter((header) => normalizeHeader(header) !== "exampleonly").join(", ");
}

function staffTemplateRow(
  fields: AdmissionFormField[],
  values: {
    name: CsvCell;
    mobile: CsvCell;
    email: CsvCell;
    role: CsvCell;
    classTeacherOf?: CsvCell;
    salary?: CsvCell;
    qualification?: CsvCell;
    joiningDate?: CsvCell;
    address?: CsvCell;
    department?: CsvCell;
    custom?: Record<string, CsvCell>;
    example?: CsvCell;
  }
) {
  const byId: Record<string, CsvCell> = {
    staffName: values.name,
    phone: values.mobile,
    email: values.email,
    role: values.role,
    classTeacherOf: values.classTeacherOf || "",
    monthlySalary: values.salary || "",
    qualification: values.qualification || "",
    joiningDate: values.joiningDate || "",
    address: values.address || "",
    department: values.department || "",
    example: values.example || "",
  };
  return staffImportColumns(fields).map((column) => {
    if (column.id in byId) return byId[column.id];
    return values.custom?.[column.id] || "";
  });
}

function headerIndex(headers: CsvCell[], ...labels: string[]) {
  const normalized = labels.map((label) => normalizeHeader(label)).filter(Boolean);
  return headers.findIndex((header) => normalized.includes(normalizeHeader(header)));
}

function csvBuffer(rows: CsvCell[][]) {
  const encoded = rows.map((row) => row.map((value) => `"${String(value).replaceAll('"', '""')}"`).join(","));
  return Buffer.from(`\uFEFF${encoded.join("\r\n")}\r\n`, "utf8");
}

const SAMPLE_STUDENT_FIRST_NAMES = [
  "Aarav",
  "Aanya",
  "Aditya",
  "Advait",
  "Aisha",
  "Ali",
  "Ananya",
  "Anika",
  "Anvi",
  "Arjun",
  "Arnav",
  "Avni",
  "Ayaan",
  "Dev",
  "Devika",
  "Diya",
  "Hana",
  "Harsh",
  "Inaaya",
  "Ira",
  "Ishaan",
  "Kabir",
  "Kiara",
  "Krish",
  "Lavanya",
  "Meera",
  "Mihir",
  "Myra",
  "Navya",
  "Neel",
  "Nisha",
  "Parth",
  "Prisha",
  "Raghav",
  "Reyansh",
  "Riya",
  "Ruhi",
  "Samaira",
  "Samar",
  "Sara",
  "Shaurya",
  "Siya",
  "Tara",
  "Ved",
  "Vihaan",
  "Vivaan",
  "Yash",
  "Zara",
  "Zoya",
  "Aryan",
];

const SAMPLE_LAST_NAMES = [
  "Sharma",
  "Menon",
  "Nair",
  "Reddy",
  "Rao",
  "Qureshi",
  "Iyer",
  "Bose",
  "Kapoor",
  "Patil",
];

function sampleStudentRows(labels: string[]) {
  const usableLabels = labels.length ? labels : ["1-A", "2-A", "3-A", "4-A", "5-A"];
  const rollsByClass = new Map<string, number>();
  return SAMPLE_STUDENT_FIRST_NAMES.map((first, index) => {
    const last = SAMPLE_LAST_NAMES[index % SAMPLE_LAST_NAMES.length];
    const classLabel = usableLabels[index % usableLabels.length];
    const parentFirst = ["Neha", "Rahul", "Pooja", "Amit", "Farah", "Vikram", "Ritu", "Sanjay", "Kavita", "Imran"][index % 10];
    const rollNumber = (rollsByClass.get(classLabel) || 0) + 1;
    rollsByClass.set(classLabel, rollNumber);
    return {
      admissionNo: `TEST-${String(index + 1).padStart(3, "0")}`,
      rollNumber,
      name: `${first} ${last}`,
      dob: `201${index % 7}-${String((index % 12) + 1).padStart(2, "0")}-${String((index % 27) + 1).padStart(2, "0")}`,
      classLabel,
      interests: ["Sports", "Olympiad", "Science", "Arts", "Spelling"][index % 5],
      parentName: `${parentFirst} ${last}`,
      parentMobile: `98765${String(40000 + index).padStart(5, "0")}`,
      parentEmail: `parent${String(index + 1).padStart(3, "0")}@example.com`,
    };
  });
}

function sampleStaffRows(labels: string[], roles: StaffImportRole[]) {
  const usableLabels = labels.length ? labels : ["1-A", "2-A", "3-A", "4-A", "5-A"];
  const classTeacherLabels = usableLabels.slice(1);
  const roleLabels = new Set(roles.map((role) => roleLabel(role)));
  const teacherRows = [
    "Meera Singh",
    "Rohan Verma",
    "Nisha Khan",
    "Amit Das",
    "Priya Nair",
    "Farhan Ali",
    "Sneha Rao",
    "Karan Mehta",
    "Pallavi Iyer",
    "Deepak Joshi",
  ].map((name, index) => [
    name,
    `98766${String(10000 + index).padStart(5, "0")}`,
    `teacher${String(index + 1).padStart(2, "0")}@example.com`,
    "TEACHER",
    classTeacherLabels[index] || "",
    30000 + index * 1000,
    ["B.Ed", "M.Sc Mathematics", "B.A English", "M.A History", "B.Sc Physics"][index % 5],
    "",
  ] as CsvCell[]);
  const officeRows = [
    ["Vikram Rao", "9876670001", "admin.import@example.com", "ADMIN", "", 50000, "Principal", ""],
    ["Ritu Shah", "9876670002", "fees.import@example.com", "FEES", "", 36000, "Accounts", ""],
    ["Kiran Mehta", "9876670003", "exams.import@example.com", "EXAMS", "", 38000, "Exam controller", ""],
    ["Asha Gupta", "9876670004", "admissions.import@example.com", "ADMISSIONS", "", 34000, "Admissions", ""],
  ].filter((row) => roleLabels.has(String(row[3]))) as CsvCell[][];
  return [...teacherRows, ...officeRows];
}

function sampleOpeningBalanceAmount(index: number) {
  return 900 + ((index * 1379) % 8) * 500;
}

function openingBalanceRows(
  students: OpeningBalanceStudent[],
  openingByStudent: Map<string, OpeningBalanceInvoice>,
  classLabels: string[],
  options: { sampleData?: boolean; includeExampleOnEmpty?: boolean } = {}
): CsvCell[][] {
  const rows: CsvCell[][] = [
    OPENING_BALANCE_HEADERS,
  ];

  if (!students.length && options.includeExampleOnEmpty !== false) {
    rows.push(["", "Aarav Sharma (example)", classLabels[0] || "1-A", 2500, dateText(new Date()), "YES"]);
    return rows;
  }

  students.forEach((student, index) => {
    const current = openingByStudent.get(student.id);
    rows.push([
      student.admissionNo,
      student.name,
      `${student.class.name}-${student.class.section}`,
      options.sampleData ? sampleOpeningBalanceAmount(index) : current?.amount || 0,
      current ? dateText(current.dueDate) : dateText(new Date()),
      "",
    ]);
  });
  return rows;
}

async function openingBalanceRowsForTemplate(classLabels: string[], options: { sampleData?: boolean } = {}) {
  const students = await prisma.student.findMany({ include: { class: true }, orderBy: { name: "asc" } });
  const opening = await prisma.feeInvoice.findMany({ where: { period: "OPENING" }, include: { payments: true } });
  return openingBalanceRows(students, new Map(opening.map((row) => [row.studentId, row])), classLabels, { includeExampleOnEmpty: true, ...options });
}

async function openingBalanceTemplateWorkbook(classLabels: string[], options: { sampleData?: boolean } = {}) {
  const [students, opening] = await Promise.all([
    prisma.student.findMany({ include: { class: true }, orderBy: [{ class: { name: "asc" } }, { class: { section: "asc" } }, { name: "asc" }] }),
    prisma.feeInvoice.findMany({ where: { period: "OPENING" }, include: { payments: true } }),
  ]);
  const openingByStudent = new Map(opening.map((row) => [row.studentId, row]));
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Anekio";
  workbook.subject = "First time fee import";
  const labels = classLabels.length ? classLabels : ["1-A"];

  labels.forEach((label) => {
    const sheet = workbook.addWorksheet(label);
    const classStudents = students.filter((student) => `${student.class.name}-${student.class.section}` === label);
    const rows = openingBalanceRows(classStudents, openingByStudent, labels, { ...options, includeExampleOnEmpty: students.length === 0 });
    rows.forEach((row) => sheet.addRow(row));
    applyHeaderStyle(sheet);
    sheet.columns = OPENING_BALANCE_HEADERS.map((header) => ({ header, key: normalizeHeader(header), width: Math.max(16, header.length + 2) }));
  });

  return workbook;
}

function blankRowsFor(kind: ImportKind, labels: string[]): CsvCell[][] {
  const firstClass = labels[0] || "1-A";
  if (kind === "teachers") {
    return [
      ["Name", "Mobile", "Email", "Role", "Class teacher of", "Monthly salary", "Qualification", "Example only"],
      ["Meera Singh (example)", "9876543211", "teacher@example.com", "TEACHER", firstClass, 30000, "B.Ed, Mathematics", "YES"],
    ];
  }
  if (kind === "opening_balances") {
    return [
      OPENING_BALANCE_HEADERS,
      ["", "Aarav Sharma (example)", firstClass, 2500, dateText(new Date()), "YES"],
    ];
  }
  return [];
}

async function csvRowsFor(kind: ImportKind): Promise<CsvCell[][]> {
  const classes = await prisma.class.findMany({
    where: { archivedAt: null },
    orderBy: [{ name: "asc" }, { section: "asc" }],
  });
  const classLabels = [...new Set(classes.map((row) => `${row.name}-${row.section}`))];

  if (kind === "classes") {
    return [
      ["Anekio class ID", "Class name", "Section", "Example only"],
      ["", "1", "A", "YES"],
      ...classes.map((row) => [row.id, row.name, row.section, ""]),
    ];
  }

  if (kind === "students") {
    const [students, forms] = await Promise.all([
      prisma.student.findMany({
        include: {
          class: true,
          parent: { include: { user: true } },
          enrollments: { where: { active: true, session: { current: true } }, select: { classId: true, rollNumber: true } },
        },
        orderBy: { name: "asc" },
      }),
      configuredImportForms(),
    ]);
    return [
      ["Anekio student ID", "Admission number", ...studentImportHeaders(forms.admission)],
      ["", "", ...studentTemplateRow(forms.admission, { rollNumber: 1, name: "Aarav Sharma (example)", dob: "2015-04-12", classLabel: classLabels[0] || "1-A", billingStart: currentBillingMonth(), interests: "Sports", parentName: "Neha Sharma", parentMobile: "9876543210", parentEmail: "parent@example.com", message: "Interested in admission.", example: "YES" })],
      ...students.map((student) => [
        student.id,
        student.admissionNo,
        ...studentTemplateRow(forms.admission, {
          rollNumber: student.enrollments.find((row) => row.classId === student.classId)?.rollNumber || "",
          name: student.name,
          dob: student.dateOfBirth ? dateText(student.dateOfBirth) : "",
          classLabel: `${student.class.name}-${student.class.section}`,
          billingStart: student.billingStartPeriod || "",
          parentName: student.parent?.user.name || "",
          parentMobile: student.parent?.phone || student.parent?.user.phone || "",
          parentEmail: !student.parent || student.parent.user.email.endsWith("@local.anekio.invalid") ? "" : student.parent.user.email,
        }),
      ]),
    ];
  }

  if (kind === "teachers") {
    await ensureAccessRoles();
    const [teachers, staffMembers, forms] = await Promise.all([
      prisma.teacher.findMany({ where: { teachingOnly: false }, include: { user: { include: { role: true } }, class: true }, orderBy: { user: { name: "asc" } } }),
      prisma.staffMember.findMany({ include: { user: { include: { role: true } }, role: true }, orderBy: { name: "asc" } }),
      configuredImportForms(),
    ]);
    return [
      staffImportHeaders(forms.staff),
      staffTemplateRow(forms.staff, { name: "Meera Singh (example)", mobile: "9876543211", email: "teacher@example.com", role: "TEACHER", classTeacherOf: classLabels[0] || "1-A", salary: 30000, qualification: "B.Ed, Mathematics", joiningDate: dateText(new Date()), address: "", department: "Teaching", example: "YES" }),
      ...teachers.map((teacher) => [
        ...staffTemplateRow(forms.staff, {
          name: teacher.user.name,
          mobile: teacher.user.phone || "",
          email: teacher.user.email.endsWith("@local.anekio.invalid") ? "" : teacher.user.email,
          role: roleLabel(teacher.user.role),
          classTeacherOf: teacher.class ? `${teacher.class.name}-${teacher.class.section}` : "",
          salary: teacher.monthlySalary,
          qualification: teacher.qualification || "",
          joiningDate: teacher.joinedOn,
          address: teacher.address,
          department: "Teaching",
        }),
      ]),
      ...staffMembers.map((staff) => [
        ...staffTemplateRow(forms.staff, {
          name: staff.name,
          mobile: staff.phone || staff.user?.phone || "",
          email: staff.user?.email && !staff.user.email.endsWith("@local.anekio.invalid") && !staff.user.email.endsWith("@mobile.local") ? staff.user.email : "",
          role: staff.role || staff.user?.role ? roleLabel((staff.role || staff.user?.role)!) : "ADMIN",
          salary: staff.monthlySalary,
          qualification: staff.title || "",
          joiningDate: staff.joinedOn,
          address: staff.address,
          department: staff.title || "",
        }),
      ]),
    ];
  }

  if (kind === "attendance") {
    return [
      ["Anekio student ID", "Admission number", "Student name", "Class", dateText(new Date()), "Example only"],
      ["", "ADM-001", "Aarav Sharma (example)", classLabels[0] || "1-A", "P", "YES"],
    ];
  }

  if (kind === "staff_attendance") {
    return [
      ["Anekio staff ID", "Staff type", "Employee ID", "Staff name", "Role", dateText(new Date()), "Example only"],
      ["", "teacher", "T-101", "Meera Singh (example)", "Teacher", "P", "YES"],
    ];
  }

  if (kind === "exam_marks") {
    return [
      ["Anekio student ID", "Admission number", "Student name", "Class", "Midterm - Mathematics (/80)", "Example only"],
      ["", "ADM-001", "Aarav Sharma (example)", classLabels[0] || "1-A", 72, "YES"],
    ];
  }

  if (kind === "class_teachers") {
    const teachers = await prisma.teacher.findMany({ include: { user: true }, orderBy: { user: { name: "asc" } } });
    const teacherLabels = teachers.map((teacher) => `${teacher.employeeId} · ${teacher.user.name}`);
    return [
      ["Class", "Class teacher employee ID", "Class teacher name", "Example only"],
      [classLabels[0] || "1-A", teachers[0]?.employeeId || "T-101", teachers[0]?.user.name || "Meera Singh (example)", "YES"],
      ...classes.map((klass, index) => {
        const teacher = teachers[index] || null;
        return [`${klass.name}-${klass.section}`, teacher?.employeeId || "", teacher?.user.name || "", ""];
      }),
      ...(teacherLabels.length ? [["Available teachers", teacherLabels.join("; "), "", "YES"] as CsvCell[]] : []),
    ];
  }

  return openingBalanceRowsForTemplate(classLabels);
}

async function attendanceTemplateWorkbook(options: { sampleData?: boolean } = {}) {
  const session = await prisma.schoolSession.findFirst({
    where: { current: true },
    orderBy: { startsOn: "desc" },
  });
  if (!session) throw new Error("Create a school session before downloading attendance.");
  const today = dateText(new Date());
  const through = [session.endsOn, today].filter(Boolean).sort()[0] || today;
  const dates = dateRange(session.startsOn, through);
  if (!dates.length) throw new Error("This session has no dates to export yet.");
  const [config, holidays, classes] = await Promise.all([
    prisma.schoolConfig.findUnique({ where: { id: "school" }, select: { weekdays: true } }),
    prisma.schoolHoliday.findMany({ where: { sessionId: session.id }, orderBy: { date: "asc" } }),
    prisma.class.findMany({
      where: { archivedAt: null },
      include: { students: { orderBy: { name: "asc" } } },
      orderBy: [{ name: "asc" }, { section: "asc" }],
    }),
  ]);
  if (!classes.length) throw new Error("Create classes before downloading attendance.");
  const holidayByDate = new Map(holidays.map((row) => [row.date, row.name]));
  const weekdays = parseWeekdays(config?.weekdays);
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Anekio";
  workbook.subject = `Attendance import for ${session.label}`;
  const headers = ["Anekio student ID", "Admission number", "Student name", "Class", ...dates, "Example only"];
  for (const klass of classes) {
    const label = `${klass.name}-${klass.section}`;
    const sheet = workbook.addWorksheet(label);
    sheet.addRow(headers);
    sheet.addRow([
      "",
      "ADM-001",
      "Aarav Sharma (example)",
      label,
      ...dates.map((date) => holidayByDate.has(date) ? "H" : weekdays.includes(new Date(`${date}T00:00:00`).getDay() || 7) ? "P" : "H"),
      "YES",
    ]);
    klass.students.forEach((student) => {
      sheet.addRow([
        student.id,
        student.admissionNo,
        student.name,
        label,
        ...dates.map((date) => holidayByDate.has(date) ? "H" : weekdays.includes(new Date(`${date}T00:00:00`).getDay() || 7) ? "P" : "H"),
        "",
      ]);
    });
    applyHeaderStyle(sheet);
    sheet.columns = headers.map((header, index) => ({ header, key: normalizeHeader(header), width: index < 4 ? Math.max(18, header.length + 2) : 13 }));
  }
  return workbook;
}

async function staffAttendanceTemplateWorkbook(options: { sampleData?: boolean } = {}) {
  const session = await prisma.schoolSession.findFirst({
    where: { current: true },
    orderBy: { startsOn: "desc" },
  });
  if (!session) throw new Error("Create a school session before downloading staff attendance.");
  const today = dateText(new Date());
  const through = [session.endsOn, today].filter(Boolean).sort()[0] || today;
  const dates = dateRange(session.startsOn, through);
  if (!dates.length) throw new Error("This session has no dates to export yet.");
  const [config, holidays, teachers, staffMembers] = await Promise.all([
    prisma.schoolConfig.findUnique({ where: { id: "school" }, select: { weekdays: true } }),
    prisma.schoolHoliday.findMany({ where: { sessionId: session.id }, orderBy: { date: "asc" } }),
    prisma.teacher.findMany({
      where: { teachingOnly: false },
      include: { user: { include: { role: true } }, class: true },
      orderBy: { user: { name: "asc" } },
    }),
    prisma.staffMember.findMany({
      where: { archivedAt: null },
      include: { role: true, user: { include: { role: true } } },
      orderBy: { name: "asc" },
    }),
  ]);
  if (!teachers.length && !staffMembers.length) throw new Error("Create staff before downloading staff attendance.");
  const holidayByDate = new Map(holidays.map((row) => [row.date, row.name]));
  const weekdays = parseWeekdays(config?.weekdays);
  const markForDate = (date: string) => holidayByDate.has(date) ? "H" : weekdays.includes(new Date(`${date}T00:00:00`).getDay() || 7) ? "P" : "H";
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Anekio";
  workbook.subject = `Staff attendance import for ${session.label}`;
  const headers = ["Anekio staff ID", "Staff type", "Employee ID", "Staff name", "Role", ...dates, "Example only"];
  const sheet = workbook.addWorksheet(TEMPLATE_DETAILS.staff_attendance.sheet);
  sheet.addRow(headers);
  sheet.addRow(["", "teacher", "T-101", "Meera Singh (example)", "Teacher", ...dates.map(markForDate), "YES"]);
  if (options.sampleData) {
    teachers.slice(0, 2).forEach((teacher) => {
      sheet.addRow([
        teacher.id,
        "teacher",
        teacher.employeeId,
        teacher.user.name,
        teacher.class ? `Class teacher ${teacher.class.name}-${teacher.class.section}` : roleLabel(teacher.user.role),
        ...dates.map(markForDate),
        "",
      ]);
    });
    staffMembers.slice(0, Math.max(0, 2 - Math.min(2, teachers.length))).forEach((staff) => {
      sheet.addRow([
        staff.id,
        "staff",
        staff.employeeId,
        staff.name,
        staff.role ? roleLabel(staff.role) : staff.user?.role ? roleLabel(staff.user.role) : staff.title || "Staff",
        ...dates.map(markForDate),
        "",
      ]);
    });
  } else {
    teachers.forEach((teacher) => {
      sheet.addRow([
        teacher.id,
        "teacher",
        teacher.employeeId,
        teacher.user.name,
        teacher.class ? `Class teacher ${teacher.class.name}-${teacher.class.section}` : roleLabel(teacher.user.role),
        ...dates.map(markForDate),
        "",
      ]);
    });
    staffMembers.forEach((staff) => {
      sheet.addRow([
        staff.id,
        "staff",
        staff.employeeId,
        staff.name,
        staff.role ? roleLabel(staff.role) : staff.user?.role ? roleLabel(staff.user.role) : staff.title || "Staff",
        ...dates.map(markForDate),
        "",
      ]);
    });
  }
  applyHeaderStyle(sheet);
  sheet.columns = headers.map((header, index) => ({ header, key: normalizeHeader(header), width: index < 5 ? Math.max(16, header.length + 2) : 13 }));
  return workbook;
}

function examColumnLabel(exam: { series?: { name: string } | null; subject: { name: string; code?: string | null }; maxMarks: number }) {
  return `${exam.series?.name || "Exam"} - ${formatSubjectLabel(exam.subject.code, exam.subject.name)} (/${exam.maxMarks})`;
}

function sampleExamMark(studentIndex: number, examIndex: number, maxMarks: number): CsvCell {
  if ((studentIndex + examIndex) % 13 === 5) return "Ab";
  const floor = Math.max(1, Math.round(maxMarks * 0.45));
  const range = Math.max(1, maxMarks - floor);
  return Math.min(maxMarks, floor + ((studentIndex * 11 + examIndex * 7) % (range + 1)));
}

async function examMarksTemplateWorkbook(options: { sampleData?: boolean } = {}) {
  const session = await prisma.schoolSession.findFirst({
    where: { current: true },
    orderBy: { startsOn: "desc" },
  });
  if (!session) throw new Error("Create a school session before downloading exam marks.");
  const classes = await prisma.class.findMany({
    where: { archivedAt: null },
    include: {
      students: { orderBy: { name: "asc" } },
      examSeries: {
        where: { sessionId: session.id },
        include: { exams: { include: { subject: true }, orderBy: [{ date: "asc" }, { title: "asc" }] } },
        orderBy: { createdAt: "asc" },
      },
    },
    orderBy: [{ name: "asc" }, { section: "asc" }],
  });
  const classesWithExams = classes.filter((klass) => klass.examSeries.some((series) => series.exams.length));
  if (!classesWithExams.length) throw new Error("Create past exam series in Exams before downloading marks history.");
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Anekio";
  workbook.subject = `Exam marks import for ${session.label}`;
  for (const klass of classesWithExams) {
    const label = `${klass.name}-${klass.section}`;
    const exams = klass.examSeries.flatMap((series) => series.exams.map((exam) => ({ ...exam, series })));
    const headers = ["Anekio student ID", "Admission number", "Student name", "Class", ...exams.map(examColumnLabel), "Remarks", "Example only"];
    const sheet = workbook.addWorksheet(label);
    sheet.addRow(headers);
    sheet.addRow(["", "ADM-001", "Aarav Sharma (example)", label, ...exams.map((exam, index) => index === 0 ? Math.min(72, exam.maxMarks) : ""), "", "YES"]);
    klass.students.forEach((student, studentIndex) => {
      sheet.addRow([
        student.id,
        student.admissionNo,
        student.name,
        label,
        ...exams.map((exam, examIndex) => options.sampleData ? sampleExamMark(studentIndex, examIndex, exam.maxMarks) : ""),
        "",
        "",
      ]);
    });
    applyHeaderStyle(sheet);
    sheet.columns = headers.map((header, index) => ({ header, key: normalizeHeader(header), width: index < 4 ? Math.max(18, header.length + 2) : Math.max(16, Math.min(28, header.length + 2)) }));
  }
  return workbook;
}

function xlsxFileName(kind: ImportKind) {
  return TEMPLATE_DETAILS[kind].file.replace(/\.csv$/i, ".xlsx");
}

function applyHeaderStyle(sheet: ExcelJS.Worksheet) {
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  sheet.getRow(1).font = { bold: true };
}

async function staffImportRoles(db: Pick<typeof prisma, "role"> = prisma): Promise<StaffImportRole[]> {
  await ensureAccessRoles();
  return db.role.findMany({
    where: { portal: { in: ["OFFICE", "TEACHER"] } },
    select: { id: true, name: true, slug: true, portal: true },
    orderBy: [{ portal: "asc" }, { isSystem: "desc" }, { name: "asc" }],
  });
}

function roleLabel(role: StaffImportRole) {
  return role.slug === "TEACHER" ? "TEACHER" : role.name.toUpperCase();
}

function roleLookupKey(value: string) {
  return normalizeHeader(value);
}

function resolveStaffImportRole(roles: StaffImportRole[], row: ImportRow, fields: AdmissionFormField[] = []) {
  const raw = configuredImportValue(row, fields, "role", "Role", "Role ID", "Role slug") || "TEACHER";
  const key = roleLookupKey(raw);
  return roles.find((role) => [role.id, role.slug, role.name, roleLabel(role)].some((value) => roleLookupKey(value) === key)) || null;
}

function monthlySalaryFrom(row: ImportRow, fallback: number) {
  const raw = sheetCell(row, "Monthly salary", "Salary");
  if (!raw) return fallback;
  const value = Number(raw.replace(/[₹,\s]/g, ""));
  return Number.isFinite(value) && value >= 0 ? Math.round(value) : fallback;
}

function salaryIsValid(row: ImportRow) {
  const raw = sheetCell(row, "Monthly salary", "Salary");
  if (!raw) return true;
  const value = Number(raw.replace(/[₹,\s]/g, ""));
  return Number.isFinite(value) && value >= 0;
}

async function ensureClassForImport(db: OnboardingDb, klass: { name: string; section: string }) {
  const existing = await db.class.findFirst({ where: { name: klass.name, section: klass.section } });
  if (existing) return existing.archivedAt
    ? db.class.update({ where: { id: existing.id }, data: { archivedAt: null } })
    : existing;
  return db.class.create({ data: { name: klass.name, section: klass.section } });
}

export async function onboardingTemplate(user: AccessUser, rawKind: string) {
  need(user);
  const kind = asKind(rawKind);
  if (kind === "students") await requireSchoolAdmissionFormSetup();
  return {
    fileName: TEMPLATE_DETAILS[kind].file,
    contentType: "text/csv; charset=utf-8",
    buffer: csvBuffer(await csvRowsFor(kind)),
  };
}

export async function onboardingSpreadsheetTemplate(user: AccessUser, rawKind: string, options: { sampleData?: boolean } = {}) {
  need(user);
  const kind = asKind(rawKind);
  if (kind === "students") await requireSchoolAdmissionFormSetup();
  if (kind === "attendance") {
    const workbook = await attendanceTemplateWorkbook(options);
    return {
      fileName: xlsxFileName(kind),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buffer: Buffer.from(await workbook.xlsx.writeBuffer()),
    };
  }
  if (kind === "staff_attendance") {
    const workbook = await staffAttendanceTemplateWorkbook(options);
    return {
      fileName: xlsxFileName(kind),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buffer: Buffer.from(await workbook.xlsx.writeBuffer()),
    };
  }
  if (kind === "exam_marks") {
    const workbook = await examMarksTemplateWorkbook(options);
    return {
      fileName: xlsxFileName(kind),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buffer: Buffer.from(await workbook.xlsx.writeBuffer()),
    };
  }
  const classes = await prisma.class.findMany({
    where: { archivedAt: null },
    orderBy: [{ name: "asc" }, { section: "asc" }],
  });
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Anekio";
  const labels = classes.length ? [...new Set(classes.map((row) => `${row.name}-${row.section}`))] : ["1-A", "2-A", "3-A", "4-A", "5-A"];
  if (kind === "opening_balances") {
    const openingWorkbook = await openingBalanceTemplateWorkbook(labels, options);
    return {
      fileName: xlsxFileName(kind),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buffer: Buffer.from(await openingWorkbook.xlsx.writeBuffer()),
    };
  }
  if (kind !== "students") {
    const forms = kind === "teachers" ? await configuredImportForms() : null;
    const blankRows = kind === "teachers"
      ? [
        staffImportHeaders(forms!.staff),
        staffTemplateRow(forms!.staff, { name: "Meera Singh (example)", mobile: "9876543211", email: "teacher@example.com", role: "TEACHER", classTeacherOf: labels[0] || "1-A", salary: 30000, qualification: "B.Ed, Mathematics", joiningDate: dateText(new Date()), address: "", department: "Teaching", example: "YES" }),
      ]
      : blankRowsFor(kind, labels);
    const rows = options.sampleData && kind === "teachers"
      ? blankRows
      : options.sampleData || !blankRows.length
        ? await csvRowsFor(kind)
        : blankRows;
    if (kind === "teachers") {
      const roles = await staffImportRoles();
      if (options.sampleData) {
        rows.push(...sampleStaffRows(labels, roles).map((row) =>
          staffTemplateRow(forms!.staff, {
            name: row[0],
            mobile: row[1],
            email: row[2],
            role: row[3],
            classTeacherOf: row[4],
            salary: row[5],
            qualification: row[6],
            joiningDate: dateText(new Date()),
            address: "",
            department: row[6],
            example: row[7],
          })
        ));
      }
    }
    const sheet = workbook.addWorksheet(TEMPLATE_DETAILS[kind].sheet);
    rows.forEach((row) => sheet.addRow(row));
    applyHeaderStyle(sheet);
    sheet.columns = (rows[0] || []).map((header) => ({ header: String(header), key: normalizeHeader(header), width: Math.max(16, String(header).length + 2) }));
    if (kind === "teachers" && forms) {
      staffImportColumns(forms.staff).forEach((column, columnIndex) => {
        const cell = sheet.getRow(1).getCell(columnIndex + 1);
        cell.note = column.required ? "Required" : "Optional";
        if (column.required) cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFE8D6" } };
      });
    }

    if (kind === "teachers" || kind === "class_teachers") {
      const roles = kind === "teachers" ? await staffImportRoles() : [];
      const lists = workbook.addWorksheet("_Lists");
      lists.state = "veryHidden";
      lists.getCell("A1").value = "Roles";
      lists.getCell("B1").value = "Classes";
      roles.forEach((role, index) => { lists.getCell(index + 2, 1).value = roleLabel(role); });
      labels.forEach((label, index) => { lists.getCell(index + 2, 2).value = label; });
      const roleEnd = Math.max(2, roles.length + 1);
      const classEnd = Math.max(2, labels.length + 1);
      const headers = rows[0] || [];
      const roleColumn = kind === "teachers" && forms
        ? headerIndex(headers, forms.staff.find((field) => field.id === "role")?.label || "", "Role") + 1
        : headerIndex(headers, "Role") + 1;
      const classColumn = kind === "teachers"
        ? headerIndex(headers, "Class teacher of") + 1
        : headerIndex(headers, "Class") + 1;
      for (let rowNumber = 2; rowNumber <= 250; rowNumber += 1) {
        if (roleColumn > 0) {
          sheet.getCell(rowNumber, roleColumn).dataValidation = {
            type: "list",
            allowBlank: true,
            formulae: [`'_Lists'!$A$2:$A$${roleEnd}`],
          };
        }
        if (classColumn > 0) {
          sheet.getCell(rowNumber, classColumn).dataValidation = {
            type: "list",
            allowBlank: true,
            formulae: [`'_Lists'!$B$2:$B$${classEnd}`],
          };
        }
      }
    }

    return {
      fileName: xlsxFileName(kind),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buffer: Buffer.from(await workbook.xlsx.writeBuffer()),
    };
  }
  const forms = await configuredImportForms();
  const headers = studentImportHeaders(forms.admission);
  const columnGuide = studentImportColumnGuide(forms.admission);
  const samplesByClass = new Map<string, ReturnType<typeof sampleStudentRows>>();
  if (options.sampleData) {
    sampleStudentRows(labels).forEach((row) => {
      const rows = samplesByClass.get(row.classLabel) || [];
      rows.push(row);
      samplesByClass.set(row.classLabel, rows);
    });
  }
  labels.forEach((label, index) => {
    const sheet = workbook.addWorksheet(label);
    sheet.addRow(headers);
    if (!options.sampleData) {
      sheet.addRow(studentTemplateRow(forms.admission, { rollNumber: 1, name: index === 0 ? "Aarav Sharma (example)" : "", dob: "2015-04-12", classLabel: label, billingStart: currentBillingMonth(), interests: "Sports", parentName: "Neha Sharma", parentMobile: "9876543210", parentEmail: "parent@example.com", message: "Interested in admission.", example: "YES" }));
    }
    (samplesByClass.get(label) || []).forEach((row) => {
      sheet.addRow(studentTemplateRow(forms.admission, { rollNumber: row.rollNumber, name: row.name, dob: row.dob, classLabel: row.classLabel, billingStart: currentBillingMonth(), interests: row.interests, parentName: row.parentName, parentMobile: row.parentMobile, parentEmail: row.parentEmail }));
    });
    applyHeaderStyle(sheet);
    sheet.columns = headers.map((header) => ({ header, key: normalizeHeader(header), width: Math.max(18, header.length + 2) }));
    columnGuide.forEach((column, columnIndex) => {
      const cell = sheet.getRow(1).getCell(columnIndex + 1);
      cell.note = `${column.required ? "Required" : "Optional"}: ${column.reason}`;
      if (column.required) cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFE8D6" } };
    });
  });
  const guide = workbook.addWorksheet("Field guide");
  guide.addRow(["Column", "Required?", "Why"]);
  columnGuide.forEach((column) => guide.addRow([column.header, column.required ? "Yes" : "No", column.reason]));
  guide.addRow([]);
  guide.addRow(["Form source", "School setup → Forms & Templates → Admission form", "Confirm the school form before downloading a fresh sheet."]);
  guide.addRow(["File uploads", "Not in Excel", "Upload document fields separately during admission."]);
  guide.addRow(["Roll numbers", "Automatic", "Existing students keep their roll. New students get the larger of (sheet row − 1) and (last roll in the class + 1). To set rolls yourself, add a \"Roll number\" column."]);
  applyHeaderStyle(guide);
  guide.columns = [{ width: 30 }, { width: 24 }, { width: 78 }];
  return {
    fileName: "anekio-students.xlsx",
    contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    buffer: Buffer.from(await workbook.xlsx.writeBuffer()),
  };
}

function realRows(rows: ImportRow[]) {
  return rows.filter((row) => !["yes", "true", "sample", "example"].includes(sheetCell(row, "Example only", "Row type").toLowerCase()));
}

export function rowsFromCsvContent(csv: string): ImportRow[] {
  return realRows(parseCsv(csv).map((row, index) => ({ ...row, _row: String(index + 2) })));
}

function rowsFromWorksheet(sheet: ExcelJS.Worksheet, classLabel = "") {
  const headers = new Map<number, string>();
  sheet.getRow(1).eachCell((cell, column) => headers.set(column, normalizeHeader(cellText(cell.value))));
  const rows: ImportRow[] = [];
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    const record: ImportRow = { _row: classLabel ? `${sheet.name}!${rowNumber}` : String(rowNumber) };
    headers.forEach((header, column) => {
      if (header) record[header] = cellText(row.getCell(column).value);
    });
    if (classLabel && !sheetCell(record, "Class")) record[normalizeHeader("Class")] = classLabel;
    if (Object.entries(record).some(([key, value]) => key !== "_row" && value.trim())) rows.push(record);
  });
  return rows;
}

export async function rowsFromWorkbookBuffer(kind: ImportKind, buf: Buffer): Promise<ImportRow[]> {
  const workbook = new ExcelJS.Workbook();
  const arrayBuffer = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
  await workbook.xlsx.load(arrayBuffer);
  if (kind === "students" || kind === "attendance" || kind === "exam_marks" || kind === "opening_balances") {
    const studentsSheet = kind === "students" ? workbook.getWorksheet(TEMPLATE_DETAILS.students.sheet) : undefined;
    const openingSheet = kind === "opening_balances" ? workbook.getWorksheet(TEMPLATE_DETAILS.opening_balances.sheet) : undefined;
    const namedSheet = studentsSheet || openingSheet;
    const sheets = namedSheet ? [namedSheet] : workbook.worksheets.filter((sheet) => Boolean(parseClass(sheet.name)));
    if (!sheets.length) {
      throw new Error(kind === "students" ? "This workbook needs a Students sheet, or tabs named like 1-A, 1-B, 2-C." : "This workbook needs class tabs named like 1-A, 1-B, 2-C.");
    }
    return realRows(sheets.flatMap((sheet) => rowsFromWorksheet(sheet, namedSheet ? "" : sheet.name)));
  }
  const sheet = workbook.getWorksheet(TEMPLATE_DETAILS[kind].sheet);
  if (!sheet) throw new Error(`This workbook has no “${TEMPLATE_DETAILS[kind].sheet}” sheet. Download the current Anekio template.`);
  return realRows(rowsFromWorksheet(sheet));
}

async function rowsFromUpload(kind: ImportKind, uploadPath: string): Promise<ImportRow[]> {
  if (!uploadPath.includes("/onboarding/imports/") || uploadPath.includes("..")) throw new Error("Use a file uploaded from School setup.");
  const { buf, type } = await readUpload(uploadPath);
  if (type === "text/csv" || uploadPath.toLowerCase().endsWith(".csv")) {
    return rowsFromCsvContent(buf.toString("utf8"));
  }
  return rowsFromWorkbookBuffer(kind, buf);
}

function rowError(row: ImportRow, message: string) {
  return `Row ${row._row}: ${message}`;
}

function onboardingImportWriteError(row: ImportRow, error: unknown) {
  if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
    const target = Array.isArray(error.meta?.target) ? error.meta.target.map(String).join(", ") : "email or mobile";
    return new Error(rowError(row, `${target} is already used by another account. Use the existing ID or change the duplicate contact detail.`));
  }
  return error;
}

function attendanceDateFromHeader(header: string) {
  if (/^\d{8}$/.test(header)) return `${header.slice(0, 4)}-${header.slice(4, 6)}-${header.slice(6, 8)}`;
  return "";
}

function attendanceCells(row: ImportRow) {
  return Object.entries(row)
    .map(([key, value]) => ({ date: attendanceDateFromHeader(key), value: value.trim() }))
    .filter((cell) => cell.date);
}

function examMarkValue(value: string) {
  const raw = value.trim();
  const normalized = raw.toUpperCase().replace(/[\s_-]+/g, "");
  if (!raw || raw === "-") return { skip: true, absent: false, marks: 0 };
  if (["A", "AB", "ABSENT"].includes(normalized)) return { skip: false, absent: true, marks: 0 };
  const marks = Number(raw);
  return Number.isFinite(marks) ? { skip: false, absent: false, marks } : null;
}

async function examMarkColumns(): Promise<ExamMarkColumn[]> {
  const orgId = currentTenantOrg();
  const session = await (orgId ? runWithoutTenant(() => prisma.schoolSession.findFirst({
    where: { current: true, orgId },
    orderBy: { startsOn: "desc" },
  })) : prisma.schoolSession.findFirst({
    where: { current: true },
    orderBy: { startsOn: "desc" },
  }));
  if (!session) return [];
  const where: Prisma.ExamWhereInput = {
    series: { sessionId: session.id, ...(orgId ? { orgId } : {}) },
  };
  const exams = await (orgId ? runWithoutTenant(() => prisma.exam.findMany({
    where,
    include: { subject: true, series: true, class: true },
    orderBy: [{ classId: "asc" }, { date: "asc" }, { title: "asc" }],
  })) : prisma.exam.findMany({
    where,
    include: { subject: true, series: true, class: true },
    orderBy: [{ classId: "asc" }, { date: "asc" }, { title: "asc" }],
  }));
  return exams.map((exam) => {
    const label = examColumnLabel(exam);
    return { key: normalizeHeader(label), examId: exam.id, classId: exam.classId, classLabel: `${exam.class.name}-${exam.class.section}`, maxMarks: exam.maxMarks, label };
  });
}

function examMarkCells(row: ImportRow, columns: ExamMarkColumn[]) {
  const rowClass = parseClass(sheetCell(row, "Class"));
  const classLabel = rowClass ? `${rowClass.name}-${rowClass.section}` : "";
  return columns
    .filter((column) => !classLabel || column.classLabel === classLabel)
    .map((column) => ({ ...column, value: row[column.key]?.trim() || "" }))
    .filter((cell) => cell.value);
}

function parseAttendanceMark(value: string): AttendanceImportMark | null {
  const mark = value.trim().toUpperCase().replace(/[\s_-]+/g, "");
  if (!mark || mark === "-") return null;
  if (["H", "HOLIDAY", "OFF", "CLOSED"].includes(mark)) return "HOLIDAY";
  if (["P", "PRESENT"].includes(mark)) return AttendanceStatus.PRESENT;
  if (["A", "ABSENT"].includes(mark)) return AttendanceStatus.ABSENT;
  if (["LT", "LATE"].includes(mark)) return AttendanceStatus.LATE;
  if (["L", "LEAVE"].includes(mark)) return AttendanceStatus.LEAVE;
  if (["HD", "HALF", "HALFDAY"].includes(mark)) return AttendanceStatus.HALF_DAY;
  return null;
}

function normalizeStaffKind(value: string): StaffAttendancePerson["kind"] | "" {
  const kind = value.trim().toLowerCase();
  if (["teacher", "teaching"].includes(kind)) return "teacher";
  if (["staff", "employee", "support", "office"].includes(kind)) return "staff";
  return "";
}

async function staffAttendancePeople(db: Pick<typeof prisma, "teacher" | "staffMember"> = prisma): Promise<StaffAttendancePerson[]> {
  const [teachers, staffMembers] = await Promise.all([
    db.teacher.findMany({ where: { teachingOnly: false }, include: { user: { include: { role: true } }, class: true } }),
    db.staffMember.findMany({ where: { archivedAt: null }, include: { role: true, user: { include: { role: true } } } }),
  ]);
  return [
    ...teachers.map((teacher) => ({
      kind: "teacher" as const,
      id: teacher.id,
      employeeId: teacher.employeeId,
      name: teacher.user.name,
      role: teacher.class ? `Class teacher ${teacher.class.name}-${teacher.class.section}` : roleLabel(teacher.user.role),
    })),
    ...staffMembers.map((staff) => ({
      kind: "staff" as const,
      id: staff.id,
      employeeId: staff.employeeId,
      name: staff.name,
      role: staff.role ? roleLabel(staff.role) : staff.user?.role ? roleLabel(staff.user.role) : staff.title || "Staff",
    })),
  ];
}

function resolveStaffAttendancePerson(row: ImportRow, people: StaffAttendancePerson[]) {
  const kind = normalizeStaffKind(sheetCell(row, "Staff type", "Type", "Kind"));
  const staffId = sheetCell(row, "Anekio staff ID", "Staff ID", "Anekio employee ID");
  const employeeId = sheetCell(row, "Employee ID", "Employee number").toLowerCase();
  const byId = staffId ? people.filter((person) => person.id === staffId) : [];
  const byEmployee = employeeId ? people.filter((person) => person.employeeId.toLowerCase() === employeeId) : [];
  const matches = (byId.length ? byId : byEmployee).filter((person) => !kind || person.kind === kind);
  return matches.length === 1 ? matches[0] : null;
}

/** Works out every row's roll number (see planStudentRolls) against the class's current rolls. */
async function studentRollPlan(db: Pick<OnboardingDb, "student" | "studentClassEnrollment">, rows: ImportRow[], fields: AdmissionFormField[]) {
  const [students, enrollments] = await Promise.all([
    db.student.findMany({ select: { id: true, admissionNo: true } }),
    db.studentClassEnrollment.findMany({
      where: { active: true, session: { current: true } },
      select: { studentId: true, rollNumber: true, class: { select: { name: true, section: true } } },
    }),
  ]);
  const ids = new Set(students.map((row) => row.id));
  const byAdmission = new Map(students.map((row) => [admissionLookupKey(row.admissionNo), row.id]));
  return planStudentRolls(
    rows.map((row) => {
      const klass = classFromImportRow(row, fields);
      const id = sheetCell(row, "Anekio student ID");
      const admissionNo = admissionLookupKey(sheetCell(row, "Admission number", "Admission no"));
      const roll = parseRollNumber(sheetCell(row, "Roll number", "Roll no", "Roll no.", "Roll"));
      return {
        row: row._row,
        classKey: klass ? `${klass.name}-${klass.section}` : "",
        studentId: (id && ids.has(id) ? id : "") || (admissionNo ? byAdmission.get(admissionNo) || "" : ""),
        typed: roll.ok ? roll.value : null,
      };
    }),
    enrollments
      .filter((row) => row.rollNumber != null)
      .map((row) => ({ studentId: row.studentId, classKey: `${row.class.name}-${row.class.section}`, rollNumber: Number(row.rollNumber) }))
  );
}

async function validateRows(kind: ImportKind, rows: ImportRow[], coveragePeriod?: string) {
  const errors: string[] = [];
  const roles = kind === "teachers" ? await staffImportRoles() : [];
  const forms = kind === "students" || kind === "teachers" ? await configuredImportForms() : null;
  const students = kind === "opening_balances" || kind === "students" || kind === "attendance"
    ? await prisma.student.findMany({ select: { id: true, admissionNo: true } })
    : [];
  const billedThroughCoverage = kind === "opening_balances"
    ? await prisma.feeInvoice.findMany({
        where: { studentId: { in: students.map((student) => student.id) }, period: { gte: "0000-01", lte: coveragePeriod || currentMonthPeriod() } },
        select: { studentId: true, period: true },
      })
    : [];
  const billedByStudent = new Map(billedThroughCoverage.map((invoice) => [invoice.studentId, invoice.period]));
  const studentById = new Map(students.map((student) => [student.id, student]));
  const studentByAdmission = new Map(students.map((student) => [admissionLookupKey(student.admissionNo), student]));
  const examStudents = kind === "exam_marks"
    ? await prisma.student.findMany({ select: { id: true, admissionNo: true, classId: true } })
    : [];
  const examColumns = kind === "exam_marks" ? await examMarkColumns() : [];
  const examsById = kind === "exam_marks" && examColumns.length
    ? new Map((await prisma.exam.findMany({ where: { id: { in: examColumns.map((column) => column.examId) } }, select: { id: true, classId: true, maxMarks: true } })).map((exam) => [exam.id, exam]))
    : new Map<string, { id: string; classId: string; maxMarks: number }>();
  const staffPeople = kind === "staff_attendance" ? await staffAttendancePeople() : [];
  const studentIds = new Set(students.map((row) => row.id));
  const admissionNos = new Set(students.map((row) => admissionLookupKey(row.admissionNo)));
  const openingAdmissionRows = new Map<string, string>();
  const examStudentsById = new Map(examStudents.map((row) => [row.id, row]));
  const examStudentsByAdmission = new Map(examStudents.map((row) => [row.admissionNo.toLowerCase(), row]));
  const classTeacherRows = new Map<string, string>();
  const rollRows = new Map<string, string>();
  const rollsInFile = new Map<string, string>();
  const existingRolls = kind === "students"
    ? await prisma.studentClassEnrollment.findMany({
        where: { active: true, session: { current: true } },
        select: { studentId: true, classId: true, rollNumber: true, class: { select: { name: true, section: true } } },
      })
    : [];
  const existingRollKey = new Set(
    existingRolls.map((row) => `${row.class.name}-${row.class.section}:${row.rollNumber}:${row.studentId}`)
  );
  const existingRollByClass = new Map<string, Set<number>>();
  for (const row of existingRolls) {
    const classKey = `${row.class.name}-${row.class.section}`;
    const set = existingRollByClass.get(classKey) || new Set<number>();
    set.add(row.rollNumber);
    existingRollByClass.set(classKey, set);
  }

  if (kind === "exam_marks") {
    if (!examColumns.length) {
      return ["No saved exam papers were found for this school. Schedule the past exam papers in Exams, then download a fresh exam marks template."];
    }
    const hasGeneratedMarkColumn = rows.some((row) =>
      examColumns.some((column) => Object.prototype.hasOwnProperty.call(row, column.key))
    );
    if (!hasGeneratedMarkColumn) {
      return ["This file does not contain the generated exam mark columns for saved exams. Download the latest exam marks template or test data, fill marks, then upload that file."];
    }
  }

  rows.forEach((row) => {
    if (kind === "classes") {
      const name = sheetCell(row, "Class name", "Class");
      const section = sheetCell(row, "Section");
      if (!name || !section) errors.push(rowError(row, "class name and section are required."));
      return;
    }
    if (kind === "students") {
      const name = configuredImportValue(row, forms!.admission, "studentName", "Student name", "Name");
      const dobLabel = forms!.admission.find((field) => field.id === "dateOfBirth")?.label || "Date of birth";
      const dob = sheetCell(row, dobLabel, "Date of birth", "DOB");
      const klass = classFromImportRow(row, forms!.admission);
      const rawPhone = configuredImportValue(row, forms!.admission, "phone", "Parent mobile", "Parent phone");
      const phone = normalizeMobile(rawPhone);
      const parentName = configuredImportValue(row, forms!.admission, "guardianName", "Parent name");
      const parentEmail = configuredImportValue(row, forms!.admission, "email", "Parent email");
      const parentContact = parentAdmissionContact({ parentName, parentPhone: phone, parentEmail });
      // Parent columns follow the admission form: no mobile and no email imports a student without a parent.
      const formRequires = (id: string) => !forms!.admission.length || forms!.admission.some((field) => field.id === id && field.visible && field.required);
      const studentId = sheetCell(row, "Anekio student ID");
      const admissionNo = sheetCell(row, "Admission number", "Admission no").toLowerCase();
      const roll = parseRollNumber(sheetCell(row, "Roll number", "Roll no", "Roll no.", "Roll"));
      if (!name) errors.push(rowError(row, "student name is required."));
      if (dob ? !validDate(dob) : formRequires("dateOfBirth")) errors.push(rowError(row, "date of birth must be YYYY-MM-DD."));
      if (!klass) errors.push(rowError(row, "class must be a value like 1-A."));
      if (!parentName && formRequires("guardianName")) errors.push(rowError(row, "parent name is required."));
      if (rawPhone.trim() && !phone) errors.push(rowError(row, "parent mobile must be a 10-digit number."));
      else if (!phone && formRequires("phone")) errors.push(rowError(row, "parent mobile must be a 10-digit number."));
      else if (parentContact.filled && !parentContact.canCreate) errors.push(rowError(row, "add a parent mobile or email, or leave the parent details empty."));
      if (formRequires("email") && !parentEmail.trim()) errors.push(rowError(row, "parent email is required."));
      if (formRequires("rollNumber") && roll.ok && roll.value == null) {
        errors.push(rowError(row, `${forms!.admission.find((field) => field.id === "rollNumber")?.label || "Roll no"} is required.`));
      }
      for (const field of visibleFields(forms!.admission)) {
        if (!field.required || ["studentName", "classWanted", "guardianName", "phone", "email", "billingStartPeriod", "rollNumber", "interests", "dateOfBirth"].includes(field.id)) continue;
        if (!configuredImportValue(row, forms!.admission, field.id, field.id === "email" ? "Parent email" : "")) {
          errors.push(rowError(row, `${field.label} is required by the admission form.`));
        }
      }
      const billingField = forms!.admission.find((field) => field.id === "billingStartPeriod");
      const billingHeader = normalizeHeader(billingField?.label || "Billing starts from");
      const billingRaw = configuredImportValue(row, forms!.admission, "billingStartPeriod", "Billing starts from");
      const billing = parseBillingMonth(billingRaw);
      if (billing === null) errors.push(rowError(row, `${billingField?.label || "Billing starts from"} must be a month like 2026-04.`));
      else if (!billing && billingField?.visible && billingField.required && Object.prototype.hasOwnProperty.call(row, billingHeader)) {
        errors.push(rowError(row, `${billingField.label} is required by the admission form (a month like 2026-04).`));
      }
      if (!roll.ok) errors.push(rowError(row, "roll number must be a whole number of 1 or more."));
      if (studentId && !studentIds.has(studentId)) errors.push(rowError(row, "Anekio student ID was not found."));
      if (!studentId && admissionNo && admissionNos.has(admissionNo)) {
        // An admission number is a safe update key, so this row is valid.
      }
      return;
    }
    if (kind === "attendance") {
      const studentId = sheetCell(row, "Anekio student ID");
      const admissionNo = sheetCell(row, "Admission number", "Admission no").toLowerCase();
      if ((!studentId || !studentIds.has(studentId)) && (!admissionNo || !admissionNos.has(admissionNo))) {
        errors.push(rowError(row, "student ID or admission number was not found."));
      }
      const cells = attendanceCells(row);
      if (!cells.length) errors.push(rowError(row, "at least one date column is required."));
      for (const cell of cells) {
        if (!validDate(cell.date)) errors.push(rowError(row, `${cell.date} is not a valid date column.`));
        if (cell.date > dateText(new Date())) errors.push(rowError(row, `${cell.date} cannot be in the future.`));
        if (cell.value && !parseAttendanceMark(cell.value)) errors.push(rowError(row, `${cell.date} must be P, A, H, L, LT, or half day.`));
      }
      return;
    }
    if (kind === "staff_attendance") {
      const rawKind = sheetCell(row, "Staff type", "Type", "Kind");
      if (rawKind && !normalizeStaffKind(rawKind)) errors.push(rowError(row, "staff type must be teacher or staff."));
      if (!resolveStaffAttendancePerson(row, staffPeople)) {
        errors.push(rowError(row, "staff ID or employee ID was not found."));
      }
      const cells = attendanceCells(row);
      if (!cells.length) errors.push(rowError(row, "at least one date column is required."));
      for (const cell of cells) {
        if (!validDate(cell.date)) errors.push(rowError(row, `${cell.date} is not a valid date column.`));
        if (cell.date > dateText(new Date())) errors.push(rowError(row, `${cell.date} cannot be in the future.`));
        if (cell.value && !parseAttendanceMark(cell.value)) errors.push(rowError(row, `${cell.date} must be P, A, H, L, LT, or half day.`));
      }
      return;
    }
    if (kind === "exam_marks") {
      const studentId = sheetCell(row, "Anekio student ID");
      const admissionNo = sheetCell(row, "Admission number", "Admission no").toLowerCase();
      const student = studentId ? examStudentsById.get(studentId) : admissionNo ? examStudentsByAdmission.get(admissionNo) : null;
      if (!student) {
        errors.push(rowError(row, "student ID or admission number was not found."));
        return;
      }
      const cells = examMarkCells(row, examColumns);
      for (const cell of cells) {
        const exam = examsById.get(cell.examId);
        const parsed = examMarkValue(cell.value);
        if (!exam) errors.push(rowError(row, `${cell.label} no longer exists.`));
        else if (exam.classId !== student.classId) errors.push(rowError(row, `${cell.label} does not belong to this student's class.`));
        else if (!parsed) errors.push(rowError(row, `${cell.label} must be a number, Ab, or blank.`));
        else if (!parsed.skip && !parsed.absent && (parsed.marks < 0 || parsed.marks > exam.maxMarks)) errors.push(rowError(row, `${cell.label} must be between 0 and ${exam.maxMarks}.`));
      }
      return;
    }
    if (kind === "teachers") {
      if (!configuredImportValue(row, forms!.staff, "staffName", "Teacher name", "Staff name", "Name")) errors.push(rowError(row, "name is required."));
      if (!normalizeMobile(configuredImportValue(row, forms!.staff, "phone", "Mobile", "Phone"))) errors.push(rowError(row, "mobile must be a 10-digit number."));
      if (!resolveStaffImportRole(roles, row, forms!.staff)) errors.push(rowError(row, "role must be one of the office or teacher roles."));
      for (const field of visibleFields(forms!.staff)) {
        if (!field.required || field.type === "file" || ["staffName", "phone", "role", "monthlySalary"].includes(field.id)) continue;
        if (!configuredImportValue(row, forms!.staff, field.id, field.label)) {
          errors.push(rowError(row, `${field.label} is required.`));
        }
      }
      const classText = sheetCell(row, "Class teacher of", "Class teacher", "Class");
      const klass = classText ? parseClass(classText) : null;
      if (classText && !klass) errors.push(rowError(row, "class teacher value must look like 1-A."));
      if (klass) {
        const classKey = `${klass.name}-${klass.section}`;
        const firstRow = classTeacherRows.get(classKey);
        if (firstRow) errors.push(rowError(row, `${classKey} already has a class teacher in row ${firstRow}.`));
        else classTeacherRows.set(classKey, row._row);
      }
      if (!salaryIsValid(row)) errors.push(rowError(row, "monthly salary must be zero or more."));
      return;
    }
    if (kind === "class_teachers") {
      const classText = sheetCell(row, "Class");
      const employeeId = sheetCell(row, "Class teacher employee ID", "Employee ID", "Teacher employee ID");
      const teacherName = sheetCell(row, "Class teacher name", "Teacher name");
      const klass = parseClass(classText);
      if (!klass) errors.push(rowError(row, "class must use a value like 1-A."));
      if (!employeeId && !teacherName) errors.push(rowError(row, "teacher employee ID or teacher name is required."));
      return;
    }
    const studentId = sheetCell(row, "Anekio student ID");
    const admissionNo = admissionLookupKey(sheetCell(row, "Admission number", "Admission no"));
    const parsedAmount = parseOpeningBacklogAmount(sheetCell(row, "Backlog invoice amount", "Opening due amount", "Previous system due", "Due amount", "Amount"));
    const dueDate = sheetCell(row, "Due date");
    const matchedStudent = studentId ? studentById.get(studentId) : studentByAdmission.get(admissionNo);
    if (!matchedStudent) {
      errors.push(rowError(row, "student ID or admission number was not found."));
    }
    const billedMonth = matchedStudent && billedByStudent.get(matchedStudent.id);
    if (billedMonth) errors.push(rowError(row, `${billedMonth} already has a monthly invoice. Do not include that month again in the opening balance.`));
    if (admissionNo) {
      const firstRow = openingAdmissionRows.get(admissionNo);
      if (firstRow) errors.push(rowError(row, "Duplicate admission number in import file"));
      else openingAdmissionRows.set(admissionNo, row._row);
    }
    if ("error" in parsedAmount) errors.push(rowError(row, parsedAmount.error));
    if (!validDate(dueDate)) errors.push(rowError(row, "due date must use YYYY-MM-DD."));
  });
  if (kind === "students" && forms) errors.push(...(await studentRollPlan(prisma, rows, forms.admission)).errors);
  return errors;
}

async function writeOnboardingState(
  id: string,
  orgId: string,
  data: { selectedModulesJson?: string } = {},
  mode: "ensure" | "save" = "save"
) {
  return runWithoutTenant(async () => {
    const existing = await prisma.schoolOnboardingState.findUnique({ where: { id } });
    if (existing) {
      if (mode === "ensure" && existing.orgId === orgId) return existing;
      return prisma.schoolOnboardingState.update({
        where: { id },
        data: mode === "ensure" ? { orgId } : { orgId, ...data },
      });
    }
    return prisma.schoolOnboardingState.create({
      data: { id, orgId, ...data },
    });
  });
}

export async function ensureOnboardingState(user: AccessUser) {
  const orgId = await onboardingOrgId(user);
  const id = onboardingStateId(orgId);
  const legacy = await runWithoutTenant(() =>
    prisma.schoolOnboardingState.findUnique({
      where: { id: ONBOARDING_STATE_ID },
      select: { orgId: true, selectedModulesJson: true },
    })
  );
  const selectedModulesJson =
    legacy && (!legacy.orgId || legacy.orgId === orgId) ? legacy.selectedModulesJson : undefined;
  return writeOnboardingState(
    id,
    orgId,
    selectedModulesJson ? { selectedModulesJson } : {},
    "ensure"
  );
}

async function onboardingOrgId(user: AccessUser) {
  const orgId = user.orgId || "";
  if (!orgId) throw new Error("Your login is not linked to a school organisation. Sign in again with a school admin account.");
  const org = await prisma.saasOrg.findUnique({ where: { id: orgId }, select: { id: true } });
  if (!org) throw new Error("Your login is linked to an organisation that was not found. Sign in again or repair this user's organisation.");
  return org.id;
}

export async function previewOnboardingImport(user: AccessUser, input: { kind?: string; uploadPath?: string; fileName?: string }) {
  need(user);
  const kind = asKind(input.kind);
  const uploadPath = String(input.uploadPath || "");
  if (!uploadPath) throw new Error("Upload a completed template first.");
  const rows = await rowsFromUpload(kind, uploadPath);
  return previewOnboardingRows(user, {
    kind,
    fileName: String(input.fileName || TEMPLATE_DETAILS[kind].file),
    uploadPath,
    rows,
  });
}

export async function previewOnboardingRows(
  user: AccessUser,
  input: { kind: ImportKind; fileName: string; uploadPath: string; rows: ImportRow[] }
) {
  need(user);
  const kind = asKind(input.kind);
  if (kind === "students") await requireSchoolAdmissionFormSetup();
  const rows = input.rows;
  if (!rows.length) throw new Error("No data rows found. Add school data below the example row, or copy it and clear Example only.");
  const orgId = await onboardingOrgId(user);
  const coveragePeriod = kind === "opening_balances" ? currentMonthPeriod() : undefined;
  const errors = [
    ...(kind === "opening_balances" ? await openingDocumentErrors(orgId) : []),
    ...(await validateRows(kind, rows, coveragePeriod)),
  ];
  const state = await ensureOnboardingState(user);
  const batch = await prisma.schoolOnboardingImport.create({
    data: {
      orgId,
      stateId: state.id,
      kind,
      fileName: input.fileName || TEMPLATE_DETAILS[kind].file,
      uploadPath: input.uploadPath,
      rowsJson: JSON.stringify(kind === "opening_balances" ? { rows, coveragePeriod } : rows),
      errorsJson: JSON.stringify(errors),
    },
  });
  return {
    batchId: batch.id,
    kind,
    rowCount: rows.length,
    validCount: errors.length ? Math.max(0, rows.length - new Set(errors.map((error) => error.match(/^Row (\d+)/)?.[1])).size) : rows.length,
    errors,
    sample: rows.slice(0, 5),
    ...(coveragePeriod ? { coveragePeriod } : {}),
  };
}

function placeholderEmail(kind: "parent" | "teacher", phone: string) {
  return `${kind}.${phone}@local.anekio.invalid`;
}

function staffPlaceholderEmail(phone: string) {
  return `staff.${phone}@local.anekio.invalid`;
}

async function applyClasses(db: OnboardingDb, rows: ImportRow[]) {
  let created = 0;
  let updated = 0;
  for (const row of rows) {
    const id = sheetCell(row, "Anekio class ID");
    const name = sheetCell(row, "Class name", "Class");
    const section = sheetCell(row, "Section").toUpperCase();
    const existing = id
      ? await db.class.findUnique({ where: { id } })
      : await db.class.findFirst({ where: { name, section } });
    if (existing) {
      await db.class.update({ where: { id: existing.id }, data: { name, section, archivedAt: null } });
      updated += 1;
    } else {
      await db.class.create({ data: { name, section } });
      created += 1;
    }
  }
  return { created, updated };
}

async function nextCodes(orgId: string | null) {
  const [students, teachers, staffMembers] = await runWithoutTenant(() => Promise.all([
    prisma.student.findMany({ where: { orgId }, select: { admissionNo: true } }),
    prisma.teacher.findMany({ where: { orgId }, select: { employeeId: true } }),
    prisma.staffMember.findMany({ where: { orgId }, select: { employeeId: true } }),
  ]));
  const studentNumbers = students.map((row) => Number(row.admissionNo.replace(/\D/g, ""))).filter(Number.isFinite);
  const teacherNumbers = teachers.map((row) => Number(row.employeeId.replace(/\D/g, ""))).filter(Number.isFinite);
  const staffNumbers = staffMembers.map((row) => Number(row.employeeId.replace(/\D/g, ""))).filter(Number.isFinite);
  return {
    admission: (studentNumbers.length ? Math.max(...studentNumbers) : 0) + 1,
    employee: (teacherNumbers.length ? Math.max(...teacherNumbers) : 100) + 1,
    staffEmployee: (staffNumbers.length ? Math.max(...staffNumbers) : 200) + 1,
  };
}

async function applyStudents(
  db: OnboardingDb,
  rows: ImportRow[],
  setup: { orgId: string; roleId: string; password: string; admission: number }
) {
  const forms = await configuredImportForms();
  const rollPlan = (await studentRollPlan(db, rows, forms.admission)).rolls;
  let created = 0;
  let updated = 0;
  let nextAdmission = setup.admission;
  for (const row of rows) {
    const klass = classFromImportRow(row, forms.admission)!;
    const existingClass = await db.class.findFirst({ where: { name: klass.name, section: klass.section } });
    const classRow = existingClass
      ? await db.class.update({ where: { id: existingClass.id }, data: { archivedAt: null } })
      : await db.class.create({ data: { name: klass.name, section: klass.section } });
    const phone = normalizeMobile(configuredImportValue(row, forms.admission, "phone", "Parent mobile", "Parent phone"));
    const suppliedEmail = configuredImportValue(row, forms.admission, "email", "Parent email").toLowerCase();
    const parentName = configuredImportValue(row, forms.admission, "guardianName", "Parent name");
    const studentName = configuredImportValue(row, forms.admission, "studentName", "Student name", "Name");
    const parentContact = parentAdmissionContact({ parentName, parentPhone: phone, parentEmail: suppliedEmail });
    const email = suppliedEmail || (phone ? placeholderEmail("parent", phone) : "");
    // No parent mobile or email: no parent login.
    const user = parentContact.canCreate
      ? await db.user.findFirst({
          where: { orgId: setup.orgId, OR: [...(email ? [{ email }] : []), ...(phone ? [{ phone }] : [])] },
          include: { parent: true, role: { select: { portal: true } } },
        })
      : null;
    let parentId = user?.parent?.id || "";
    const staffParent = Boolean(user && !parentId);
    if (user && !parentId) {
      // Staff who is also a parent: add a parent hat to the same login.
      if (user.role.portal === "STUDENT") throw new Error(rowError(row, `${user.email} is a student's own login. Use the parent's number.`));
      try {
        parentId = (await db.parent.create({ data: { orgId: setup.orgId, userId: user.id, phone: phone || user.phone || "" } })).id;
      } catch (error) {
        throw onboardingImportWriteError(row, error);
      }
    }
    if (!parentId && parentContact.canCreate && email) {
      let parentUser: { parent: { id: string } | null };
      try {
        parentUser = await db.user.create({
          data: {
            orgId: setup.orgId,
            name: parentName || `Parent of ${studentName}`,
            email,
            phone: phone || null,
            password: setup.password,
            roleId: setup.roleId,
            parent: { create: { orgId: setup.orgId, phone: phone || null } },
          },
          include: { parent: true },
        });
      } catch (error) {
        throw onboardingImportWriteError(row, error);
      }
      parentId = parentUser.parent!.id;
    } else if (user && !staffParent && user.role.portal === "PARENT") {
      await db.user.update({ where: { id: user.id }, data: { name: parentName || user.name } });
    }
    const studentId = sheetCell(row, "Anekio student ID");
    let admissionNo = sheetCell(row, "Admission number", "Admission no");
    const existing = studentId
      ? await db.student.findUnique({ where: { id: studentId } })
      : admissionNo
        ? await db.student.findFirst({ where: { admissionNo, orgId: setup.orgId } })
        : null;
    if (!admissionNo) {
      do {
        admissionNo = `ANE-${String(nextAdmission).padStart(5, "0")}`;
        nextAdmission += 1;
      } while (await db.student.findFirst({ where: { admissionNo, orgId: setup.orgId }, select: { id: true } }));
    }
    const roll = { value: rollPlan.get(row._row) ?? null };
    const tags = parsePathTags(configuredImportValue(row, forms.admission, "interests", "Interest", "Interests", "Path"));
    const billingStart = parseBillingMonth(configuredImportValue(row, forms.admission, "billingStartPeriod", "Billing starts from")) || "";
    const data = {
      orgId: setup.orgId,
      ...(billingStart ? { billingStartPeriod: billingStart } : {}),
      name: studentName,
      admissionNo,
      // A blank date of birth keeps what an existing student already has.
      ...(() => {
        const raw = sheetCell(row, forms.admission.find((field) => field.id === "dateOfBirth")?.label || "Date of birth", "Date of birth", "DOB");
        return raw ? { dateOfBirth: new Date(`${raw}T00:00:00`) } : existing ? {} : { dateOfBirth: null };
      })(),
      classId: classRow.id,
      // A row without a parent mobile keeps the student's current parent (or none for a new student).
      ...(parentId ? { parentId } : {}),
    };
    let savedId = existing?.id || "";
    if (existing) {
      await db.student.update({ where: { id: existing.id }, data });
      try {
        await assignStudentRollNumber(db, { studentId: existing.id, classId: classRow.id, orgId: setup.orgId, rollNumber: roll.value });
      } catch (error) {
        throw error instanceof Error ? new Error(rowError(row, error.message)) : error;
      }
      updated += 1;
    } else {
      const student = await db.student.create({ data: { billingStartPeriod: "", ...data } });
      savedId = student.id;
      try {
        await assignStudentRollNumber(db, { studentId: student.id, classId: classRow.id, orgId: setup.orgId, rollNumber: roll.value });
      } catch (error) {
        throw error instanceof Error ? new Error(rowError(row, error.message)) : error;
      }
      created += 1;
    }
    if (savedId) {
      await db.studentInterest.deleteMany({ where: { studentId: savedId } });
      if (tags.length) await db.studentInterest.createMany({ data: tags.map((tag) => ({ studentId: savedId, tag })) });
    }
  }
  return { created, updated };
}

async function applyTeachers(
  db: OnboardingDb,
  rows: ImportRow[],
  setup: { orgId: string; password: string; employee: number; staffEmployee: number; roles: StaffImportRole[] }
) {
  const forms = await configuredImportForms();
  let created = 0;
  let updated = 0;
  let nextEmployee = setup.employee;
  let nextStaffEmployee = setup.staffEmployee;
  for (const row of rows) {
    const role = resolveStaffImportRole(setup.roles, row, forms.staff);
    if (!role) throw new Error(rowError(row, "role no longer exists."));
    const name = configuredImportValue(row, forms.staff, "staffName", "Teacher name", "Staff name", "Name");
    const phone = normalizeMobile(configuredImportValue(row, forms.staff, "phone", "Mobile", "Phone"));
    const email = configuredImportValue(row, forms.staff, "email", "Email").toLowerCase() || (role.portal === "TEACHER" ? placeholderEmail("teacher", phone) : staffPlaceholderEmail(phone));
    const teacherId = sheetCell(row, "Anekio teacher ID");
    let employeeId = sheetCell(row, "Employee ID");
    const classText = sheetCell(row, "Class teacher of", "Class teacher", "Class");
    const klass = classText ? parseClass(classText) : null;
    const classRow = klass ? await ensureClassForImport(db, klass) : null;
    const salary = monthlySalaryFrom(row, role.portal === "TEACHER" ? 30000 : 25000);
    const joinedOn = configuredImportValue(row, forms.staff, "joiningDate", "Joining date");
    const address = configuredImportValue(row, forms.staff, "address", "Address");
    const qualification = configuredImportValue(row, forms.staff, "qualification", "Qualification");

    if (role.portal === "TEACHER") {
      const existing = teacherId
        ? await db.teacher.findUnique({ where: { id: teacherId }, include: { user: true } })
        : employeeId
          ? await db.teacher.findFirst({ where: { orgId: setup.orgId, employeeId }, include: { user: true } })
          : await db.teacher.findFirst({ where: { user: { OR: [{ email }, { phone }] } }, include: { user: true } });
      if (!employeeId) {
        do {
          employeeId = `T-${nextEmployee}`;
          nextEmployee += 1;
        } while (await db.teacher.findFirst({ where: { orgId: setup.orgId, employeeId }, select: { id: true } }));
      }
      if (existing) {
        await db.user.update({ where: { id: existing.userId }, data: { orgId: setup.orgId, name, email, phone, roleId: role.id } });
        await db.teacher.update({
          where: { id: existing.id },
          data: { orgId: setup.orgId, employeeId, monthlySalary: salary, qualification: qualification || null, ...(joinedOn ? { joinedOn } : {}), ...(address ? { address } : {}), ...(classRow ? { classId: classRow.id } : {}) },
        });
        if (classRow) {
          await db.teacherClass.upsert({
            where: { teacherId_classId: { teacherId: existing.id, classId: classRow.id } },
            update: {},
            create: { teacherId: existing.id, classId: classRow.id },
          });
        }
        updated += 1;
      } else {
        let createdUser: { teacher: { id: string } | null };
        try {
          createdUser = await db.user.create({
            data: {
              orgId: setup.orgId,
              name,
              email,
              phone,
              password: setup.password,
              roleId: role.id,
              teacher: {
                create: {
                  orgId: setup.orgId,
                  employeeId,
                  monthlySalary: salary,
                  qualification: qualification || null,
                  ...(joinedOn ? { joinedOn } : {}),
                  ...(address ? { address } : {}),
                  ...(classRow ? { classId: classRow.id } : {}),
                },
              },
            },
            include: { teacher: true },
          });
        } catch (error) {
          throw onboardingImportWriteError(row, error);
        }
        if (classRow && createdUser.teacher) {
          await db.teacherClass.create({ data: { teacherId: createdUser.teacher.id, classId: classRow.id } });
        }
        created += 1;
      }
    } else {
      const existing = employeeId
        ? await db.staffMember.findFirst({ where: { orgId: setup.orgId, employeeId }, include: { user: true } })
        : await db.staffMember.findFirst({ where: { user: { OR: [{ email }, { phone }] } }, include: { user: true } });
      if (!employeeId) {
        do {
          employeeId = `S-${nextStaffEmployee}`;
          nextStaffEmployee += 1;
        } while (await db.staffMember.findFirst({ where: { orgId: setup.orgId, employeeId }, select: { id: true } }));
      }
      if (existing) {
        if (existing.userId) await db.user.update({ where: { id: existing.userId }, data: { orgId: setup.orgId, name, email, phone, roleId: role.id } });
        await db.staffMember.update({
          where: { id: existing.id },
          data: { orgId: setup.orgId, name, title: role.name, phone, employeeId, roleId: role.id, monthlySalary: salary, ...(joinedOn ? { joinedOn } : {}), ...(address ? { address } : {}), kind: "OFFICE", archivedAt: null },
        });
        updated += 1;
      } else {
        try {
          await db.user.create({
            data: {
              orgId: setup.orgId,
              name,
              email,
              phone,
              password: setup.password,
              roleId: role.id,
              staffMember: { create: { orgId: setup.orgId, name, title: role.name, phone, employeeId, roleId: role.id, monthlySalary: salary, ...(joinedOn ? { joinedOn } : {}), ...(address ? { address } : {}), kind: "OFFICE" } },
            },
          });
        } catch (error) {
          throw onboardingImportWriteError(row, error);
        }
        created += 1;
      }
    }
  }
  return { created, updated };
}

async function applyClassTeachers(db: OnboardingDb, rows: ImportRow[], orgId: string | null) {
  let updated = 0;
  for (const row of rows) {
    const klass = parseClass(sheetCell(row, "Class"))!;
    const classRow = await ensureClassForImport(db, klass);
    const employeeId = sheetCell(row, "Class teacher employee ID", "Employee ID", "Teacher employee ID");
    const teacherName = sheetCell(row, "Class teacher name", "Teacher name");
    const teacher = employeeId
      ? await db.teacher.findFirst({ where: { orgId, employeeId }, include: { user: true } })
      : await db.teacher.findFirst({ where: { user: { name: { equals: teacherName } } }, include: { user: true } });
    if (!teacher) throw new Error(rowError(row, "teacher no longer exists."));
    await db.teacher.update({ where: { id: teacher.id }, data: { classId: classRow.id } });
    await db.teacherClass.upsert({
      where: { teacherId_classId: { teacherId: teacher.id, classId: classRow.id } },
      update: {},
      create: { teacherId: teacher.id, classId: classRow.id },
    });
    updated += 1;
  }
  return { created: 0, updated };
}

async function applyOpeningBalances(db: OnboardingDb, rows: ImportRow[], coveragePeriod: string, orgId?: string | null) {
  let created = 0;
  let updated = 0;
  for (const row of rows) {
    const studentId = sheetCell(row, "Anekio student ID");
    const admissionNo = sheetCell(row, "Admission number", "Admission no");
    const student = await findStudentForOpening(db, { studentId, admissionNo, orgId: orgId ?? null });
    if (!student) throw new Error(rowError(row, "student no longer exists."));
    const parsedAmount = parseOpeningBacklogAmount(sheetCell(row, "Backlog invoice amount", "Opening due amount", "Previous system due", "Due amount", "Amount"));
    if ("error" in parsedAmount) throw new Error(rowError(row, parsedAmount.error));
    const dueDateText = sheetCell(row, "Due date");
    if (!validDate(dueDateText)) throw new Error(rowError(row, "due date must use YYYY-MM-DD."));
    const dueDate = new Date(`${dueDateText}T00:00:00`);
    const amount = parsedAmount.amount;
    const generatedThrough = coveragePeriod;
    const alreadyBilled = await db.feeInvoice.findFirst({
      where: { studentId: student.id, period: { gte: "0000-01", lte: coveragePeriod } },
      select: { period: true },
    });
    if (alreadyBilled) throw new Error(rowError(row, `${alreadyBilled.period} already has a monthly invoice. Do not include that month again in the opening balance.`));
    const existing = await db.feeInvoice.findUnique({
      where: { studentId_period: { studentId: student.id, period: "OPENING" } },
      include: { payments: true },
    });
    const paid = existing?.payments.reduce((total, payment) => total + payment.amount, 0) || 0;
    if (amount < paid) throw new Error(rowError(row, `backlog invoice amount cannot be below ₹${paid} already collected.`));
    if (existing) {
      await db.feeInvoice.update({
        where: { id: existing.id },
        data: {
          kind: "OPENING",
          generatedThrough,
          title: "Backlog invoice",
          amount,
          linesJson: JSON.stringify([{ label: "Backlog invoice", kind: "FLAT", amount }]),
          dueDate,
          classId: student.classId,
          status: amount <= paid ? InvoiceStatus.PAID : paid ? InvoiceStatus.PARTIAL : InvoiceStatus.DUE,
        },
      });
      updated += 1;
    } else if (amount > 0) {
      await db.feeInvoice.create({
        data: {
          orgId: orgId ?? null,
          studentId: student.id,
          classId: student.classId,
          period: "OPENING",
          kind: "OPENING",
          generatedThrough,
          title: "Backlog invoice",
          amount,
          linesJson: JSON.stringify([{ label: "Backlog invoice", kind: "FLAT", amount }]),
          dueDate,
          shareToken: randomUUID(),
          status: InvoiceStatus.DUE,
        },
      });
      created += 1;
    }
    const firstUnbilledPeriod = feePeriodAfter(generatedThrough);
    if (student.billingStartPeriod < firstUnbilledPeriod) {
      await db.student.update({
        where: { id: student.id },
        data: { billingStartPeriod: firstUnbilledPeriod },
      });
    }
  }
  return { created, updated };
}

async function applyAttendance(db: OnboardingDb, rows: ImportRow[], user: AccessUser) {
  let created = 0;
  let updated = 0;
  for (const row of rows) {
    const studentId = sheetCell(row, "Anekio student ID");
    const admissionNo = sheetCell(row, "Admission number", "Admission no");
    const student = studentId
      ? await db.student.findUnique({ where: { id: studentId }, select: { id: true } })
      : await db.student.findFirst({ where: { admissionNo, orgId: user.orgId ?? null }, select: { id: true } });
    if (!student) throw new Error(rowError(row, "student no longer exists."));
    for (const cell of attendanceCells(row)) {
      const status = parseAttendanceMark(cell.value);
      if (!status || status === "HOLIDAY") continue;
      const date = new Date(`${cell.date}T00:00:00`);
      const existing = await db.attendance.findUnique({ where: { studentId_date: { studentId: student.id, date } }, select: { id: true } });
      await db.attendance.upsert({
        where: { studentId_date: { studentId: student.id, date } },
        update: { status, markedById: user.id },
        create: { orgId: user.orgId ?? null, studentId: student.id, date, status, markedById: user.id },
      });
      if (existing) updated += 1;
      else created += 1;
    }
  }
  return { created, updated };
}

async function applyStaffAttendance(db: OnboardingDb, rows: ImportRow[], user: AccessUser) {
  let created = 0;
  let updated = 0;
  const people = await staffAttendancePeople(db);
  for (const row of rows) {
    const person = resolveStaffAttendancePerson(row, people);
    if (!person) throw new Error(rowError(row, "staff no longer exists."));
    for (const cell of attendanceCells(row)) {
      const status = parseAttendanceMark(cell.value);
      if (!status || status === "HOLIDAY") continue;
      const date = new Date(`${cell.date}T00:00:00`);
      const where = person.kind === "teacher"
        ? { teacherId_date: { teacherId: person.id, date } }
        : { staffId_date: { staffId: person.id, date } };
      const existing = await db.staffDay.findUnique({ where, select: { id: true } });
      await db.staffDay.upsert({
        where,
        update: { status, markedById: user.id, inAt: "", outAt: "", startTimeUsed: "", computedStatus: null },
        create: {
          orgId: user.orgId ?? null,
          teacherId: person.kind === "teacher" ? person.id : null,
          staffId: person.kind === "staff" ? person.id : null,
          date,
          status,
          markedById: user.id,
        },
      });
      if (existing) updated += 1;
      else created += 1;
    }
  }
  return { created, updated };
}

async function applyExamMarks(db: OnboardingDb, rows: ImportRow[], user: AccessUser) {
  let created = 0;
  let updated = 0;
  const [columns, students] = await Promise.all([
    examMarkColumns(),
    db.student.findMany({ select: { id: true, admissionNo: true, classId: true } }),
  ]);
  const studentsById = new Map(students.map((row) => [row.id, row]));
  const studentsByAdmission = new Map(students.map((row) => [row.admissionNo.toLowerCase(), row]));
  const touchedExamIds = new Set<string>();
  for (const row of rows) {
    const studentId = sheetCell(row, "Anekio student ID");
    const admissionNo = sheetCell(row, "Admission number", "Admission no").toLowerCase();
    const student = studentId ? studentsById.get(studentId) : studentsByAdmission.get(admissionNo);
    if (!student) throw new Error(rowError(row, "student no longer exists."));
    for (const cell of examMarkCells(row, columns)) {
      const parsed = examMarkValue(cell.value);
      if (!parsed || parsed.skip) continue;
      const existing = await db.examResult.findUnique({ where: { examId_studentId: { examId: cell.examId, studentId: student.id } }, select: { id: true } });
      await db.examResult.upsert({
        where: { examId_studentId: { examId: cell.examId, studentId: student.id } },
        update: { marks: parsed.absent ? 0 : parsed.marks, absent: parsed.absent, remarks: sheetCell(row, "Remarks") || null },
        create: {
          orgId: user.orgId ?? null,
          examId: cell.examId,
          studentId: student.id,
          marks: parsed.absent ? 0 : parsed.marks,
          absent: parsed.absent,
          remarks: sheetCell(row, "Remarks") || null,
        },
      });
      touchedExamIds.add(cell.examId);
      if (existing) updated += 1;
      else created += 1;
    }
  }
  if (touchedExamIds.size) {
    await db.exam.updateMany({
      where: { id: { in: [...touchedExamIds] }, workflowStatus: { in: [ExamWorkflowStatus.SCHEDULED, ExamWorkflowStatus.IN_PROGRESS] } },
      data: { workflowStatus: ExamWorkflowStatus.MARKS_DRAFT, marksGrantedAt: new Date(), conductedAt: new Date() },
    });
  }
  return { created, updated };
}

function onboardingApplyErrorMessage(error: unknown) {
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === "P2025" || error.code === "P2003") {
      return "Import could not be applied because one of the linked records changed after review. Download the latest template, review it again, and apply.";
    }
    if (error.code === "P2028") {
      return "Import took too long to apply. Try again, or split the file into smaller date ranges if it still fails.";
    }
  }
  const message = error instanceof Error ? error.message : "";
  if (/Record not found/i.test(message)) {
    return "Import could not be applied because one of the linked records changed after review. Download the latest template, review it again, and apply.";
  }
  if (/Transaction.*not found|closed transaction|timed out/i.test(message)) {
    return "Import took too long to apply. Try again, or split the file into smaller date ranges if it still fails.";
  }
  return message || "Import failed.";
}

export async function applyOnboardingImport(user: AccessUser, input: { batchId?: string }) {
  need(user);
  const batchId = String(input.batchId || "");
  const orgId = await onboardingOrgId(user);
  const batch = await prisma.schoolOnboardingImport.findUnique({ where: { id: batchId } });
  if (!batch) throw new Error("Import review not found.");
  if (batch.orgId && batch.orgId !== orgId) throw new Error("Import review not found.");
  if (batch.status === "APPLIED") throw new Error("This import was already applied.");
  const errors = JSON.parse(batch.errorsJson) as string[];
  if (errors.length && batch.status !== "FAILED") throw new Error("Fix the review errors and upload the template again.");
  const kind = asKind(batch.kind);
  const savedRows = JSON.parse(batch.rowsJson) as ImportRow[] | { rows: ImportRow[]; coveragePeriod: string };
  const rows = Array.isArray(savedRows) ? savedRows : savedRows.rows;
  if (kind === "opening_balances" && (Array.isArray(savedRows) || !/^\d{4}-(0[1-9]|1[0-2])$/.test(savedRows.coveragePeriod))) {
    throw new Error("This fee review is outdated. Upload the current first-time fee sheet again.");
  }
  if (kind === "opening_balances") {
    const documentErrors = await openingDocumentErrors(orgId);
    if (documentErrors.length) throw new Error(documentErrors.join(" "));
  }
  try {
    const codes = kind === "students" || kind === "teachers" ? await nextCodes(orgId) : null;
    const peopleSetup = kind === "students"
      ? { orgId, roleId: await roleIdBySlug("PARENT"), password: await bcrypt.hash("12345", 10), admission: codes!.admission }
      : kind === "teachers"
        ? { orgId, password: await bcrypt.hash("12345", 10), employee: codes!.employee, staffEmployee: codes!.staffEmployee, roles: await staffImportRoles() }
        : null;
    const result = await prisma.$transaction(async (db) => kind === "classes"
      ? applyClasses(db, rows)
      : kind === "students"
        ? applyStudents(db, rows, peopleSetup as { orgId: string; roleId: string; password: string; admission: number })
        : kind === "teachers"
          ? applyTeachers(db, rows, peopleSetup as { orgId: string; password: string; employee: number; staffEmployee: number; roles: StaffImportRole[] })
          : kind === "attendance"
            ? applyAttendance(db, rows, user)
            : kind === "staff_attendance"
              ? applyStaffAttendance(db, rows, user)
              : kind === "exam_marks"
                ? applyExamMarks(db, rows, user)
          : kind === "class_teachers"
            ? applyClassTeachers(db, rows, orgId)
            : applyOpeningBalances(db, rows, (savedRows as { coveragePeriod: string }).coveragePeriod, orgId), { maxWait: 10_000, timeout: 60_000 });
    await prisma.schoolOnboardingImport.update({
      where: { id: batch.id },
      data: { status: "APPLIED", appliedAt: new Date(), createdCount: result.created, updatedCount: result.updated, errorsJson: "[]" },
    });
    return { ...result, batchId: batch.id };
  } catch (error) {
    const message = onboardingApplyErrorMessage(error);
    await prisma.schoolOnboardingImport.update({
      where: { id: batch.id },
      data: { status: "FAILED", errorsJson: JSON.stringify([message]) },
    });
    throw new Error(message);
  }
}

export async function saveOnboardingPlan(user: AccessUser, input: { modules?: unknown }) {
  need(user);
  const requested = Array.isArray(input.modules) ? input.modules.map(String) : [];
  const state = await ensureOnboardingState(user);
  const current = parsePlanState(state.selectedModulesJson);
  const modules = requested.length ? DEFAULT_ONBOARDING_MODULES : current.modules;
  const selectedModulesJson = serializePlanState({ modules, manualSteps: current.manualSteps, configuredSteps: current.configuredSteps });
  const orgId = await onboardingOrgId(user);
  const saved = await writeOnboardingState(state.id, orgId, { selectedModulesJson });
  return parsePlanState(saved.selectedModulesJson);
}

export async function toggleOnboardingStep(user: AccessUser, input: { key?: unknown; complete?: unknown }) {
  need(user);
  const key = String(input.key || "") as OnboardingStepKey;
  if (!ONBOARDING_STEP_KEYS.has(key)) throw new Error("Choose a valid onboarding step.");
  const state = await ensureOnboardingState(user);
  const current = parsePlanState(state.selectedModulesJson);
  const manual = new Set(current.manualSteps);
  if (input.complete === false) manual.delete(key);
  else manual.add(key);
  const orgId = await onboardingOrgId(user);
  const saved = await writeOnboardingState(state.id, orgId, {
    selectedModulesJson: serializePlanState({ modules: current.modules, manualSteps: [...manual], configuredSteps: current.configuredSteps }),
  });
  return parsePlanState(saved.selectedModulesJson);
}

/** Defaults shown by the UI are not setup completion until the school explicitly saves them. */
export async function markOnboardingConfigured(user: AccessUser, key: "working_days" | `sessions:${string}` | `exam_plan:${string}`) {
  const state = await ensureOnboardingState(user);
  const current = parsePlanState(state.selectedModulesJson);
  const orgId = await onboardingOrgId(user);
  await writeOnboardingState(state.id, orgId, {
    selectedModulesJson: serializePlanState({ ...current, configuredSteps: [...current.configuredSteps, key] }),
  });
}

export function schoolIdentityComplete(school: {
  name: string;
  address: string;
  phone: string;
  email: string;
  logoPath: string;
  signPath: string;
} | null) {
  if (!school) return false;
  const name = school.name.trim();
  return Boolean(
    name && name !== "School" && name !== "Anekio School" &&
    school.address.trim() && school.phone.trim() && school.email.trim() &&
    school.logoPath.trim() && school.signPath.trim()
  );
}

export function schoolSpecificSetupComplete(input: {
  configuredSteps: string[];
  session: { id: string; examPlanJson: string } | null;
  weekdays: string | null | undefined;
  teachingPeriodCount: number;
}) {
  const configured = new Set(input.configuredSteps);
  const plan = parseExamPlan(input.session?.examPlanJson, false);
  return {
    sessions: Boolean(input.session && configured.has(`sessions:${input.session.id}`)),
    workingDays: configured.has("working_days") && parseWeekdays(input.weekdays).length > 0 && input.teachingPeriodCount > 0,
    examPlan: Boolean(input.session && configured.has(`exam_plan:${input.session.id}`)) &&
      plan.length > 0 && examPlanWeight(plan) === 100 && plan.every((row) => row.maxMarks > 0 && row.expectedPeriod),
  };
}

export async function onboardingBundle(user: AccessUser) {
  need(user);
  const state = await ensureOnboardingState(user);
  const orgId = state.orgId || (user.orgId ?? "");
  const importantDocumentTypes = [
    "FEE_INVOICE",
    "PAYMENT_RECEIPT",
    "STUDENT_ID",
    "ADMIT_CARD",
    "ADMISSION_CONFIRMATION",
    "EMPLOYEE_ID",
    "SALARY_SLIP",
    "REPORT_CARD",
    "EXAM_DATE_SHEET",
    "CONSOLIDATED_REPORT",
  ];
  const [school, classCount, studentCount, teacherCount, staffMemberCount, attendanceCount, staffAttendanceCount, currentSession, holidayCount, examCount, examMarkCount, templateCount, openingCount, documentTemplates, latestImports, latestSheets] = await Promise.all([
    prisma.schoolConfig.findUnique({
      where: { id: "school" },
      select: {
        name: true,
        address: true,
        phone: true,
        email: true,
        logoPath: true,
        signPath: true,
        weekdays: true,
        upiId: true,
        bankName: true,
        bankAccountName: true,
        bankAccountNumber: true,
        bankIfsc: true,
        payGateway: true,
        razorpayKeyId: true,
        cashfreeAppId: true,
        billdeskMerchantId: true,
        admissionFormJson: true,
      },
    }),
    prisma.class.count({ where: { archivedAt: null } }),
    prisma.student.count(),
    prisma.teacher.count(),
    prisma.staffMember.count({ where: { archivedAt: null } }),
    prisma.attendance.count(),
    prisma.staffDay.count(),
    prisma.schoolSession.findFirst({ where: { current: true }, select: { id: true, examPlanJson: true } }),
    prisma.schoolHoliday.count(),
    prisma.examSeries.count({ where: { exams: { some: {} } } }),
    prisma.examResult.count(),
    prisma.feeTemplate.count(),
    prisma.feeInvoice.count({ where: { period: "OPENING" } }),
    prisma.documentTemplate.findMany({ where: { orgId, status: "ACTIVE", type: { in: importantDocumentTypes } }, select: { type: true } }),
    prisma.schoolOnboardingImport.findMany({ where: { stateId: state.id }, orderBy: { createdAt: "desc" }, take: 8 }),
    prisma.onboardingGoogleSheet.findMany({ where: { stateId: state.id }, orderBy: { createdAt: "desc" }, take: 8 }),
  ]);
  const planState = parsePlanState(state?.selectedModulesJson);
  const modules = planState.modules;
  const manualDone = new Set(planState.manualSteps);
  const importDone = new Set(latestImports.filter((row) => row.status === "APPLIED").map((row) => row.kind));
  const hasBank = Boolean(school?.bankName && school.bankAccountName && school.bankAccountNumber && school.bankIfsc);
  const hasUpi = Boolean(school?.upiId);
  const hasGateway =
    school?.payGateway === "RAZORPAY" ? Boolean(school.razorpayKeyId)
      : school?.payGateway === "CASHFREE" ? Boolean(school.cashfreeAppId)
        : school?.payGateway === "BILLDESK" ? Boolean(school.billdeskMerchantId)
          : false;
  const savedDocumentTypes = new Set(documentTemplates.map((row) => row.type));
  const hasInvoiceDocument = savedDocumentTypes.has("FEE_INVOICE");
  const hasReceiptDocument = savedDocumentTypes.has("PAYMENT_RECEIPT");
  const hasFeeDocuments = hasInvoiceDocument && hasReceiptDocument;
  const hasStudentIdDocument = savedDocumentTypes.has("STUDENT_ID");
  const hasStudentAdmitCardDocument = savedDocumentTypes.has("ADMIT_CARD");
  const hasAdmissionConfirmationDocument = savedDocumentTypes.has("ADMISSION_CONFIRMATION");
  const hasStaffIdDocument = savedDocumentTypes.has("EMPLOYEE_ID");
  const hasSalarySlipDocument = savedDocumentTypes.has("SALARY_SLIP");
  const hasReportCardDocument = savedDocumentTypes.has("REPORT_CARD");
  const hasExamDateSheetDocument = savedDocumentTypes.has("EXAM_DATE_SHEET");
  const hasConsolidatedReportDocument = savedDocumentTypes.has("CONSOLIDATED_REPORT");
  const hasImportantDocuments = importantDocumentTypes.every((type) => savedDocumentTypes.has(type));
  const staffCount = teacherCount + staffMemberCount;
  const periodCount = await prisma.period.count({ where: { isBreak: false } });
  const schoolSetup = schoolSpecificSetupComplete({ configuredSteps: planState.configuredSteps, session: currentSession, weekdays: school?.weekdays, teachingPeriodCount: periodCount });
  const hasWorkingDays = schoolSetup.workingDays;
  const hasAdmissionFormSetup = admissionFormFields(school?.admissionFormJson).length > 0;
  const hasHolidayCalendar = holidayCount > 0 || manualDone.has("holiday_calendar");
  const hasStudentAttendanceHistory = attendanceCount > 0 || importDone.has("attendance");
  const hasStaffAttendanceHistory = staffAttendanceCount > 0 || importDone.has("staff_attendance");
  const hasExamPlan = schoolSetup.examPlan;
  const hasExamHistory = examCount > 0;
  const hasExamMarksHistory = examMarkCount > 0 || importDone.has("exam_marks");
  const step = (
    key: OnboardingStepKey,
    area: OnboardingSetupArea,
    number: number,
    title: string,
    body: string,
    complete: boolean,
    blocked = false,
    missingReason = "",
    target: OnboardingTarget = { href: "/school", label: "Open setup" },
    manualAllowed = true,
  ) => ({
    key,
    area,
    number,
    title,
    body,
    target,
    dataComplete: complete,
    manualComplete: manualAllowed && manualDone.has(key),
    missingReason,
    manualAllowed,
    status: complete || (manualAllowed && manualDone.has(key)) ? "complete" : blocked ? "blocked" : "ready",
  });
  const steps = [
    step("school", "school", 1, "Identity & brand assets", "Add the school name, address, contact details, logo, and principal signature. Stamp is optional.", schoolIdentityComplete(school), false, "Save the school details, logo, and principal signature to complete this step.", { href: "/school?tab=identity", label: "Open identity" }, false),
    step("sessions", "school", 2, "Sessions", "Confirm or create this school's current academic session.", schoolSetup.sessions, false, "Confirm the school's current session; an automatically suggested session is not complete setup.", { href: "/school?tab=sessions", label: "Open sessions" }, false),
    step("classes", "school", 3, "Classes", "Create classes in School setup, or let student and staff sheets create valid class labels like 1-A.", classCount > 0, false, "Classes connect students, teachers, fees, attendance, exams, and document batches.", { href: "/school?tab=classes", label: "Open classes" }),
    step("working_days", "school", 4, "Clock", "Choose school days and bell times before attendance templates are generated.", hasWorkingDays, !hasWorkingDays, "Attendance uses Clock working days to prefill school days and weekly offs.", { href: "/school?tab=clock", label: "Open clock" }, false),
    step("holiday_calendar", "school", 5, "Calendar", "Add or import holidays before attendance templates are generated.", hasHolidayCalendar, !hasHolidayCalendar, "Attendance imports need holidays marked first so those dates are skipped.", { href: "/school?tab=calendar", label: "Open calendar" }),
    step("admission_form", "teaching", 6, "Admission form setup", "Choose which admission fields are shown and required before preparing the student import sheet.", hasAdmissionFormSetup, false, "Save this school's admission form to confirm its fields before importing families.", { href: "/school?tab=forms", label: "Open admission form" }, false),
    step("students", "teaching", 7, "Students and parents", "Download a fresh sheet using this school's admission form, then import family records.", studentCount > 0 || importDone.has("students"), !hasAdmissionFormSetup, "Confirm the admission form first so the sheet shows the right required and optional fields.", { href: "/people", label: "Open students" }),
    step("student_id_document", "teaching", 7, "Student ID card template", "Save and publish the student ID card template.", hasStudentIdDocument, !hasStudentIdDocument, "Student ID cards need a published template before the office can issue cards.", { href: "/school?tab=documents&document=STUDENT_ID", label: "Open student ID template" }, false),
    step("student_admit_card_document", "teaching", 8, "Student admit card template", "Save and publish the student admit card template.", hasStudentAdmitCardDocument, !hasStudentAdmitCardDocument, "Admit cards need a published template before exams can issue hall tickets.", { href: "/school?tab=documents&document=ADMIT_CARD", label: "Open admit card template" }, false),
    step("admission_confirmation_document", "teaching", 9, "Admission confirmation template", "Save and publish the admission confirmation template.", hasAdmissionConfirmationDocument, !hasAdmissionConfirmationDocument, "Admission confirmation needs a published template before admitted families can receive it.", { href: "/school?tab=documents&document=ADMISSION_CONFIRMATION", label: "Open admission template" }, false),
    step("teachers", "teaching", 10, "Staff", "Import staff records with role and class-teacher columns when needed.", staffCount > 0 || importDone.has("teachers"), false, "Staff are needed for class ownership, timetable, attendance, payroll, and documents.", { href: "/staff", label: "Open staff" }),
    step("staff_id_document", "teaching", 11, "Staff ID card template", "Save and publish the staff ID card template.", hasStaffIdDocument, !hasStaffIdDocument, "Staff ID cards need a published template before the office can issue cards.", { href: "/school?tab=documents&document=EMPLOYEE_ID", label: "Open staff ID template" }, false),
    step("salary_slip_document", "teaching", 12, "Salary slip template", "Save and publish the salary slip template.", hasSalarySlipDocument, !hasSalarySlipDocument, "Salary slips need a published template before payroll documents can be issued.", { href: "/school?tab=documents&document=SALARY_SLIP", label: "Open salary slip template" }, false),
    step("attendance", "teaching", 13, "Student attendance history", "Import old student attendance with class sheets, holiday calendar days, and dates through today.", hasStudentAttendanceHistory && hasWorkingDays && hasHolidayCalendar, studentCount === 0 || classCount === 0 || !hasWorkingDays || !hasHolidayCalendar, "Student attendance history needs classes, students, working days, and the holiday calendar first.", { href: "/attendance", label: "Open student attendance" }),
    step("staff_attendance", "teaching", 14, "Staff attendance history", "Import old staff attendance with holidays already marked through today.", hasStaffAttendanceHistory && hasWorkingDays && hasHolidayCalendar, staffCount === 0 || !hasWorkingDays || !hasHolidayCalendar, "Staff attendance history needs staff, working days, and the holiday calendar first.", { href: "/staff", label: "Open staff attendance" }),
    step("exam_plan", "exams", 15, "This year's exam plan", "Confirm and save this school's exam sittings, weights, marks, and expected periods.", hasExamPlan, classCount === 0, "Create classes first, then save this school's exam plan; suggested sittings are not complete setup.", { href: "/school?tab=exams", label: "Open year plan" }, false),
    step("exam_marks", "exams", 16, "Exam marks history", "Download the marks sheet generated from saved exam history, then upload completed marks for review.", hasExamMarksHistory, studentCount === 0 || !hasExamPlan || !hasExamHistory, "Save this year's exam plan, schedule past exams, and add students before importing marks.", { href: "/exams", label: "Open marks import" }),
    step("report_card_document", "exams", 17, "Report card template", "Save and publish the report card template.", hasReportCardDocument, !hasReportCardDocument, "Report cards need a published template before results can be shared.", { href: "/school?tab=documents&document=REPORT_CARD", label: "Open report card template" }, false),
    step("exam_date_sheet_document", "exams", 18, "Exam date sheet template", "Save and publish the exam date sheet template.", hasExamDateSheetDocument, !hasExamDateSheetDocument, "Exam date sheets need a published template before schedules can be issued.", { href: "/school?tab=documents&document=EXAM_DATE_SHEET", label: "Open date sheet template" }, false),
    step("consolidated_report_document", "exams", 19, "Consolidated report card template", "Save and publish the consolidated report card template.", hasConsolidatedReportDocument, !hasConsolidatedReportDocument, "Consolidated report cards need a published template before full-session results can be shared.", { href: "/school?tab=documents&document=CONSOLIDATED_REPORT", label: "Open consolidated report template" }, false),
    step("collection_account", "money", 20, "Bank and collection account", "Add UPI, bank account, or the school's payment gateway before asking parents to pay.", hasUpi || hasBank || hasGateway, false, "Collection details appear on pay pages, invoices, receipts, and office collection workflows.", { href: "/school?tab=collect", label: "Open collection setup" }),
    step("fee_invoice_document", "money", 21, "Fee invoice template", "Save and publish the fee invoice template before the first billing cycle.", hasInvoiceDocument, !hasInvoiceDocument, "Fee invoice template is required before fee setup can continue.", { href: "/school?tab=documents&document=FEE_INVOICE", label: "Open invoice template" }, false),
    step("payment_receipt_document", "money", 22, "Payment receipt template", "Save and publish the payment receipt template before the first billing cycle.", hasReceiptDocument, !hasReceiptDocument, "Payment receipt template is required before fee setup can continue.", { href: "/school?tab=documents&document=PAYMENT_RECEIPT", label: "Open receipt template" }, false),
    step("opening_balances", "money", 23, "First time fee import", "Enter one unpaid amount per student through the current month. Monthly billing begins the following month.", importDone.has("opening_balances") || (studentCount > 0 && openingCount >= studentCount), studentCount === 0 || !hasFeeDocuments, studentCount === 0 ? "Students are required before first-time fee import." : !hasFeeDocuments ? "Publish the fee invoice and payment receipt templates before first-time fee import." : "Opening balances prevent missed old dues and duplicate first invoices.", { href: "/fees", label: "Open fees" }),
    step("recurring_fees", "money", 24, "Recurring fee rules", "Set class fee ranges. New invoices begin after each student's imported cut-off month.", templateCount > 0, classCount === 0, "Recurring fee rules are needed before monthly billing can run correctly.", { href: "/fees", label: "Open fees" }),
    step("review", "money", 25, "Review and launch", "Check counts, spot-check families, fees, exams, staff, and templates, then hand the workspace to the school.", false, classCount === 0 || studentCount === 0 || !hasImportantDocuments, !hasImportantDocuments ? "Save and publish the important student, staff, exam, invoice, and receipt templates before launch review." : "Review catches missing setup before the school starts using the workspace live.", { href: "/school", label: "Open school setup" }, false),
  ];
  steps.forEach((row, index) => { row.number = index + 1; });
  const required = steps;
  const completed = required.filter((row) => row.status === "complete").length;
  const forms = await configuredImportForms();
  const studentColumns = sheetColumnSummary(studentImportHeaders(forms.admission));
  const staffColumns = sheetColumnSummary(staffImportHeaders(forms.staff));
  return {
    modules,
    progress: { completed, total: required.length, percent: required.length ? Math.round((completed / required.length) * 100) : 0 },
    counts: { classes: classCount, students: studentCount, teachers: staffCount, openingBalances: openingCount, feeTemplates: templateCount },
    steps,
    templates: (IMPORT_KINDS.filter((kind) => kind !== "classes" && kind !== "class_teachers") as ImportKind[]).map((kind) => ({
      kind,
      title: TEMPLATE_DETAILS[kind].title,
      fileName: xlsxFileName(kind),
      columns: kind === "students" ? studentColumns : kind === "teachers" ? staffColumns : "",
      disabled: (kind === "students" && !hasAdmissionFormSetup) || (kind === "opening_balances" && (studentCount === 0 || !hasFeeDocuments)) || (kind === "attendance" && (studentCount === 0 || classCount === 0 || !hasWorkingDays || !hasHolidayCalendar)) || (kind === "staff_attendance" && (staffCount === 0 || !hasWorkingDays || !hasHolidayCalendar)) || (kind === "exam_marks" && (studentCount === 0 || !hasExamPlan || !hasExamHistory)),
      prerequisite: kind === "students" ? "Save this school's admission form in School setup → Forms & Templates" : kind === "opening_balances" ? (studentCount === 0 ? "Students" : !hasFeeDocuments ? "Fee invoice and payment receipt templates" : "Students") : kind === "attendance" ? "Classes, students, working days, and holiday calendar" : kind === "staff_attendance" ? "Staff, working days, and holiday calendar" : kind === "exam_marks" ? "Year exam plan, setup exams, and students" : "Class labels can be created from the sheet",
    })),
    imports: latestImports.map((row) => ({
      id: row.id,
      kind: row.kind,
      fileName: row.fileName,
      status: row.status,
      created: row.createdCount,
      updated: row.updatedCount,
      createdAt: row.createdAt.toISOString(),
      appliedAt: row.appliedAt?.toISOString() || "",
      errors: JSON.parse(row.errorsJson) as string[],
    })),
    googleSheets: latestSheets.map((row) => ({
      id: row.id,
      kind: row.kind,
      name: row.name,
      webViewLink: row.webViewLink,
      createdAt: row.createdAt.toISOString(),
      reviewedAt: row.reviewedAt?.toISOString() || "",
      importId: row.importId || "",
    })),
  };
}
