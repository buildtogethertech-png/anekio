import { examTimes } from "./exam-time";
import bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";
import { FeeLineKind, InvoiceStatus, PaperType, PathTag } from "@prisma/client";
import { sendAisensyWhatsApp, getAisensyConfig } from "./aisensy";
import { can, type AccessUser } from "./permissions";
import { prisma } from "./prisma";
import { roleIdBySlug } from "./roles";
import { issueTemplateMonthlyInvoices, reminderCopy } from "./fee-run";
import {
  catalogAddOnKind,
  catalogAddOnLabel,
  classAddOnKind,
  classAddOnKey,
  classAllFeeLines,
  feeLineTotal,
  feePeriod,
  invoiceBalance,
  invoiceLateMetadata,
  replaceInvoiceLateMetadata,
  feeTemplateLateWrite,
  parseCatalogAddOnKind,
  parseFeeCatalogState,
  clampFeeDueDay,
  studentHasClassAddOn,
  parseFeeLines,
  periodFromDate,
  serializeFeeCatalogState,
  lateStampFromSetup,
  type FeeCatalogItem,
} from "./fees";
import { normalizeMobile } from "./phone";
import { getResendConfig, sendResendEmail } from "./resend";
import { cell, parseClassLabel, parseCsv, parseDob, parsePathTags } from "./sheet";
import { ensureSchoolSessions, startNextSchoolSession, updateCurrentSchoolSession } from "./school-session";
import { markOnboardingConfigured } from "./onboarding";
import { todayJoinedOn } from "./staff-profile";
import { feePayUrl } from "./utils";
import { addDays, paperSetterId, ymd } from "./exams";
import { validateExamMark } from "./exam-marks";
import {
  adminCanPublish,
  adminCanReview,
  assertExamTransition,
  canGrantMarksEntry,
  grantedEvaluatorIds,
  teacherCanEditMarks,
  teacherMayEnterMarks,
  teacherMayTakeExam,
  teacherCanTakeExam, teacherMarksBlock } from "./exam-workflow";
import {
  loadExamNoticeCtx,
  notifyExamConducted,
  notifyMarksApproved,
  notifyMarksCorrection,
  notifyMarksGranted,
  notifyMarksReminder,
  notifyMarksSubmitted,
  notifyPaperHandedOver,
  notifyPaperReceived,
  notifyPaperReturned,
  notifyPaperSubmitted,
  notifyResultsPublished,
  notifySeriesAssigned,
  notifyExamReassigned,
} from "./exam-events";
import { eligibleTeacherIdsForExam, ensureExamEvaluator, teacherIdsBySubjectName } from "./exam-evaluators";
import { isQuestionPaperFile } from "./uploads";
import { assignStudentRollNumber } from "./student-rolls";
function need(user: AccessUser, ...keys: string[]) {
  if (!keys.some((k) => can(user, k))) throw new Error("No access.");
}

function normalizeFeePeriod(value: unknown) {
  const text = String(value || "").trim();
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(text) ? text : "";
}

function monthsBetween(startsPeriod: string, endsPeriod: string) {
  const [startYear, startMonth] = startsPeriod.split("-").map(Number);
  const [endYear, endMonth] = endsPeriod.split("-").map(Number);
  const months: { period: string; year: number; monthIndex: number }[] = [];
  let year = startYear;
  let monthIndex = startMonth - 1;
  const end = endYear * 12 + (endMonth - 1);
  while (year * 12 + monthIndex <= end) {
    months.push({ period: feePeriod(year, monthIndex), year, monthIndex });
    monthIndex += 1;
    if (monthIndex > 11) {
      monthIndex = 0;
      year += 1;
    }
  }
  return months;
}


async function needExamClass(user: AccessUser, classId: string, mode: "mark" | "run" = "mark") {
  need(user, "exams.edit", "marks.enter", "exams.teach");
  if (user.portal === "OFFICE" && can(user, "exams.edit")) return;
  const teacher = await prisma.teacher.findUnique({
    where: { userId: user.id },
    include: { subjects: true, classes: true },
  });
  if (!teacher) throw new Error("Not your class");
  const linked =
    teacher.classId === classId ||
    teacher.subjects.some((s) => s.classId === classId) ||
    teacher.classes.some((c) => c.classId === classId);
  const assigned = linked
    ? 1
    : await prisma.exam.count({
        where: {
          classId,
          OR: [
            { teacherId: teacher.id },
            { setterId: teacher.id },
            { evaluators: { some: { teacherId: teacher.id } } },
          ],
        },
      });
  if (!assigned) throw new Error("Not your class");
  if (mode === "run" && teacher.classId !== classId) {
    throw new Error("Only the class teacher or admin can do that");
  }
}

function examDateFields(paper: {
  date: string;
  paperDueOn?: string;
  copiesDueOn?: string;
  resultOn?: string;
  teacherId?: string | null;
  setterId?: string | null;
}) {
  // Order is fixed: question paper ready → exam day → copies checked.
  const examDay = String(paper.date || "").slice(0, 10);
  if (paper.paperDueOn && examDay && paper.paperDueOn.slice(0, 10) > examDay) {
    throw new Error("Paper ready date must be before the exam date.");
  }
  if (paper.copiesDueOn && examDay && paper.copiesDueOn.slice(0, 10) < examDay) {
    throw new Error("Checking due date must be after the exam date.");
  }
  const teacherId = paper.teacherId || null;
  return {
    date: new Date(paper.date),
    paperDueOn: paper.paperDueOn ? new Date(paper.paperDueOn) : null,
    copiesDueOn: paper.copiesDueOn ? new Date(paper.copiesDueOn) : null,
    resultOn: paper.resultOn ? new Date(paper.resultOn) : null,
    teacherId,
    setterId: paper.setterId || teacherId,
  };
}

export async function startNextSchoolSessionCore(user: AccessUser) {
  need(user, "school.edit");
  const session = await startNextSchoolSession();
  await markOnboardingConfigured(user, `sessions:${session.id}`);
}

export async function saveFeeAcademicSessionCore(
  user: AccessUser,
  input: {
    label?: string;
    startsOn?: string;
    endsOn?: string;
    sessionName?: string;
    sessionStart?: string;
    sessionEnd?: string;
    dueDay?: number;
  }
) {
  need(user, "fees.configure");
  const startsOn = String(input.startsOn ?? input.sessionStart ?? "").trim();
  const endsOn = String(input.endsOn ?? input.sessionEnd ?? "").trim();
  if (!startsOn || !endsOn) throw new Error("Pick the session start and end.");
  if (endsOn < startsOn) throw new Error("Session end must be after session start.");
  const session = await updateCurrentSchoolSession({
    label: input.label ?? input.sessionName,
    startsOn,
    endsOn,
  });
  await markOnboardingConfigured(user, `sessions:${session.id}`);
  if (input.dueDay == null || String(input.dueDay).trim() === "") {
    const catalog = await loadFeeCatalog();
    return { ...session, dueDay: catalog.dueDay };
  }
  const dueDay = clampFeeDueDay(input.dueDay);
  const catalog = await loadFeeCatalog();
  await writeFeeCatalog(user, { ...catalog, dueDay });
  await prisma.feeTemplate.updateMany({
    where: { sessionId: session.id },
    data: { dueDay },
  });
  return { ...session, dueDay };
}

async function refreshInvoiceLateRule(
  where: { templateId?: string; orgId: string | null },
  rule: Parameters<typeof invoiceLateMetadata>[0]
) {
  const invoices = await prisma.feeInvoice.findMany({
    where,
    select: { id: true, period: true, metadataJson: true },
  });
  for (const invoice of invoices) {
    if (!normalizeFeePeriod(invoice.period)) continue;
    await prisma.feeInvoice.update({
      where: { id: invoice.id },
      data: { metadataJson: replaceInvoiceLateMetadata(invoice.metadataJson, rule) },
    });
  }
}

export async function saveFeeTemplateCore(
  user: AccessUser,
  input: {
    templateId?: string;
    classId: string;
    sessionId?: string;
    name?: string;
    startsPeriod?: string;
    endsPeriod?: string;
    dueDay?: number;
    lateKind?: string;
    lateGraceDays?: number;
    lateAmount?: number;
    lateIntervalCount?: number;
    lateIntervalUnit?: string;
    lines?: { label?: string; kind?: string; amount?: number; scope?: string }[];
  }
) {
  need(user, "fees.configure");
  const classId = String(input.classId || "");
  if (!classId) throw new Error("Class required");
  const templateId = String(input.templateId || "");
  const { current } = await ensureSchoolSessions();
  const sessionId = String(input.sessionId || current.id);
  const name = String(input.name || "Monthly fee").trim() || "Monthly fee";
  const startsPeriod = normalizeFeePeriod(input.startsPeriod) || current.startsOn.slice(0, 7);
  const endsPeriod = normalizeFeePeriod(input.endsPeriod) || current.endsOn.slice(0, 7);
  if (startsPeriod > endsPeriod) throw new Error("Start month must be before end month");
  const catalogDue = parseFeeCatalogState(
    (await prisma.schoolConfig.findUnique({ where: { id: "school" }, select: { feeCatalogJson: true } }))?.feeCatalogJson
  ).dueDay;
  const dueDay = clampFeeDueDay(input.dueDay != null && String(input.dueDay).trim() !== "" ? input.dueDay : catalogDue);
  const hasLate = input.lateKind != null && String(input.lateKind).trim() !== "";
  const rawKind = String(input.lateKind || "NONE").toUpperCase();
  const lateKind =
    rawKind === "STATIC" || rawKind === "DAILY" || rawKind === "RECURRING" || rawKind === "PERCENT" ? rawKind : "NONE";
  const lateGraceDays = lateKind === "NONE" ? 0 : Math.max(0, Math.round(Number(input.lateGraceDays || 0)));
  const lateAmount = lateKind === "NONE" ? 0 : Math.max(0, Number(input.lateAmount || 0));
  const lateIntervalCount =
    lateKind === "RECURRING" || lateKind === "PERCENT" ? Math.max(1, Math.round(Number(input.lateIntervalCount || 1))) : 1;
  const lateIntervalUnit =
    (lateKind === "RECURRING" || lateKind === "PERCENT") && String(input.lateIntervalUnit || "DAY").toUpperCase() === "MONTH"
      ? "MONTH"
      : "DAY";
  const lateStamp = {
    lateKind,
    lateGraceDays,
    lateAmount: Math.round(lateAmount),
    lateIntervalCount,
    lateIntervalUnit,
  };
  const catalogLate = parseFeeCatalogState(
    (await prisma.schoolConfig.findUnique({ where: { id: "school" }, select: { feeCatalogJson: true } }))?.feeCatalogJson
  ).late;
  const inheritedLate = lateStampFromSetup(catalogLate).stamp;
  const drafted = (Array.isArray(input.lines) ? input.lines : parseFeeLines(JSON.stringify(input.lines || []))).map((line) => {
    const scope = String(line.scope || "ALL").toUpperCase() === "ADD_ON" ? "ADD_ON" : "ALL";
    return {
      label: String(line.label || "").trim() || (scope === "ALL" ? "Line" : ""),
      kind: (line.kind === "PERCENT" ? "PERCENT" : "FLAT") as FeeLineKind,
      amount: Math.max(0, Math.round(Number(line.amount) || 0)),
      scope,
    };
  });
  const allLines = drafted.filter((line) => line.scope === "ALL");
  const seenAddOns = new Set<string>();
  const addOnLines = drafted.filter((line) => {
    if (line.scope !== "ADD_ON" || !line.label || line.amount <= 0) return false;
    const key = classAddOnKey(line.label);
    if (seenAddOns.has(key)) return false;
    seenAddOns.add(key);
    return true;
  });
  if (!allLines.length) throw new Error("Add at least one class charge");
  const lines = [...allLines, ...addOnLines].map((line, i) => ({
    label: line.label || "Line",
    kind: line.kind,
    amount: line.amount,
    scope: line.scope,
    sortOrder: i,
    orgId: user.orgId ?? null,
  }));
  const editing = templateId
    ? await prisma.feeTemplate.findUnique({ where: { id: templateId } })
    : null;
  if (editing && (editing.classId !== classId || editing.sessionId !== sessionId)) throw new Error("Template does not belong to this class");
  const overlap = await prisma.feeTemplate.findFirst({
    where: {
      classId,
      sessionId,
      ...(editing ? { NOT: { id: editing.id } } : {}),
      startsPeriod: { lte: endsPeriod },
      endsPeriod: { gte: startsPeriod },
    },
  });
  if (overlap) throw new Error(`This range overlaps ${overlap.startsPeriod || "an earlier setup"} to ${overlap.endsPeriod || "an earlier setup"}.`);
  const lateData = hasLate ? lateStamp : editing ? {} : feeTemplateLateWrite(inheritedLate);
  if (editing) {
    await prisma.feeLine.deleteMany({ where: { templateId: editing.id } });
    const updated = await prisma.feeTemplate.update({
      where: { id: editing.id },
      data: { orgId: user.orgId ?? null, name, startsPeriod, endsPeriod, dueDay, ...lateData, lines: { create: lines } },
    });
    await syncClassAddOnAmounts(classId, addOnLines);
    await refreshInvoiceLateRule({ templateId: updated.id, orgId: user.orgId ?? null }, updated);
    return { id: updated.id };
  } else {
    const created = await prisma.feeTemplate.create({
      data: { orgId: user.orgId ?? null, classId, sessionId, name, startsPeriod, endsPeriod, dueDay, ...lateData, lines: { create: lines } },
    });
    await syncClassAddOnAmounts(classId, addOnLines);
    return { id: created.id };
  }
}

async function syncClassAddOnAmounts(classId: string, addOnLines: { label: string; amount: number }[]) {
  for (const line of addOnLines) {
    await prisma.studentFeeAddOn.updateMany({
      where: {
        student: { classId },
        OR: [{ kind: classAddOnKind(line.label) }, { kind: "CHARGE", label: line.label }],
      },
      data: { amount: line.amount, label: line.label },
    });
  }
}

async function deliverFeeReminder(invoiceId: string) {
  const invoice = await prisma.feeInvoice.findUnique({
    where: { id: invoiceId },
    include: {
      student: { include: { parent: { include: { user: true } } } },
      payments: true,
    },
  });
  if (!invoice) throw new Error("Invoice missing");
  const { dueNow, message } = reminderCopy(invoice);
  if (dueNow <= 0) throw new Error("This month is already paid. Nudge another open bill.");
  const parent = invoice.student.parent;
  if (!parent) throw new Error(`${invoice.student.name} has no parent added yet. Add a parent mobile to send reminders.`);
  let token = invoice.shareToken;
  if (!token) {
    token = randomUUID();
    await prisma.feeInvoice.update({ where: { id: invoice.id }, data: { shareToken: token } });
  }
  const payUrl = feePayUrl(token);
  const [whatsapp, email] = await Promise.all([getAisensyConfig(), getResendConfig()]);
  if (!whatsapp.configured && !email.configured) {
    throw new Error("Connect WhatsApp in School settings or configure platform email in Anekio Admin → Email delivery.");
  }
  const sent: string[] = [];
  const errors: string[] = [];
  if (whatsapp.configured) {
    try {
      await sendAisensyWhatsApp({
        phone: parent.phone,
        userName: parent.user.name || invoice.student.name,
        params: [invoice.student.name, invoice.title, String(dueNow), payUrl],
      });
      sent.push("WhatsApp");
    } catch (err) {
      errors.push(err instanceof Error ? err.message : "WhatsApp failed");
    }
  }
  if (email.configured) {
    try {
      await sendResendEmail({
        to: parent.user.email,
        studentName: invoice.student.name,
        title: invoice.title,
        amount: String(dueNow),
        payUrl,
      });
      sent.push("email");
    } catch (err) {
      errors.push(err instanceof Error ? err.message : "Email failed");
    }
  }
  if (!sent.length) throw new Error(errors[0] || "Reminder could not be sent");
  await prisma.feeReminder.create({
    data: { orgId: invoice.orgId ?? null, invoiceId, message: `${message} · ${sent.join(" + ")}` },
  });
}

export async function sendFeeRemindersCore(user: AccessUser, input: { invoiceIds?: string[] }) {
  need(user, "fees.collect", "fees.remind");
  const ids = [...new Set((input.invoiceIds || []).map(String).filter(Boolean))].slice(0, 100);
  if (!ids.length) throw new Error("Nothing to remind");
  let ok = 0;
  let lastError = "";
  for (let i = 0; i < ids.length; i += 4) {
    const results = await Promise.allSettled(ids.slice(i, i + 4).map(deliverFeeReminder));
    for (const result of results) {
      if (result.status === "fulfilled") ok += 1;
      else lastError = result.reason instanceof Error ? result.reason.message : "Reminder failed";
    }
  }
  if (!ok) throw new Error(lastError || "No reminders sent");
  return { sent: ok };
}

export async function collectAllStudentFeesCore(
  user: AccessUser,
  input: { studentId: string; method?: string; reference?: string; notes?: string; proofPath?: string }
) {
  need(user, "fees.collect");
  const studentId = String(input.studentId || "");
  if (!studentId) throw new Error("Student required");
  const method = (["CASH", "UPI", "BANK", "CHEQUE"].includes(input.method || "") ? input.method : "CASH") as
    | "CASH"
    | "UPI"
    | "BANK"
    | "CHEQUE";
  const reference = String(input.reference || "").trim() || null;
  if ((method === "UPI" || method === "BANK") && !reference) throw new Error("Enter the UTR / reference number");
  if (method === "CHEQUE" && !reference) throw new Error("Enter the cheque number");
  const invoices = await prisma.feeInvoice.findMany({
    where: { studentId },
    include: { payments: true },
    orderBy: { dueDate: "asc" },
  });
  const open = invoices.filter((inv) => invoiceBalance(inv).dueNow > 0);
  if (!open.length) throw new Error("Nothing due for this student");
  const { recordLedgerPayment } = await import("./fee-ledger");
  const proofPath = String(input.proofPath || "").trim() || null;
  const notes = String(input.notes || "").trim() || "Full payment";
  for (const inv of open) {
    await recordLedgerPayment({
      invoiceId: inv.id,
      amount: invoiceBalance(inv).dueNow,
      method,
      reference,
      proofPath,
      notes,
    });
  }
}

export async function issueClassFeesCore(
  user: AccessUser,
  input: { classId: string; templateId?: string; year?: number; month?: number; startsPeriod?: string; endsPeriod?: string }
) {
  need(user, "fees.collect");
  const classId = String(input.classId || "");
  const { current } = await ensureSchoolSessions();
  const template = input.templateId ? await prisma.feeTemplate.findUnique({
    where: { id: String(input.templateId) },
    include: { lines: { orderBy: { sortOrder: "asc" } } },
  }) : await prisma.feeTemplate.findFirst({
    where: {
      classId,
      sessionId: current.id,
      ...(input.startsPeriod && input.endsPeriod ? { startsPeriod: String(input.startsPeriod), endsPeriod: String(input.endsPeriod) } : {}),
    },
    include: { lines: { orderBy: { sortOrder: "asc" } } },
  });
  if (template && template.classId !== classId) throw new Error("Template does not belong to this class");
  if (!template || !template.lines.length) throw new Error("Save a fee template first");
  const fallbackPeriod = feePeriod(Number(input.year || new Date().getFullYear()), Number(input.month ?? new Date().getMonth()));
  const startsPeriod = template.startsPeriod || normalizeFeePeriod(input.startsPeriod) || fallbackPeriod;
  const endsPeriod = template.endsPeriod || normalizeFeePeriod(input.endsPeriod) || startsPeriod;
  if (startsPeriod > endsPeriod) throw new Error("Start month must be before end month");
  const now = new Date();
  const currentPeriod = feePeriod(now.getFullYear(), now.getMonth());
  const issueThrough = endsPeriod < currentPeriod ? endsPeriod : currentPeriod;
  const months = startsPeriod <= issueThrough ? monthsBetween(startsPeriod, issueThrough) : [];
  const result = await issueTemplateMonthlyInvoices(template, months);
  if (!result.studentCount) throw new Error("This class has no students. Add them on Students, then issue.");
  return { issued: result.created, through: issueThrough };
}

export async function createInvoiceCore(
  user: AccessUser,
  input: { studentId: string; classId?: string; title?: string; amount?: number; dueDate?: string; lateFeePerDay?: number }
) {
  need(user, "fees.collect");
  const studentId = String(input.studentId || "");
  if (!studentId) throw new Error("Student required");
  const dueDate = new Date(String(input.dueDate || ymd(new Date())));
  const currentLate = (await loadFeeCatalog()).late;
  await prisma.feeInvoice.create({
    data: {
      orgId: user.orgId ?? null,
      studentId,
      classId: String(input.classId || "") || null,
      period: periodFromDate(dueDate),
      title: String(input.title || "Fee"),
      amount: Number(input.amount || 0),
      dueDate,
      metadataJson: invoiceLateMetadata(lateStampFromSetup(currentLate).stamp),
      status: InvoiceStatus.DUE,
      shareToken: randomUUID(),
    },
  });
}

export async function saveStudentFeeAddOnCore(
  user: AccessUser,
  input: { id?: string; studentId: string; label?: string; kind?: string; amount?: number; cadence?: string; startsPeriod?: string; endsPeriod?: string; active?: boolean }
) {
  need(user, "people.edit");
  const studentId = String(input.studentId || "");
  if (!studentId) throw new Error("Student required");
  const label = String(input.label || "Add-on").trim() || "Add-on";
  const requestedKind = String(input.kind || "CHARGE").toUpperCase();
  const kind = requestedKind === "DISCOUNT_PERCENT" ? "DISCOUNT_PERCENT" : requestedKind === "DISCOUNT" ? "DISCOUNT" : requestedKind === "CONCESSION" ? "CONCESSION" : "CHARGE";
  const cadence = String(input.cadence || "MONTHLY").toUpperCase() === "ONE_TIME" ? "ONE_TIME" : "MONTHLY";
  const data = {
    orgId: user.orgId ?? null,
    studentId,
    label,
    kind,
    amount: Math.max(0, Math.round(Number(input.amount) || 0)),
    cadence,
    startsPeriod: normalizeFeePeriod(input.startsPeriod) || "",
    endsPeriod: normalizeFeePeriod(input.endsPeriod) || "",
    active: input.active === false ? false : true,
  };
  const id = String(input.id || "");
  if (id) {
    const existing = await prisma.studentFeeAddOn.findUnique({ where: { id } });
    if (!existing || existing.studentId !== studentId) throw new Error("Add-on not found");
    await prisma.studentFeeAddOn.update({ where: { id }, data });
    return;
  }
  await prisma.studentFeeAddOn.create({ data });
}

export async function removeStudentFeeAddOnCore(user: AccessUser, input: { id: string }) {
  need(user, "people.edit");
  const id = String(input.id || "");
  if (!id) throw new Error("Add-on required");
  await prisma.studentFeeAddOn.delete({ where: { id } });
}

async function loadFeeCatalog() {
  const config = await prisma.schoolConfig.findUnique({ where: { id: "school" }, select: { feeCatalogJson: true } });
  return parseFeeCatalogState(config?.feeCatalogJson);
}

async function writeFeeCatalog(user: AccessUser, state: ReturnType<typeof parseFeeCatalogState>) {
  await prisma.schoolConfig.upsert({
    where: { id: "school" },
    update: { feeCatalogJson: serializeFeeCatalogState(state) },
    create: { id: "school", orgId: user.orgId ?? null, feeCatalogJson: serializeFeeCatalogState(state) },
  });
}

export async function saveFeeCatalogCore(
  user: AccessUser,
  input: {
    items?: { id?: string; kind?: string; label?: string; amount?: number; active?: boolean }[];
    item?: { id?: string; kind?: string; label?: string; amount?: number; active?: boolean };
    removeId?: string;
  }
) {
  need(user, "fees.configure");
  const current = await loadFeeCatalog();
  let items = current.items;
  if (Array.isArray(input.items)) {
    items = parseFeeCatalogState(JSON.stringify({ items: input.items, late: current.late })).items;
  }
  const removeId = String(input.removeId || "");
  if (removeId) items = items.filter((item) => item.id !== removeId);
  if (input.item) {
    const kind = "OTHER";
    const label = String(input.item.label || "").trim();
    if (!label) throw new Error("Fee name required");
    const next = {
      id: String(input.item.id || "").trim() || randomUUID(),
      kind,
      label,
      amount: Math.max(0, Math.round(Number(input.item.amount) || 0)),
      active: input.item.active === false ? false : true,
    } as const;
    const index = items.findIndex((item) => item.id === next.id);
    if (index >= 0) items[index] = next;
    else items.push(next);
    await prisma.studentFeeAddOn.updateMany({
      where: { kind: catalogAddOnKind(next.kind, next.id), active: true },
      data: { amount: next.amount, label: catalogAddOnLabel(next) },
    });
  }
  await writeFeeCatalog(user, { ...current, items });
  return { items };
}

export async function applySessionLateFeeCore(
  user: AccessUser,
  input: { enabled?: boolean; amount?: number; graceDays?: number; rule?: string; intervalCount?: number }
) {
  need(user, "fees.configure");
  const mapped = lateStampFromSetup(input);
  const catalog = await loadFeeCatalog();
  await writeFeeCatalog(user, { ...catalog, late: mapped.catalog });
  const { current } = await ensureSchoolSessions();
  const stamp = mapped.stamp;
  await prisma.feeTemplate.updateMany({
    where: { sessionId: current.id },
    data: {
      lateKind: stamp.lateKind,
      lateGraceDays: stamp.lateGraceDays,
      lateAmount: stamp.lateAmount,
      lateIntervalCount: stamp.lateIntervalCount,
      lateIntervalUnit: stamp.lateIntervalUnit,
    },
  });
  await refreshInvoiceLateRule({ orgId: user.orgId ?? null }, stamp);
  return { late: mapped.catalog };
}

export async function applySessionDueDayCore(user: AccessUser, input: { dueDay?: number }) {
  need(user, "fees.configure");
  const dueDay = clampFeeDueDay(input.dueDay);
  const { current } = await ensureSchoolSessions();
  await prisma.feeTemplate.updateMany({
    where: { OR: [{ sessionId: current.id }, { sessionId: null }] },
    data: { dueDay },
  });
  return { dueDay };
}

export async function assignStudentFeesCore(
  user: AccessUser,
  input: { studentId: string; otherItemIds?: string[]; classAddOnLabels?: string[]; discount?: { type?: string; value?: number } | null }
) {
  need(user, "people.edit");
  const studentId = String(input.studentId || "");
  if (!studentId) throw new Error("Student required");
  const student = await prisma.student.findUnique({
    where: { id: studentId },
    include: { feeAddOns: true },
  });
  if (!student) throw new Error("Student not found");
  const catalog = await loadFeeCatalog();
  const otherIds = [...new Set((input.otherItemIds || []).map(String).filter(Boolean))];
  const wanted: FeeCatalogItem[] = [];
  for (const id of otherIds) {
    const item = catalog.items.find((row) => row.id === id && row.kind === "OTHER" && row.active);
    if (!item) throw new Error("Other fee not found");
    wanted.push(item);
  }
  const { current } = await ensureSchoolSessions();
  const startsPeriod = current.startsOn.slice(0, 7);
  const endsPeriod = current.endsOn.slice(0, 7);
  const catalogAddOns = student.feeAddOns.filter((addOn) => parseCatalogAddOnKind(addOn.kind));
  const wantedKinds = new Set(wanted.map((item) => catalogAddOnKind(item.kind, item.id)));
  const classTemplate = await prisma.feeTemplate.findFirst({
    where: { classId: student.classId, OR: [{ sessionId: current.id }, { sessionId: null }] },
    include: { lines: { orderBy: { sortOrder: "asc" } } },
    orderBy: { startsPeriod: "desc" },
  });
  const classOptions = (classTemplate?.lines || []).filter((line) => String(line.scope || "ALL").toUpperCase() === "ADD_ON" && line.amount > 0);
  const selectedKeys = new Set(
    (input.classAddOnLabels || []).map((label) => classAddOnKey(label)).filter((key) => classOptions.some((line) => classAddOnKey(line.label) === key))
  );
  const syncClassAddOns = Array.isArray(input.classAddOnLabels);
  const syncDiscount = input.discount !== undefined;
  const discountType = String(input.discount?.type || "FLAT").toUpperCase() === "PERCENT" ? "PERCENT" : "FLAT";
  const discountValue = Math.max(0, Math.round(Number(input.discount?.value) || 0));
  if (discountType === "PERCENT" && discountValue > 100) throw new Error("Percentage discount cannot exceed 100%");
  const selectedClassOptions = syncClassAddOns
    ? classOptions.filter((line) => selectedKeys.has(classAddOnKey(line.label)))
    : classOptions.filter((line) => student.feeAddOns.some((addOn) => studentHasClassAddOn([addOn], line.label) && !parseCatalogAddOnKind(addOn.kind)));
  const discountMaximum = feeLineTotal([
    ...classAllFeeLines(classTemplate?.lines || []),
    ...wanted.map((item) => ({ label: item.label, kind: "FLAT" as const, amount: item.amount })),
    ...selectedClassOptions.map((line) => ({ label: line.label, kind: "FLAT" as const, amount: line.amount })),
  ]).total;
  if (discountType === "FLAT" && discountValue > discountMaximum) throw new Error(`Flat discount cannot exceed ${discountMaximum}`);
  await prisma.$transaction(async (tx) => {
    for (const addOn of catalogAddOns) {
      if (!wantedKinds.has(addOn.kind)) await tx.studentFeeAddOn.delete({ where: { id: addOn.id } });
    }
    for (const item of wanted) {
      const kind = catalogAddOnKind(item.kind, item.id);
      const existing = catalogAddOns.find((addOn) => addOn.kind === kind);
      const data = {
        label: catalogAddOnLabel(item),
        amount: item.amount,
        cadence: "MONTHLY",
        startsPeriod: existing?.startsPeriod || startsPeriod,
        endsPeriod: existing?.endsPeriod || endsPeriod,
        active: true,
        orgId: user.orgId ?? null,
      };
      if (existing) await tx.studentFeeAddOn.update({ where: { id: existing.id }, data });
      else await tx.studentFeeAddOn.create({ data: { ...data, studentId, kind } });
    }
    if (syncClassAddOns) {
      for (const option of classOptions) {
        const key = classAddOnKey(option.label);
        const kind = classAddOnKind(option.label);
        const existing = student.feeAddOns.find((addOn) => studentHasClassAddOn([addOn], option.label) && !parseCatalogAddOnKind(addOn.kind));
        if (selectedKeys.has(key)) {
          const data = {
            label: option.label,
            kind,
            amount: option.amount,
            cadence: "MONTHLY",
            startsPeriod: existing?.startsPeriod || classTemplate?.startsPeriod || startsPeriod,
            endsPeriod: existing?.endsPeriod || classTemplate?.endsPeriod || endsPeriod,
            active: true,
            orgId: user.orgId ?? null,
          };
          if (existing) await tx.studentFeeAddOn.update({ where: { id: existing.id }, data });
          else await tx.studentFeeAddOn.create({ data: { ...data, studentId } });
        } else if (existing) {
          await tx.studentFeeAddOn.delete({ where: { id: existing.id } });
        }
      }
    }
    if (syncDiscount) {
      await tx.studentFeeAddOn.deleteMany({ where: { studentId, kind: { in: ["DISCOUNT", "DISCOUNT_PERCENT"] } } });
      if (discountValue > 0) {
        await tx.studentFeeAddOn.create({
          data: {
            studentId,
            orgId: user.orgId ?? null,
            label: "Discount",
            kind: discountType === "PERCENT" ? "DISCOUNT_PERCENT" : "DISCOUNT",
            amount: discountValue,
            cadence: "MONTHLY",
            startsPeriod,
            endsPeriod,
            active: true,
          },
        });
      }
    }
  });
}

export async function copyExamSeriesCore(user: AccessUser, input: { seriesId: string; classIds?: string[] }) {
  need(user, "exams.edit");
  const seriesId = String(input.seriesId || "");
  const classIds = [...new Set((input.classIds || []).map(String).filter(Boolean))];
  if (!seriesId || !classIds.length) throw new Error("Pick at least one class");
  const source = await prisma.examSeries.findUnique({
    where: { id: seriesId },
    include: { exams: { include: { subject: true, evaluators: true } } },
  });
  if (!source) throw new Error("Exam not found");
  let copied = 0;
  const blocked: string[] = [];
  for (const classId of classIds) {
    if (classId === source.classId) continue;
    const klass = await prisma.class.findUnique({
      where: { id: classId },
      select: { name: true, section: true },
    });
    const label = klass ? `${klass.name}-${klass.section}` : "Class";
    const clash = await prisma.examSeries.findFirst({
      where: {
        classId,
        sessionId: source.sessionId,
        OR: source.planItemId
          ? [{ name: source.name }, { planItemId: source.planItemId }]
          : [{ name: source.name }],
      },
    });
    if (clash) {
      blocked.push(`${label} already has ${clash.name}`);
      continue;
    }
    const destSubjects = await prisma.subject.findMany({ where: { classId } });
    const byName = new Map(destSubjects.map((s) => [s.name.trim().toLowerCase(), s]));
    const papers = source.exams.flatMap((exam) => {
      const subject = byName.get(exam.subject.name.trim().toLowerCase());
      if (!subject) return [];
      return [
        {
          subject,
          teacherId: exam.teacherId || subject.teacherId,
          setterId: exam.setterId || exam.teacherId || subject.teacherId,
          maxMarks: exam.maxMarks,
          date: ymd(exam.date),
          paperDueOn: exam.paperDueOn ? ymd(exam.paperDueOn) : "",
          copiesDueOn: exam.copiesDueOn ? ymd(exam.copiesDueOn) : "",
          resultOn: exam.resultOn ? ymd(exam.resultOn) : "",
        },
      ];
    });
    if (!papers.length) {
      blocked.push(`${label} has no matching subjects`);
      continue;
    }
    await prisma.examSeries.create({
      data: {
        classId,
        sessionId: source.sessionId,
        planItemId: source.planItemId,
        name: source.name,
        exams: {
          create: papers.map((p) => ({
            orgId: user.orgId ?? null,
            title: `${source.name} · ${p.subject.name}`,
            subjectId: p.subject.id,
            classId,
            maxMarks: p.maxMarks,
            ...examDateFields({
              date: p.date,
              paperDueOn: p.paperDueOn,
              copiesDueOn: p.copiesDueOn,
              resultOn: p.resultOn,
              teacherId: p.teacherId,
              setterId: p.setterId,
            }),
          })),
        },
      },
    });
    copied += 1;
  }
  if (!copied) throw new Error(blocked[0] || "Could not copy this timetable");
  const copies = await prisma.examSeries.findMany({
    where: { sessionId: source.sessionId, name: source.name, classId: { in: classIds } },
    select: { id: true },
  });
  for (const row of copies) await notifySeriesAssigned(row.id, user.id);
  return { copied };
}

/** Hand one paper to another teacher. Only while no marks are in. */
export async function reassignExamTeacherCore(user: AccessUser, input: { examId?: string; teacherId?: string }) {
  const examId = String(input.examId || "");
  const teacherId = String(input.teacherId || "");
  if (!examId || !teacherId) throw new Error("Pick a teacher");
  const exam = await prisma.exam.findUnique({ where: { id: examId } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "run");
  if (exam.teacherId === teacherId) return;
  const teacher = await prisma.teacher.findUnique({ where: { id: teacherId } });
  if (!teacher) throw new Error("Teacher not found");
  const marked = await prisma.examResult.count({ where: { examId } });
  if (marked) throw new Error("Marks are already in for this paper, so the teacher can't be changed.");
  const previous = exam.teacherId;
  await prisma.exam.update({
    where: { id: examId },
    data: { teacherId, ...(exam.setterId === previous && !exam.paperAt ? { setterId: teacherId } : {}) },
  });
  if (previous) await prisma.examEvaluator.deleteMany({ where: { examId, teacherId: previous } });
  await ensureExamEvaluator(examId, teacherId);
  const ctx = await loadExamNoticeCtx(examId);
  if (ctx) await notifyExamReassigned(ctx, user.id);
}

export async function updateExamSeriesPapersCore(
  user: AccessUser,
  input: {
    seriesId: string;
    papers?: {
      subjectId?: string;
      teacherId?: string;
      setterId?: string;
      maxMarks?: number;
      date?: string;
      paperDueOn?: string;
      copiesDueOn?: string;
      resultOn?: string;
      startTime?: string;
      endTime?: string;
    }[];
  }
) {
  const seriesId = String(input.seriesId || "");
  if (!seriesId) throw new Error("Series required");
  const series = await prisma.examSeries.findUnique({
    where: { id: seriesId },
    include: { exams: true },
  });
  if (!series) throw new Error("Series not found");
  await needExamClass(user, series.classId, "run");
  const papers = (input.papers || [])
    .map((row) => {
      const teacherId = String(row.teacherId || "") || null;
      return {
        subjectId: String(row.subjectId || ""),
        teacherId,
        setterId: String(row.setterId || "") || teacherId,
        maxMarks: Math.max(1, Math.round(Number(row.maxMarks) || 0)),
        date: String(row.date || "").slice(0, 10),
        paperDueOn: String(row.paperDueOn || "").slice(0, 10),
        copiesDueOn: String(row.copiesDueOn || "").slice(0, 10),
        resultOn: String(row.resultOn || "").slice(0, 10),
        ...examTimes(row.startTime, row.endTime),
      };
    })
    .filter((row) => row.subjectId && row.maxMarks && row.date);
  if (!papers.length) throw new Error("Pick at least one subject");
  const classSubjects = await prisma.subject.findMany({ where: { classId: series.classId } });
  const lastDate = papers.map((p) => p.date).filter(Boolean).sort().at(-1) || ymd(new Date());
  let extra = 1;
  for (const subject of classSubjects) {
    if (papers.some((p) => p.subjectId === subject.id)) continue;
    const examDate = addDays(lastDate, extra);
    extra += 1;
    papers.push({
      subjectId: subject.id,
      teacherId: subject.teacherId,
      setterId: subject.teacherId,
      maxMarks: papers[0]?.maxMarks || 80,
      date: examDate,
      paperDueOn: addDays(examDate, -7),
      copiesDueOn: addDays(examDate, 7),
      startTime: papers[0]?.startTime || "",
      endTime: papers[0]?.endTime || "",
      resultOn: addDays(examDate, 14),
    });
  }
  const keepSubjects = new Set(papers.map((p) => p.subjectId));
  for (const exam of series.exams) {
    if (!keepSubjects.has(exam.subjectId)) {
      const marked = await prisma.examResult.count({ where: { examId: exam.id } });
      if (marked) throw new Error("Cannot remove a subject that already has marks.");
      await prisma.exam.delete({ where: { id: exam.id } });
    }
  }
  const subjects = await prisma.subject.findMany({
    where: { classId: series.classId, id: { in: papers.map((p) => p.subjectId) } },
  });
  const byId = new Map(subjects.map((s) => [s.id, s]));
  const skillTeachers = await teacherIdsBySubjectName(series.classId, subjects.map((subject) => subject.name));
  const today = ymd(new Date());
  const history = papers.every((paper) => paper.date && paper.date < today) || series.exams.every((exam) => ymd(exam.date) < today);
  for (const paper of papers) {
    const subject = byId.get(paper.subjectId);
    if (!subject) continue;
    const existing = series.exams.find((e) => e.subjectId === paper.subjectId);
    const teacherId = paper.teacherId || existing?.teacherId || skillTeachers.get(subject.name) || (history ? null : subject.teacherId) || null;
    if (!teacherId && !history) throw new Error(`Schedule not saved. Assign teachers to ${subject.name} on Staff first (class and subject).`);
    const stamp = examDateFields({
      ...paper,
      teacherId,
      setterId: paper.setterId || existing?.setterId || teacherId,
    });
    if (existing) {
      await prisma.exam.update({
        where: { id: existing.id },
        data: { title: `${series.name} · ${subject.name}`, maxMarks: paper.maxMarks, startTime: paper.startTime, endTime: paper.endTime, ...stamp },
      });
    } else {
      await prisma.exam.create({
        data: {
          seriesId: series.id,
          title: `${series.name} · ${subject.name}`,
          subjectId: subject.id,
          classId: series.classId,
          maxMarks: paper.maxMarks,
          startTime: paper.startTime,
          endTime: paper.endTime,
          ...stamp,
        },
      });
    }
  }
  await notifySeriesAssigned(series.id, user.id);
}

export async function saveSeriesMarksCore(
  user: AccessUser,
  input: {
    seriesId: string;
    marks?: { examId?: string; studentId?: string; marks?: string | number; absent?: boolean; remarks?: string }[];
  }
) {
  const seriesId = String(input.seriesId || "");
  if (!seriesId) throw new Error("Series required");
  const series = await prisma.examSeries.findUnique({
    where: { id: seriesId },
    include: { exams: { include: { evaluators: true } } },
  });
  if (!series) throw new Error("Series not found");
  need(user, "marks.enter", "exams.edit");
  const teacher =
    user.portal === "TEACHER"
      ? await prisma.teacher.findUnique({ where: { userId: user.id }, select: { id: true } })
      : null;
  const examIds = new Set(
    series.exams
      .filter((e) => (teacher ? teacherMayEnterMarks(e, teacher.id) : can(user, "exams.edit")))
      .map((e) => e.id)
  );
  if (!examIds.size) throw new Error("Only the evaluation teacher can enter marks for their paper");
  const locked = new Set(
    series.exams
      .filter((e) => examIds.has(e.id) && (teacher ? !teacherCanEditMarks(e.workflowStatus) : e.workflowStatus === "PUBLISHED"))
      .map((e) => e.id)
  );
  const rows = Array.isArray(input.marks) ? input.marks : [];
  if (rows.some((row) => locked.has(String(row.examId || "")))) {
    throw new Error("Marks are locked for one or more papers.");
  }
  const maxByExam = new Map(series.exams.map((e) => [e.id, e.maxMarks]));
  const students = await prisma.student.findMany({ where: { classId: series.classId }, select: { id: true } });
  const studentIds = new Set(students.map((s) => s.id));
  for (const row of rows) {
    const examId = String(row.examId || "");
    const studentId = String(row.studentId || "");
    if (!examIds.has(examId) || !studentIds.has(studentId)) continue;
    const absent = Boolean(row.absent);
    const raw = String(row.marks ?? "").trim();
    if (!absent && raw === "") {
      await prisma.examResult.deleteMany({ where: { examId, studentId } });
      continue;
    }
    const marks = absent ? 0 : Number(raw);
    if (Number.isNaN(marks) || marks < 0) throw new Error("Marks must be a number");
    const cap = maxByExam.get(examId) || 0;
    if (marks > cap) throw new Error(`Marks cannot exceed ${cap}`);
    await prisma.examResult.upsert({
      where: { examId_studentId: { examId, studentId } },
      update: { marks, absent, remarks: String(row.remarks || "").trim() || null },
      create: { examId, studentId, marks, absent, remarks: String(row.remarks || "").trim() || null },
    });
  }
}

async function writeMarkAudit(input: {
  examId: string;
  studentId: string;
  marks: number;
  absent: boolean;
  remarks?: string | null;
  action: string;
  actorId: string;
  note?: string | null;
}) {
  await prisma.examResultAudit.create({
    data: {
      examId: input.examId,
      studentId: input.studentId,
      marks: input.marks,
      absent: input.absent,
      remarks: input.remarks || null,
      action: input.action,
      actorId: input.actorId,
      note: input.note || null,
    },
  });
}

async function writeExamMarkRows(
  exam: { id: string; classId: string; maxMarks: number; workflowStatus?: string | null; correctionNote?: string | null },
  rows: { studentId?: string; marks?: string | number; absent?: boolean }[],
  opts?: { actorId?: string; restrictTo?: Set<string>; audit?: string }
) {
  const students = await prisma.student.findMany({
    where: { classId: exam.classId },
    select: { id: true, name: true },
  });
  const studentIds = new Set(students.map((s) => s.id));
  const names = new Map(students.map((s) => [s.id, s.name]));
  let saved = 0;
  for (const row of rows) {
    const studentId = String(row.studentId || "");
    if (!studentId) continue;
    if (!studentIds.has(studentId)) throw new Error("That student is not in this class.");
    if (opts?.restrictTo && !opts.restrictTo.has(studentId)) {
      throw new Error("Only the requested student marks can be corrected.");
    }
    const absent = Boolean(row.absent);
    const raw = String(row.marks ?? "").trim();
    if (!absent && raw === "") {
      if (exam.workflowStatus === "CORRECTION_REQUIRED") continue;
      await prisma.examResult.deleteMany({ where: { examId: exam.id, studentId } });
      continue;
    }
    const marks = absent ? 0 : Number(raw);
    validateExamMark(marks, exam.maxMarks, names.get(studentId) || "Marks");
    const remarks = null;
    await prisma.examResult.upsert({
      where: { examId_studentId: { examId: exam.id, studentId } },
      update: { marks, absent },
      create: { examId: exam.id, studentId, marks, absent },
    });
    if (opts?.audit && opts.actorId) {
      await writeMarkAudit({
        examId: exam.id,
        studentId,
        marks,
        absent,
        remarks,
        action: opts.audit,
        actorId: opts.actorId,
      });
    }
    saved += 1;
  }
  return { saved, studentCount: students.length };
}

async function correctionStudentIds(examId: string, _paperNote?: string | null) {
  const rows = await prisma.examResult.findMany({
    where: { examId, correctionRequestedAt: { not: null } },
    select: { studentId: true },
  });
  if (rows.length) return new Set(rows.map((row) => row.studentId));
  return null;
}

export async function saveExamMarksCore(
  user: AccessUser,
  input: {
    examId?: string;
    marks?: { studentId?: string; marks?: string | number; absent?: boolean }[];
  }
) {
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "mark");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    const blocked = teacherMarksBlock(exam, teacher?.id);
    if (blocked) throw new Error(blocked);
  } else if (exam.workflowStatus === "PUBLISHED") {
    throw new Error("Published results cannot be edited. Unpublish first if the school must change them.");
  } else {
    need(user, "exams.edit");
  }
  const restrict =
    user.portal === "TEACHER" && exam.workflowStatus === "CORRECTION_REQUIRED"
      ? await correctionStudentIds(exam.id, exam.correctionNote)
      : null;
  const result = await writeExamMarkRows(exam, Array.isArray(input.marks) ? input.marks : [], {
    restrictTo: restrict && restrict.size ? restrict : undefined,
  });
  if (exam.workflowStatus === "SCHEDULED" || exam.workflowStatus === "IN_PROGRESS") {
    assertExamTransition(exam.workflowStatus, "MARKS_DRAFT");
    await prisma.exam.update({
      where: { id: exam.id },
      data: { workflowStatus: "MARKS_DRAFT" },
    });
  }
  return result;
}

export async function takeExamCore(user: AccessUser, input: { examId?: string }) {
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "mark");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    if (!teacherMayTakeExam(exam, teacher?.id)) {
      throw new Error("Set the question paper first, then take the exam.");
    }
  }
  if (!teacherCanTakeExam(exam.workflowStatus)) throw new Error("This exam has already been taken.");
  assertExamTransition(exam.workflowStatus, "IN_PROGRESS");
  await prisma.exam.update({
    where: { id: exam.id },
    data: { workflowStatus: "IN_PROGRESS", conductedAt: new Date() },
  });
  const ctx = await loadExamNoticeCtx(exam.id);
  if (ctx) await notifyExamConducted(ctx, user.id);
}

export async function submitExamMarksCore(
  user: AccessUser,
  input: {
    examId?: string;
    marks?: { studentId?: string; marks?: string | number; absent?: boolean }[];
  }
) {
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "mark");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    const blocked = teacherMarksBlock(exam, teacher?.id);
    if (blocked) throw new Error(blocked);
  } else {
    need(user, "exams.edit", "marks.enter");
    if (!teacherCanEditMarks(exam.workflowStatus)) {
      throw new Error("This paper is already submitted.");
    }
  }
  const restrict =
    user.portal === "TEACHER" && exam.workflowStatus === "CORRECTION_REQUIRED"
      ? await correctionStudentIds(exam.id, exam.correctionNote)
      : null;
  const nextStatus = exam.workflowStatus === "CORRECTION_REQUIRED" ? "RESUBMITTED" : "SUBMITTED";
  await writeExamMarkRows(exam, Array.isArray(input.marks) ? input.marks : [], {
    actorId: user.id,
    restrictTo: restrict && restrict.size ? restrict : undefined,
    audit: nextStatus,
  });
  const students = await prisma.student.findMany({ where: { classId: exam.classId }, select: { id: true } });
  const results = await prisma.examResult.findMany({ where: { examId: exam.id } });
  const have = new Set(results.map((row) => row.studentId));
  const missing = students.filter((s) => !have.has(s.id)).length;
  if (missing && nextStatus === "SUBMITTED") {
    throw new Error(`Enter marks or Absent for every student before submitting. ${missing} still missing.`);
  }
  assertExamTransition(exam.workflowStatus, nextStatus);
  await prisma.exam.update({
    where: { id: exam.id },
    data: {
      workflowStatus: nextStatus,
      submittedAt: new Date(),
      copiesDoneAt: new Date(),
      correctionNote: nextStatus === "RESUBMITTED" ? exam.correctionNote : null,
    },
  });
  if (nextStatus === "RESUBMITTED") {
    await prisma.examResult.updateMany({
      where: { examId: exam.id, correctionRequestedAt: { not: null } },
      data: {
        correctionRequestedAt: null,
        correctionRequestedById: null,
        version: { increment: 1 },
      },
    });
  }
  const ctx = await loadExamNoticeCtx(exam.id);
  if (ctx) await notifyMarksSubmitted(ctx, nextStatus === "RESUBMITTED", user.id);
  return { submitted: students.length };
}

export async function reviewExamMarksCore(user: AccessUser, input: { examId?: string }) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  if (!adminCanReview(exam.workflowStatus)) {
    throw new Error("This paper is not waiting for review.");
  }
  if (exam.workflowStatus === "SUBMITTED") {
    assertExamTransition(exam.workflowStatus, "UNDER_REVIEW");
    await prisma.exam.update({
      where: { id: exam.id },
      data: { workflowStatus: "UNDER_REVIEW" },
    });
  }
}

export async function returnExamMarksCore(user: AccessUser, input: { examId?: string; note?: string }) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  if (
    exam.workflowStatus !== "SUBMITTED" &&
    exam.workflowStatus !== "UNDER_REVIEW" &&
    exam.workflowStatus !== "RESUBMITTED" &&
    exam.workflowStatus !== "APPROVED"
  ) {
    throw new Error("Only submitted papers can be sent back.");
  }
  const note = String(input.note || "").trim();
  if (!note) throw new Error("Add a correction note so the teacher knows what to fix.");
  assertExamTransition(exam.workflowStatus, "CORRECTION_REQUIRED");
  await prisma.exam.update({
    where: { id: exam.id },
    data: {
      workflowStatus: "CORRECTION_REQUIRED",
      correctionNote: note,
    },
  });
  const ctx = await loadExamNoticeCtx(exam.id);
  if (ctx) await notifyMarksCorrection(ctx, note, user.id);
}

export async function requestExamMarkCorrectionCore(
  user: AccessUser,
  input: { examId?: string; studentId?: string; note?: string }
) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  const studentId = String(input.studentId || "");
  const note = String(input.note || "").trim();
  if (!examId || !studentId) throw new Error("Pick the student and paper.");
  if (!note) throw new Error("Add a reason so the teacher knows what to verify.");
  const exam = await prisma.exam.findUnique({
    where: { id: examId },
    include: { evaluators: true, results: true },
  });
  if (!exam) throw new Error("Exam not found");
  if (exam.workflowStatus === "PUBLISHED") throw new Error("Unpublish results before requesting a correction.");
  if (
    exam.workflowStatus !== "SUBMITTED" &&
    exam.workflowStatus !== "UNDER_REVIEW" &&
    exam.workflowStatus !== "RESUBMITTED" &&
    exam.workflowStatus !== "APPROVED"
  ) {
    throw new Error("Request a correction after the teacher has submitted the mark sheet.");
  }
  const student = await prisma.student.findUnique({ where: { id: studentId }, select: { id: true, name: true, classId: true } });
  if (!student || student.classId !== exam.classId) throw new Error("That student is not in this class.");
  const current = exam.results.find((row) => row.studentId === studentId);
  if (!current) throw new Error("No mark has been submitted for this student yet.");
  assertExamTransition(exam.workflowStatus, "CORRECTION_REQUIRED");
  await prisma.examResult.update({
    where: { examId_studentId: { examId, studentId } },
    data: {
      correctionNote: note,
      correctionRequestedAt: new Date(),
      correctionRequestedById: user.id,
    },
  });
  await prisma.exam.update({
    where: { id: examId },
    data: { workflowStatus: "CORRECTION_REQUIRED", correctionNote: exam.correctionNote || note },
  });
  await writeMarkAudit({
    examId,
    studentId,
    marks: current.marks,
    absent: current.absent,
    remarks: current.remarks,
    action: "CORRECTION_REQUESTED",
    actorId: user.id,
    note,
  });
  const ctx = await loadExamNoticeCtx(examId);
  if (ctx) await notifyMarksCorrection(ctx, `${student.name}: ${note}`, user.id);
}

export async function remindExamMarksCore(user: AccessUser, input: { examId?: string }) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "run");
  if (exam.workflowStatus === "PUBLISHED") throw new Error("Results are already published.");
  const ctx = await loadExamNoticeCtx(examId);
  if (!ctx) throw new Error("Exam not found");
  await notifyMarksReminder(ctx, user.id);
}

export async function examMarkHistoryCore(user: AccessUser, input: { examId?: string; studentId?: string }) {
  need(user, "exams.edit", "exams.view");
  const examId = String(input.examId || "");
  const studentId = String(input.studentId || "");
  if (!examId || !studentId) throw new Error("Pick the student and paper.");
  const rows = await prisma.examResultAudit.findMany({
    where: { examId, studentId },
    orderBy: { createdAt: "asc" },
  });
  const actors = await prisma.user.findMany({
    where: { id: { in: [...new Set(rows.map((row) => row.actorId))] } },
    select: { id: true, name: true },
  });
  const names = new Map(actors.map((row) => [row.id, row.name]));
  return {
    history: rows.map((row) => ({
      id: row.id,
      action: row.action,
      marks: row.marks,
      absent: row.absent,
      note: row.note || "",
      at: row.createdAt.toISOString(),
      actorName: names.get(row.actorId) || "Staff",
    })),
  };
}

export async function approveExamMarksCore(user: AccessUser, input: { examId?: string }) {
  need(user, "exams.edit", "exams.publish");
  const examId = String(input.examId || "");
  if (!examId) throw new Error("Exam required");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  if (exam.workflowStatus !== "SUBMITTED" && exam.workflowStatus !== "UNDER_REVIEW" && exam.workflowStatus !== "RESUBMITTED") {
    throw new Error("Approve after the teacher has submitted the mark sheet.");
  }
  assertExamTransition(exam.workflowStatus, "APPROVED");
  const results = await prisma.examResult.findMany({ where: { examId: exam.id } });
  for (const row of results) {
    await writeMarkAudit({
      examId: exam.id,
      studentId: row.studentId,
      marks: row.marks,
      absent: row.absent,
      remarks: row.remarks,
      action: "APPROVED",
      actorId: user.id,
    });
  }
  await prisma.exam.update({
    where: { id: exam.id },
    data: { workflowStatus: "APPROVED", reviewedAt: new Date() },
  });
  const ctx = await loadExamNoticeCtx(exam.id);
  if (ctx) await notifyMarksApproved(ctx, user.id);
}

export async function publishExamResultsCore(
  user: AccessUser,
  input: { examId?: string; seriesId?: string; holdIfUnpaidMonths?: number; sendToParents?: boolean }
) {
  need(user, "exams.publish");
  const examId = String(input.examId || "");
  const seriesId = String(input.seriesId || "");
  const sendToParents = Boolean(input.sendToParents);
  if (examId) {
    const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
    if (!exam) throw new Error("Exam not found");
    if (exam.seriesId && exam.workflowStatus !== "PUBLISHED") {
      // Parents see a sitting as soon as any paper is published, so papers of one exam go out together.
      const papers = await prisma.exam.count({ where: { seriesId: exam.seriesId } });
      if (papers > 1) {
        throw new Error("Papers of this exam are published together. Publish the whole exam once every paper has marks.");
      }
    }
    if (exam.workflowStatus !== "PUBLISHED") {
      if (!adminCanPublish(exam.workflowStatus)) {
        throw new Error("The teacher hasn't sent marks for this paper yet.");
      }
      assertExamTransition(exam.workflowStatus, "PUBLISHED");
      await prisma.exam.update({
        where: { id: exam.id },
        data: { workflowStatus: "PUBLISHED", resultsPublishedAt: new Date() },
      });
      const ctx = await loadExamNoticeCtx(exam.id);
      if (ctx) await notifyResultsPublished({ exam: ctx, authorId: user.id, sendToParents });
    }
    await persistResultsUnpaidHold(user, input.holdIfUnpaidMonths);
    return { published: 1 };
  }
  if (!seriesId) throw new Error("Exam or series required");
  const series = await prisma.examSeries.findUnique({
    where: { id: seriesId },
    include: { exams: true },
  });
  if (!series) throw new Error("Series not found");
  await needExamClass(user, series.classId, "run");
  const notReady = series.exams.filter(
    (exam) => exam.workflowStatus !== "PUBLISHED" && !adminCanPublish(exam.workflowStatus)
  );
  if (notReady.length) {
    throw new Error(
      `Results cannot be published yet. ${notReady.map((exam) => exam.title).join(", ")} ${notReady.length === 1 ? "is" : "are"} still waiting for marks.`
    );
  }
  const now = new Date();
  await prisma.exam.updateMany({
    where: { seriesId, workflowStatus: { in: ["APPROVED", "SUBMITTED", "RESUBMITTED", "UNDER_REVIEW"] } },
    data: { workflowStatus: "PUBLISHED", resultsPublishedAt: now },
  });
  await persistResultsUnpaidHold(user, input.holdIfUnpaidMonths);
  await notifyResultsPublished({ seriesId, authorId: user.id, sendToParents });
  return { published: series.exams.length };
}

async function persistResultsUnpaidHold(user: AccessUser, holdIfUnpaidMonths?: number) {
  if (holdIfUnpaidMonths == null || String(holdIfUnpaidMonths).trim() === "") return;
  const resultsUnpaidMonths = Math.max(0, Math.min(24, Math.floor(Number(holdIfUnpaidMonths) || 0)));
  const current = await loadFeeCatalog();
  await writeFeeCatalog(user, { ...current, resultsUnpaidMonths });
}

export async function importExamMarksCore(user: AccessUser, input: { examId?: string; csv?: string }) {
  const examId = String(input.examId || "");
  const csv = String(input.csv || "");
  if (!examId) throw new Error("Exam required");
  if (/^PK\x03\x04/.test(csv) || csv.includes("xl/")) {
    throw new Error("Save the Excel file as CSV, then import that.");
  }
  const rows = parseCsv(csv);
  if (!rows.length) throw new Error("The sheet is empty. Use columns Admission, Name, Marks.");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "mark");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    const blocked = teacherMarksBlock(exam, teacher?.id);
    if (blocked) throw new Error(blocked);
  } else if (exam.workflowStatus === "PUBLISHED") {
    throw new Error("Published results cannot be edited.");
  }
  const students = await prisma.student.findMany({
    where: { classId: exam.classId },
    select: { id: true, name: true, admissionNo: true },
  });
  const byAdm = new Map(students.map((s) => [s.admissionNo.trim().toLowerCase(), s]));
  const byName = new Map(students.map((s) => [s.name.trim().toLowerCase(), s]));
  let saved = 0;
  const skipped: string[] = [];
  for (const row of rows) {
    const admission = cell(row, "admissionNo", "admission", "adm", "admn", "admissionno").toLowerCase();
    const name = cell(row, "name", "student", "studentname").toLowerCase();
    const student = (admission && byAdm.get(admission)) || (name && byName.get(name)) || null;
    if (!student) {
      skipped.push(cell(row, "name", "admissionNo", "admission") || "A row");
      continue;
    }
    const absentRaw = cell(row, "absent", "ab");
    const absent = /^(y|yes|1|ab|absent|true)$/i.test(absentRaw);
    const raw = cell(row, "marks", "score", "mark", "obtained");
    if (!absent && raw === "") {
      skipped.push(student.name);
      continue;
    }
    const marks = absent ? 0 : Number(raw);
    if (Number.isNaN(marks) || marks < 0) throw new Error(`Marks for ${student.name} must be a number`);
    if (marks > exam.maxMarks) throw new Error(`${student.name}: marks cannot exceed ${exam.maxMarks}`);
    await prisma.examResult.upsert({
      where: { examId_studentId: { examId, studentId: student.id } },
      update: { marks, absent },
      create: { examId, studentId: student.id, marks, absent },
    });
    saved += 1;
  }
  if (!saved) throw new Error(skipped[0] ? `Could not match ${skipped[0]}. Use admission number.` : "No marks in that sheet.");
  return { saved, skipped: skipped.length };
}

export async function completeExamWorkCore(
  user: AccessUser,
  input: { examId?: string; kind?: string; done?: boolean | string | number }
) {
  const examId = String(input.examId || "");
  const kind = String(input.kind || "");
  if (!examId || (kind !== "paper" && kind !== "copies")) throw new Error("Pick a paper task");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "mark");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    if (!teacher) throw new Error("Not your paper");
    if (kind === "paper" && paperSetterId(exam) !== teacher.id) throw new Error("Only the setter marks the paper done");
    if (kind === "copies" && !grantedEvaluatorIds(exam).includes(teacher.id)) throw new Error("Only a teacher allowed to enter marks can mark copies done");
  }
  const on = input.done !== false && input.done !== "0" && input.done !== 0;
  if (kind === "paper") {
    if (user.portal === "TEACHER") {
      if (on) await handOverExamPaperCore(user, { examId });
      else await undoExamPaperHandoverCore(user, { examId });
    } else if (on) {
      await receiveExamPaperCore(user, { examId });
    } else {
      need(user, "exams.edit");
      await prisma.exam.update({ where: { id: examId }, data: { paperAt: null, paperReceivedById: null } });
    }
    return;
  }
  await prisma.exam.update({
    where: { id: examId },
    data: { copiesDoneAt: on ? new Date() : null },
  });
}

/* ----------------------------------------------------------------------------------------------
 * Question paper handover. Teacher hands over → office confirms (Received) or sends it back.
 * Nothing counts as "paper ready" until the office has confirmed it.
 * -------------------------------------------------------------------------------------------- */

async function setterExam(user: AccessUser, examId: string) {
  if (!examId) throw new Error("Pick a paper");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { evaluators: true } });
  if (!exam) throw new Error("Exam not found");
  await needExamClass(user, exam.classId, "mark");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    if (!teacher || paperSetterId(exam) !== teacher.id) throw new Error("Only the teacher setting this paper can hand it over.");
  }
  return exam;
}

export async function handOverExamPaperCore(user: AccessUser, input: { examId?: string; note?: string }) {
  const exam = await setterExam(user, String(input.examId || ""));
  if (exam.paperAt) throw new Error("The office has already received this paper.");
  const note = String(input.note || "").replace(/\s+/g, " ").trim().slice(0, 300);
  await prisma.exam.update({
    where: { id: exam.id },
    data: { paperHandedAt: new Date(), paperHandedById: user.id, paperHandNote: note, paperReturnNote: "" },
  });
  const ctx = await loadExamNoticeCtx(exam.id);
  if (ctx) await notifyPaperHandedOver(ctx, user.id, note);
}

export async function undoExamPaperHandoverCore(user: AccessUser, input: { examId?: string }) {
  const exam = await setterExam(user, String(input.examId || ""));
  if (exam.paperAt) throw new Error("The office has already received this paper.");
  await prisma.exam.update({
    where: { id: exam.id },
    data: { paperHandedAt: null, paperHandedById: null, paperHandNote: "" },
  });
}

export async function receiveExamPaperCore(user: AccessUser, input: { examId?: string }) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  const exam = await prisma.exam.findUnique({ where: { id: examId } });
  if (!exam) throw new Error("Exam not found");
  if (exam.paperAt) return;
  await prisma.exam.update({
    where: { id: examId },
    data: { paperAt: new Date(), paperReceivedById: user.id, paperReturnNote: "" },
  });
  const ctx = await loadExamNoticeCtx(examId);
  if (ctx) await notifyPaperReceived(ctx, user.id);
}

export async function returnExamPaperCore(user: AccessUser, input: { examId?: string; reason?: string }) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  const reason = String(input.reason || "").replace(/\s+/g, " ").trim().slice(0, 300);
  if (reason.length < 3) throw new Error("Say what needs fixing, so the teacher knows.");
  const exam = await prisma.exam.findUnique({ where: { id: examId } });
  if (!exam) throw new Error("Exam not found");
  await prisma.exam.update({
    where: { id: examId },
    data: { paperAt: null, paperReceivedById: null, paperHandedAt: null, paperHandedById: null, paperReturnNote: reason },
  });
  const ctx = await loadExamNoticeCtx(examId);
  if (ctx) await notifyPaperReturned(ctx, user.id, reason);
}

export async function uploadPaperCore(
  user: AccessUser,
  input: { examId: string; studentId: string; type?: string; notes?: string; fileName: string; filePath: string }
) {
  need(user, "papers.upload");
  const examId = String(input.examId || "");
  const studentId = String(input.studentId || "");
  if (!examId || !studentId || !input.filePath) throw new Error("Exam, student and file are required");
  const allowed: PaperType[] = ["MARK_SHEET", "ANSWER_SHEET", "EVALUATED"];
  const type = (allowed.includes(input.type as PaperType) ? input.type : "EVALUATED") as PaperType;
  await prisma.examPaper.create({
    data: {
      examId,
      studentId,
      teacherId: user.id,
      type,
      fileName: input.fileName,
      filePath: input.filePath,
      notes: String(input.notes || "") || null,
    },
  });
}

export async function uploadQuestionPaperCore(
  user: AccessUser,
  input: { examId: string; fileName: string; filePath: string; mime?: string }
) {
  need(user, "papers.upload", "exams.edit");
  const examId = String(input.examId || "");
  if (!examId || !input.filePath) throw new Error("Exam and question paper are required");
  if (!isQuestionPaperFile(input.fileName, input.mime || "")) {
    throw new Error("Upload the question paper as a PDF or Word file. Spreadsheets and CSVs are not question papers.");
  }
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { teacher: true } });
  if (!exam) throw new Error("Exam not found");
  if (user.portal === "TEACHER") {
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    const setterId = exam.setterId || exam.teacherId;
    if (!teacher || teacher.id !== setterId) throw new Error("Only the question teacher can set this paper");
  }
  if (user.portal === "TEACHER") {
    await prisma.exam.update({ where: { id: examId }, data: { paperFileName: input.fileName, paperFilePath: input.filePath } });
    return;
  }
  await prisma.exam.update({
    where: { id: examId },
    data: { paperFileName: input.fileName, paperFilePath: input.filePath, paperAt: new Date(), paperReceivedById: user.id },
  });
  const ctx = await loadExamNoticeCtx(examId);
  if (ctx) await notifyPaperSubmitted(ctx, user.id);
}

export async function grantExamMarksCore(user: AccessUser, input: { examId?: string; teacherId?: string; remove?: boolean | string }) {
  need(user, "exams.edit");
  const examId = String(input.examId || "");
  const teacherId = String(input.teacherId || "");
  if (!examId || !teacherId) throw new Error("Pick the paper and the teacher who will enter marks.");
  const exam = await prisma.exam.findUnique({
    where: { id: examId },
    include: { evaluators: true, subject: true },
  });
  if (!exam) throw new Error("Exam not found");
  if (exam.workflowStatus === "PUBLISHED") throw new Error("Results are already published.");
  const teacher = await prisma.teacher.findUnique({ where: { id: teacherId }, include: { user: { select: { id: true } } } });
  if (!teacher) throw new Error("Teacher not found");
  const removing = input.remove === true || input.remove === "1" || input.remove === "true";
  const current = grantedEvaluatorIds(exam);
  if (removing) {
    if (!current.includes(teacherId)) throw new Error("That teacher is not allowed to enter marks on this paper.");
    await prisma.examEvaluator.deleteMany({ where: { examId, teacherId } });
    const left = await prisma.examEvaluator.count({ where: { examId } });
    await prisma.exam.update({
      where: { id: examId },
      data: { marksGrantedAt: left ? exam.marksGrantedAt : null },
    });
    return { removed: true };
  }
  const eligible = await eligibleTeacherIdsForExam(examId);
  if (!canGrantMarksEntry(teacherId, eligible)) {
    throw new Error("Only a teacher of this subject can be given marks entry. Assign them to this class and subject on Staff first.");
  }
  await ensureExamEvaluator(examId, teacherId);
  await prisma.exam.update({
    where: { id: examId },
    data: {
      teacherId: exam.teacherId || teacherId,
      marksGrantedAt: new Date(),
    },
  });
  const ctx = await loadExamNoticeCtx(examId);
  if (ctx) await notifyMarksGranted(ctx, user.id, [teacher.user.id]);
  return { added: true };
}

export async function importPeopleSheetCore(user: AccessUser, input: { kind?: string; csv?: string }) {
  need(user, "people.edit", "people.import");
  const kind = String(input.kind || "student");
  const rows = parseCsv(String(input.csv || ""));
  if (!rows.length) throw new Error("The sheet is empty. Check the header row.");
  const created: string[] = [];
  const skipped: string[] = [];

  if (kind === "student") {
    const [classes, parents, existing] = await Promise.all([
      prisma.class.findMany({ where: { archivedAt: null } }),
      prisma.parent.findMany({ include: { user: true } }),
      prisma.student.findMany({ select: { admissionNo: true } }),
    ]);
    const taken = new Set(existing.map((s) => s.admissionNo.toLowerCase()));
    const parentByEmail = new Map(parents.map((p) => [p.user.email.toLowerCase(), p]));
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const line = i + 2;
      const name = cell(row, "name");
      const admissionNo = cell(row, "admissionNo", "admission");
      const dob = parseDob(cell(row, "dateOfBirth", "dob"));
      const billingStartPeriod = cell(row, "billingStartPeriod", "billing starts from");
      const classRaw = cell(row, "class") || `${cell(row, "className")} ${cell(row, "section")}`.trim();
      const parsedClass = parseClassLabel(classRaw);
      const klass = parsedClass
        ? classes.find((c) => c.name === parsedClass.name && c.section.toUpperCase() === parsedClass.section)
        : classes.find((c) => `${c.name}-${c.section}`.toLowerCase() === classRaw.toLowerCase());
      const parentEmail = cell(row, "parentEmail").toLowerCase();
      if (!name || !admissionNo || (cell(row, "dateOfBirth", "dob") && !dob) || !klass || !parentEmail || !/^\d{4}-(0[1-9]|1[0-2])$/.test(billingStartPeriod)) {
        skipped.push(`Row ${line}: need name, admission no., class, parent email (date of birth as YYYY-MM-DD if given), and billing start month (YYYY-MM).`);
        continue;
      }
      if (taken.has(admissionNo.toLowerCase())) {
        skipped.push(`Row ${line}: admission ${admissionNo} already exists.`);
        continue;
      }
      let parent = parentByEmail.get(parentEmail);
      if (!parent) {
        const parentName = cell(row, "parentName");
        const parentPhone = normalizeMobile(cell(row, "parentPhone"));
        if (!parentName) {
          skipped.push(`Row ${line}: no parent with ${parentEmail}. Add the parent first.`);
          continue;
        }
        if (!parentPhone) {
          skipped.push(`Row ${line}: parent needs a 10-digit mobile.`);
          continue;
        }
        const password = await bcrypt.hash("12345", 10);
        const userRow = await prisma.user.create({
          data: {
            name: parentName,
            email: parentEmail,
            password,
            roleId: await roleIdBySlug("PARENT"),
            phone: parentPhone,
            parent: { create: { phone: parentPhone } },
          },
          include: { parent: { include: { user: true } } },
        });
        parent = userRow.parent!;
        parentByEmail.set(parentEmail, parent);
      }
      const student = await prisma.student.create({
        data: {
          orgId: user.orgId ?? null,
          name,
          admissionNo,
          classId: klass.id,
          parentId: parent.id,
          dateOfBirth: dob,
          billingStartPeriod,
          interests: { create: parsePathTags(cell(row, "path")).map((tag) => ({ tag: tag as PathTag })) },
        },
      });
      await assignStudentRollNumber(prisma, { studentId: student.id, classId: klass.id, orgId: user.orgId ?? null });
      taken.add(admissionNo.toLowerCase());
      created.push(name);
    }
  } else if (kind === "parent") {
    const existing = await prisma.user.findMany({ select: { email: true } });
    const taken = new Set(existing.map((u) => u.email.toLowerCase()));
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const line = i + 2;
      const name = cell(row, "name");
      const email = cell(row, "email").toLowerCase();
      const parentPhone = normalizeMobile(cell(row, "phone"));
      if (!name || !email) {
        skipped.push(`Row ${line}: need name and email.`);
        continue;
      }
      if (!parentPhone) {
        skipped.push(`Row ${line}: need a 10-digit mobile.`);
        continue;
      }
      if (taken.has(email)) {
        skipped.push(`Row ${line}: ${email} already exists.`);
        continue;
      }
      await prisma.user.create({
        data: {
          name,
          email,
          password: await bcrypt.hash(cell(row, "password") || "12345", 10),
          roleId: await roleIdBySlug("PARENT"),
          phone: parentPhone,
          parent: { create: { phone: parentPhone } },
        },
      });
      taken.add(email);
      created.push(name);
    }
  } else if (kind === "teacher") {
    const existingUsers = await prisma.user.findMany({ select: { email: true } });
    const existingTeachers = await prisma.teacher.findMany({ select: { employeeId: true } });
    const takenEmail = new Set(existingUsers.map((u) => u.email.toLowerCase()));
    const takenEmp = new Set(existingTeachers.map((t) => t.employeeId.toLowerCase()));
    const nums = existingTeachers
      .map((t) => Number(String(t.employeeId).replace(/\D/g, "")))
      .filter((n) => Number.isFinite(n));
    let nextEmp = (nums.length ? Math.max(...nums) : 100) + 1;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const line = i + 2;
      const name = cell(row, "name");
      const email = cell(row, "email").toLowerCase();
      const mobile = normalizeMobile(cell(row, "phone"));
      if (!name || !email) {
        skipped.push(`Row ${line}: need name and email.`);
        continue;
      }
      if (!mobile) {
        skipped.push(`Row ${line}: need a 10-digit mobile.`);
        continue;
      }
      if (takenEmail.has(email)) {
        skipped.push(`Row ${line}: ${email} already exists.`);
        continue;
      }
      let employeeId = cell(row, "employeeId");
      if (!employeeId) {
        employeeId = `T-${nextEmp}`;
        nextEmp += 1;
      }
      if (takenEmp.has(employeeId.toLowerCase())) {
        skipped.push(`Row ${line}: employee id ${employeeId} already exists.`);
        continue;
      }
      await prisma.user.create({
        data: {
          name,
          email,
          password: await bcrypt.hash(cell(row, "password") || "12345", 10),
          roleId: await roleIdBySlug("TEACHER"),
          phone: mobile,
          teacher: {
            create: {
              orgId: user.orgId ?? null,
              employeeId,
              joinedOn: todayJoinedOn(),
              ...(cell(row, "qualification") ? { qualification: cell(row, "qualification") } : {}),
            },
          },
        },
      });
      takenEmail.add(email);
      takenEmp.add(employeeId.toLowerCase());
      created.push(name);
    }
  } else {
    throw new Error("Unknown sheet type");
  }
  if (!created.length) throw new Error(skipped[0] || "Nothing imported.");
  return { created: created.length, skipped };
}

export async function archiveClassCore(user: AccessUser, input: { classId: string; restore?: boolean }) {
  need(user, "people.edit");
  const classId = String(input.classId || "");
  if (!classId) throw new Error("Class required");
  await prisma.class.update({
    where: { id: classId },
    data: { archivedAt: input.restore ? null : new Date() },
  });
}
