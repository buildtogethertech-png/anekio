import { prisma } from "./prisma";
import {
  defaultGrants,
  PERMISSION_KEYS,
  scopePolicyFor,
  SYSTEM_ROLES,
  validScopeFor,
  type AccessScope,
  type AccessUser,
} from "./permissions";
import { ensureManagers } from "./reports";
import { repairSingleOrgLegacyData } from "./legacy-org-repair";

let accessReadyPromise: Promise<void> | null = null;

export async function ensureAccessRoles() {
  if (accessReadyPromise) return accessReadyPromise;
  accessReadyPromise = prepareAccessRoles().catch((error) => {
    accessReadyPromise = null;
    throw error;
  });
  return accessReadyPromise;
}

async function prepareAccessRoles() {
  if (!prisma.role) return;
  for (const spec of SYSTEM_ROLES) {
    const role = await prisma.role.upsert({
      where: { slug: spec.slug },
      update: { name: spec.name, portal: spec.portal, description: spec.description, isSystem: true },
      create: { ...spec, isSystem: true },
    });
    const grants = defaultGrants(spec.slug);
    const have = await prisma.roleGrant.findMany({
      where: { roleId: role.id },
      select: { permission: true, scope: true },
    });
    const haveSet = new Set(have.map((g) => g.permission));
    const missing = grants.filter((permission) => !haveSet.has(permission));
    if (missing.length) {
      await prisma.roleGrant.createMany({
        data: missing.map((permission) => ({
          roleId: role.id,
          permission,
          scope:
            spec.slug === "ADMIN" && validScopeFor(permission, "SCHOOL", spec.portal)
              ? "SCHOOL"
              : scopePolicyFor(permission, spec.portal).defaultScope,
        })),
      });
    }
  }
  const rolesWithLegacyGrants = await prisma.role.findMany({ include: { grants: true } });
  for (const role of rolesWithLegacyGrants) {
    const permissionSet = new Set(role.grants.map((g) => g.permission));
    for (const grant of role.grants.filter((g) => !g.scope || !validScopeFor(g.permission, g.scope, role.portal))) {
      let scope: AccessScope = scopePolicyFor(grant.permission, role.portal).defaultScope;
      if (!grant.scope && (role.slug === "ADMIN" || grant.permission === "leave.decide")) scope = "SCHOOL";
      if (!grant.scope && (grant.permission === "timetable.view" || grant.permission === "timetable.edit")) {
        scope = permissionSet.has("timetable.edit") ? "SCHOOL" : "REPORTS";
      }
      if (!validScopeFor(grant.permission, scope, role.portal)) {
        scope = scopePolicyFor(grant.permission, role.portal).defaultScope;
      }
      await prisma.roleGrant.update({
        where: { roleId_permission: { roleId: role.id, permission: grant.permission } },
        data: { scope },
      });
    }
  }
  await ensureManagers();
  const managerRoles = await prisma.user.findMany({
    where: { reports: { some: {} }, role: { portal: { in: ["OFFICE", "TEACHER"] } } },
    select: { roleId: true, role: { select: { portal: true } } },
  });
  for (const manager of managerRoles) {
    await prisma.roleGrant.upsert({
      where: { roleId_permission: { roleId: manager.roleId, permission: "leave.decide" } },
      update: {},
      create: { roleId: manager.roleId, permission: "leave.decide", scope: "REPORTS" },
    });
    if (manager.role.portal === "TEACHER") {
      await prisma.roleGrant.upsert({
        where: { roleId_permission: { roleId: manager.roleId, permission: "timetable.view" } },
        update: {},
        create: { roleId: manager.roleId, permission: "timetable.view", scope: "REPORTS" },
      });
    }
  }
}

export async function roleIdBySlug(slug: string) {
  await ensureAccessRoles();
  const role = await prisma.role.findUnique({ where: { slug } });
  if (!role) throw new Error(`Role ${slug} missing`);
  return role.id;
}

const accessInclude = { role: { include: { grants: true } }, parent: { select: { id: true } }, teacher: { select: { id: true, teachingOnly: true } } } as const;

/**
 * Loads who is signed in. One login can wear several hats:
 * - a teacher or office user who is also a parent has a Parent row on the same User -> PARENT hat;
 * - an office user marked "Also a teacher" has a (teachingOnly) Teacher row on the same User -> TEACHER hat.
 * `as` loads them with that hat's system role (Parent: own children; Teacher: own classes, periods and papers).
 */
export async function loadAccess(userId: string, as?: "PARENT" | "TEACHER"): Promise<AccessUser | null> {
  await ensureAccessRoles();
  let user = await prisma.user.findUnique({ where: { id: userId }, include: accessInclude });
  if (!user?.role) return null;
  if (!user.orgId && (await repairSingleOrgLegacyData())) {
    user = await prisma.user.findUnique({ where: { id: userId }, include: accessInclude });
    if (!user?.role) return null;
  }
  const primary = user.role.portal;
  const hats: AccessUser["portal"][] = [primary];
  if (primary === "OFFICE" && user.teacher) hats.push("TEACHER");
  if (user.parent && primary !== "PARENT") hats.push("PARENT");
  if (as && as !== primary && hats.includes(as)) {
    const hatRole = await prisma.role.findUnique({ where: { slug: as }, include: { grants: true } });
    if (hatRole) return { ...toAccess({ ...user, roleId: hatRole.id, role: hatRole }), hats };
  }
  return { ...toAccess(user), hats };
}

function toAccess(user: {
  id: string;
  orgId?: string | null;
  name: string;
  email: string;
  roleId: string;
  role: {
    name: string;
    slug: string;
    portal: AccessUser["portal"];
    isSystem: boolean;
    grants: { permission: string; scope: AccessScope | null }[];
  };
}): AccessUser {
  return {
    id: user.id,
    orgId: user.orgId,
    name: user.name,
    email: user.email,
    role: user.role.slug,
    roleName: user.role.name,
    roleId: user.roleId,
    portal: user.role.portal,
    // "Manage employees" always includes marking their attendance; approving or paying salary includes seeing it.
    permissions: [
      ...user.role.grants.map((g) => g.permission),
      ...(user.role.grants.some((g) => g.permission === "staff.edit") && !user.role.grants.some((g) => g.permission === "staff.attendance")
        ? ["staff.attendance"]
        : []),
      ...(user.role.grants.some((g) => g.permission === "salary.approve" || g.permission === "salary.pay") &&
      !user.role.grants.some((g) => g.permission === "salary.view")
        ? ["salary.view"]
        : []),
    ],
    scopes: Object.fromEntries(
      user.role.grants.map((g) => [g.permission, g.scope ?? scopePolicyFor(g.permission, user.role.portal).defaultScope])
    ),
    isSystemRole: user.role.isSystem,
  };
}

export async function listRoles() {
  await ensureAccessRoles();
  return prisma.role.findMany({
    include: { grants: true, _count: { select: { users: true } } },
    orderBy: [{ isSystem: "desc" }, { name: "asc" }],
  });
}

export function slugFromName(name: string) {
  const base = name
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "_")
    .replace(/^_|_$/g, "")
    .slice(0, 24) || "ROLE";
  return base;
}
