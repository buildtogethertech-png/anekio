import dotenv from "dotenv";
import cors from "cors";
import express from "express";
import { existsSync } from "fs";
import path from "path";
import multer from "multer";
import bcrypt from "bcryptjs";
import { signAppToken, type AppHat } from "../lib/app-jwt";
import {
  AuthFlowError,
  consumeAuthCode,
  requestAuthCode,
  resetPasswordWithLink,
  resetPasswordWithCode,
  createTrialWelcomeResetLink,
} from "../lib/auth-challenges";
import { trialEmailOrigins } from "../lib/trial-email-urls";
import { adminPortalHtml as renderAdminPortal } from "../lib/saas-admin-portal";
import { hasAny, userFromAuthHeader } from "../lib/http-user";
import { userForLogin, usersForLogin } from "../lib/login";
import { verifiedGoogleEmail } from "../lib/mobile-google-auth";
import { serializeUser } from "../lib/http-user";
import { publicNav, navForPortal } from "../lib/nav";
import { recordPayload } from "../lib/api-v1-record";
import { queryFeeRegister } from "../lib/fee-register";
import { homePayload, serializeNotice } from "../lib/api-v1-home";
import { noticesForUser } from "../lib/data";
import { inboxRecipients, inboxThreadDetail, listInboxThreads } from "../lib/inbox";
import { parentDetailsFor, pendingProfileRequests } from "../lib/profile-requests";
import { actOp, runAct } from "../lib/run-act";
import {
  SUPPORT_BLOCKED_OPS,
  SupportSessionError,
  createSupportCode,
  endSupportSession,
  recordSupportWrite,
  redeemSupportCode,
} from "../lib/support-session";
import {
  completePresignedFileUpload,
  handleFileUpload,
  preparePresignedFileUpload,
} from "../lib/handle-upload";
import { presignedReadUrl, readUpload, readUploadDataUrl, resolveUploadPath } from "../lib/uploads";
import { createSchoolFeeOrder, verifySchoolPayment, invoicesFromPeriods } from "../lib/pay";
import { batchDocumentsHtml, findBatchDocuments, findIssuedDocument, identityScanHtml, missingIssuedScanHtml, uploadedIssuedDocumentFile, verificationHtml } from "../lib/document-studio";
import { prisma } from "../lib/prisma";
import { verifyCashfreeWebhook, captureCashfreePayment } from "../lib/cashfree";
import { captureRazorpayPayment, captureRazorpayMonths, verifyWebhookSignature } from "../lib/razorpay";
import { issueDueFeesCore } from "../lib/fee-run";
import { marksheetHtmlForUser } from "../lib/marksheet-html";
import { routineHtmlForUser } from "../lib/timetable-html";
import { runExamCronNotifications } from "../lib/exam-notification-run";
import { ensureAccessRoles, loadAccess } from "../lib/roles";
import { scopePolicyFor } from "../lib/permissions";
import { onboardingSpreadsheetTemplate } from "../lib/onboarding";
import { pastExamTemplate } from "../lib/past-exams";
import { finishOnboardingGoogleAuth } from "../lib/onboarding-google";
import { withPublicRequestOrigin } from "../lib/utils";
import { hasHostnamePrefix, normalizeHostname, schoolSlugFromHostname } from "../lib/host-routing";
import { runWithoutTenant, setTenantOrg } from "../lib/tenant-context";
import { renderInvoicePage, renderPayPage, renderStudentPayPage } from "./pay-html";
import {
  createAdmissionLeadFromWebsite,
  prepareAdmissionFileUpload,
  schoolWebsiteHtml,
} from "../lib/school-website";
import {
  createSaasDemoEnquiry,
  createSaasEnquiry,
  createSaasRazorpayOrder,
  createSaasTrial,
  ExistingTrialSignupError,
  marketingHtml,
  robotsTxt,
  saasRenewalHtml,
  saasCheckoutHtml,
  sitemapXml,
  subscriptionLockForUser,
  subscriptionOverviewForUser,
  trialStartedHtml,
  verifySaasRazorpayPayment,
} from "../lib/anekio-site";
import {
  adminInvoicePrintHtml,
  adminLoginHtml,
  adminPortalHtml,
  createAdminInvoice,
  createAdminOrganisation,
  issueAdminInvoice,
  recordAdminPayment,
  runAdminCrmAction,
  saveSaasEmailConfig,
  saveSaasEmailRule,
  updateAdminOrganisation,
} from "../lib/saas-admin";
import { adminInvoicePdf } from "../lib/saas-invoice-pdf";
import { sendSaasEmailEvent } from "../lib/saas-email";
import { updateSitePricing } from "../lib/saas-pricing";
import { appPlatform, saveAppVersionRules, updateStatusFor } from "../lib/app-version";
import { privacyPolicyHtml } from "../lib/privacy-policy";
import {
  ADMIN_OAUTH_COOKIE,
  ADMIN_SESSION_COOKIE,
  clearCookie,
  cookieValue,
  createAdminSession,
  createGoogleAdminAuth,
  finishGoogleAdminAuth,
  readAdminSession,
  secureRequest,
  verifyLocalAdminLogin,
} from "../lib/saas-admin-auth";

dotenv.config({ path: ".env.local" });
dotenv.config();

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024 } });
const PORT = Number(process.env.PORT || 4000);
// Vercel bundles this entrypoint as CommonJS, where ESM-only import.meta is invalid.
// Both the local API command and Vercel run from the project root.
const serverDir = path.resolve(process.cwd(), "server");
const argvRoot = process.argv[1] ? path.resolve(path.dirname(process.argv[1]), "..") : "";
const appShellRoutes = [
  "/login",
  "/notices",
  "/notifications",
  "/inbox",
  "/more",
  "/people",
  "/onboarding",
  "/admissions",
  "/staff",
  "/school",
  "/timetable",
  "/fees",
  "/exams",
  "/roles",
  "/attendance",
  "/class",
  "/leave",
  "/subjects",
  "/tests",
  "/papers",
  "/path",
  "/letter",
  "/uploads",
  "/profile",
  "/support-login",
];

app.use(
  cors({
    origin: true,
    credentials: true,
    allowedHeaders: ["Authorization", "Content-Type", "X-App-Platform", "X-App-Build"],
  })
);
app.use("/api/pay/webhook", express.raw({ type: "*/*" }));
app.use("/api/razorpay/webhook", express.raw({ type: "*/*" }));
app.use(express.json({ limit: "4mb" }));
app.use(express.urlencoded({ extended: true }));
app.use((_req, _res, next) => runWithoutTenant(() => next()));
app.use((req, _res, next) => withPublicRequestOrigin(requestOrigin(req), next));

/** Public: the mobile app asks whether its build must / should update. */
app.get("/api/v1/app-version", async (req, res) => {
  const platform = appPlatform(req.query.platform) || "android";
  const build = Math.floor(Number(req.query.build) || 0);
  res.setHeader("Cache-Control", "no-store");
  res.json(await updateStatusFor(platform, build));
});

/**
 * Force update, server side: an app below the minimum build gets 426 for every API call (except login-free
 * version checks), so even an old build that skipped the in-app check cannot keep working during an emergency.
 * Requests without the headers (web, older apps, scripts) pass through untouched.
 */
app.use("/api/v1", async (req, res, next) => {
  const platform = appPlatform(req.header("x-app-platform"));
  const build = Math.floor(Number(req.header("x-app-build")) || 0);
  if (!platform || !build || req.path === "/app-version") return next();
  try {
    const status = await updateStatusFor(platform, build);
    if (status.required) {
      res.status(426).json({ error: status.message, code: "update_required", storeUrl: status.storeUrl, minBuild: status.minBuild });
      return;
    }
  } catch {
    // Never block on a failed check.
  }
  next();
});

function sendError(res: express.Response, status: number, error: string) {
  res.status(status).json({ error });
}

function sendUnexpectedError(res: express.Response, error: unknown, fallback = "Something went wrong. Please try again shortly.") {
  console.error("Unexpected API error", error);
  const message = process.env.NODE_ENV === "production" ? fallback : error instanceof Error ? error.message : fallback;
  return sendError(res, 500, message);
}

const PUBLIC_DEMO_RATE_WINDOW_MS = 10 * 60_000;
const PUBLIC_DEMO_RATE_MAX = 6;
const publicDemoAttempts = new Map<string, number[]>();

function publicDemoRequestKey(req: express.Request) {
  const forwarded = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return forwarded || req.socket.remoteAddress || "unknown";
}

/** A small process-local backstop; the honeypot and delivery idempotency cover the rest. */
function allowPublicDemoRequest(req: express.Request) {
  const now = Date.now();
  const key = publicDemoRequestKey(req);
  const recent = (publicDemoAttempts.get(key) || []).filter((attempt) => attempt > now - PUBLIC_DEMO_RATE_WINDOW_MS);
  if (recent.length >= PUBLIC_DEMO_RATE_MAX) return false;
  recent.push(now);
  publicDemoAttempts.set(key, recent);
  if (publicDemoAttempts.size > 2_000) {
    for (const [candidate, attempts] of publicDemoAttempts) {
      if (!attempts.some((attempt) => attempt > now - PUBLIC_DEMO_RATE_WINDOW_MS)) publicDemoAttempts.delete(candidate);
    }
  }
  return true;
}

function hostName(req: express.Request) {
  return normalizeHostname(String(req.headers["x-forwarded-host"] || req.headers.host || ""));
}

function isAdminHost(req: express.Request) {
  return hasHostnamePrefix(hostName(req), "admin");
}

function adminBase(req: express.Request) {
  return isAdminHost(req) ? "" : "/anekio-admin";
}

function requestOrigin(req: express.Request) {
  const forwardedProto = String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim();
  const protocol = forwardedProto || req.protocol;
  const host = String(req.headers["x-forwarded-host"] || req.headers.host || "localhost:4000").split(",")[0].trim();
  return `${protocol}://${host}`;
}

function adminSecureCookie(req: express.Request) {
  return secureRequest({
    protocol: req.protocol,
    forwardedProto: String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim(),
  });
}

function adminSession(req: express.Request) {
  try {
    return readAdminSession(req.headers.cookie);
  } catch {
    return null;
  }
}

function adminCsrf(req: express.Request, csrf: string) {
  const provided = String(req.body?.csrf || "");
  return provided.length === csrf.length && provided === csrf;
}

function isAppHost(req: express.Request) {
  return hasHostnamePrefix(hostName(req), "app");
}

function isConnectHost(req: express.Request) {
  return hasHostnamePrefix(hostName(req), "connect");
}

function schoolSlugHost(req: express.Request) {
  return schoolSlugFromHostname(hostName(req));
}

async function requireUser(req: express.Request, res: express.Response) {
  const user = await userFromAuthHeader(req.headers.authorization);
  if (!user) {
    sendError(res, 401, "Sign in again.");
    return null;
  }
  setTenantOrg(user.orgId);
  return user;
}

async function requireActiveSubscription(userId: string, res: express.Response) {
  const lock = await subscriptionLockForUser(userId);
  if (!lock) return true;
  sendError(res, 402, "Renew Anekio to continue.");
  return false;
}

type LoginRow = NonNullable<Awaited<ReturnType<typeof userForLogin>>>;
type LoginChoice = {
  id: string;
  name: string;
  schoolName: string;
  portal: string;
  roleName: string;
};

/** Builds the signed-in session. `as: "PARENT"` opens a staff member's parent hat (same login). */
async function loginSession(
  userId: string,
  opts: { as?: AppHat; override?: { token: string; support: { adminEmail: string; expiresAt: string } } } = {}
) {
  const access = await loadAccess(userId, opts.as);
  if (!access) throw new Error("Sign in again.");
  const hat = opts.as && access.portal === opts.as && (access.hats || []).length > 1 ? opts.as : undefined;
  return {
    token: opts.override?.token ?? signAppToken(userId, hat),
    user: { ...serializeUser(access), ...(opts.override ? { support: opts.override.support } : {}) },
    nav: navForPortal(access.portal, access.permissions).map(publicNav),
  };
}

/** One choice per login, plus a "Parent" choice for staff who are also parents. Choice ids: `<userId>` or `<userId>:parent`. */
function loginChoices(rows: LoginRow[]): LoginChoice[] {
  return rows.flatMap((row) => {
    const base = {
      id: row.id,
      name: row.name,
      schoolName: row.org?.schoolName || "Anekio School",
      portal: row.role.portal,
      roleName: row.role.name,
    };
    if (!row.parent || row.role.portal === "PARENT") return [base];
    const kids = row.parent.students.map((student) => student.name).filter(Boolean);
    return [base, { ...base, id: `${row.id}:parent`, portal: "PARENT", roleName: kids.length ? `Parent of ${kids.join(", ")}` : "Parent" }];
  });
}

function parseAccountChoice(value: string) {
  const [id, hat] = value.split(":");
  return { id: id || "", as: hat === "parent" ? ("PARENT" as const) : undefined };
}

function sendAuthFlowError(res: express.Response, error: unknown) {
  if (error instanceof AuthFlowError) return sendError(res, error.status, error.message);
  console.error("Authentication flow failed", error);
  return sendError(res, 500, "Secure sign-in is temporarily unavailable.");
}

app.post("/api/v1/login", async (req, res) => {
  const login = String(req.body?.login || "").trim();
  const password = String(req.body?.password || "");
  const accountId = String(req.body?.accountId || "").trim();
  if (!login || !password) return sendError(res, 400, "Email or number, and password.");
  await ensureAccessRoles();
  const rows = await usersForLogin(login);
  const choice = parseAccountChoice(accountId);
  const picked = choice.id ? rows.find((row) => row.id === choice.id) : null;
  const candidates = picked ? [picked] : rows;
  const valid: LoginRow[] = [];
  for (const row of candidates) {
    if (row.role && await bcrypt.compare(password, row.password)) valid.push(row);
  }
  if (!valid.length) return sendError(res, 401, "Those credentials are not in this school.");
  const choices = loginChoices(valid);
  if (!accountId && choices.length > 1) {
    return res.json({ accountChoices: choices });
  }
  res.json(await loginSession(valid[0].id, { as: choice.as }));
});

app.post("/api/v1/login/google", async (req, res) => {
  try {
    const idToken = String(req.body?.idToken || "").trim();
    const accountId = String(req.body?.accountId || "").trim();
    if (!idToken) return sendError(res, 400, "Google sign-in could not be completed.");
    await ensureAccessRoles();
    const email = await verifiedGoogleEmail(idToken);
    const rows = await usersForLogin(email);
    if (!rows.length) {
      return sendError(res, 403, "This Google account is not linked to an Anekio school account. Use your registered email or contact your school administrator.");
    }
    const choice = parseAccountChoice(accountId);
    const picked = choice.id ? rows.find((row) => row.id === choice.id) : null;
    if (accountId && !picked) return sendError(res, 403, "That school account is not linked to this Google email.");
    const choices = loginChoices(rows);
    if (!accountId && choices.length > 1) return res.json({ accountChoices: choices });
    res.json(await loginSession((picked || rows[0]).id, { as: choice.as }));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Google sign-in could not be completed.";
    console.error("Google sign-in failed", error);
    sendError(res, 401, message);
  }
});

app.post("/api/v1/login/otp/request", async (req, res) => {
  try {
    res.json(await requestAuthCode(String(req.body?.login || ""), "LOGIN"));
  } catch (error) {
    sendAuthFlowError(res, error);
  }
});

app.post("/api/v1/login/otp/verify", async (req, res) => {
  try {
    await ensureAccessRoles();
    const userId = await consumeAuthCode(String(req.body?.login || ""), "LOGIN", String(req.body?.code || ""));
    const row = await prisma.user.findUnique({
      where: { id: userId },
      include: { role: { include: { grants: true } }, org: { select: { schoolName: true } } },
    });
    if (!row?.role) return sendError(res, 401, "That code is invalid or has expired.");
    // OTP signs in with the main role; a teacher who is also a parent switches hats from the profile menu.
    res.json(await loginSession(row.id));
  } catch (error) {
    sendAuthFlowError(res, error);
  }
});

app.post("/api/v1/login/password/request", async (req, res) => {
  try {
    res.json(await requestAuthCode(String(req.body?.login || ""), "PASSWORD_RESET"));
  } catch (error) {
    sendAuthFlowError(res, error);
  }
});

app.post("/api/v1/login/password/reset", async (req, res) => {
  try {
    res.json(
      await resetPasswordWithCode(
        String(req.body?.login || ""),
        String(req.body?.code || ""),
        String(req.body?.password || "")
      )
    );
  } catch (error) {
    sendAuthFlowError(res, error);
  }
});

app.post("/api/v1/login/password/link/reset", async (req, res) => {
  try {
    res.json(await resetPasswordWithLink(String(req.body?.token || ""), String(req.body?.password || "")));
  } catch (error) {
    sendAuthFlowError(res, error);
  }
});

app.post("/api/v1/login/support/redeem", async (req, res) => {
  try {
    await ensureAccessRoles();
    const redeemed = await redeemSupportCode(String(req.body?.code || ""));
    const row = await prisma.user.findUnique({
      where: { id: redeemed.userId },
      include: { role: { include: { grants: true } }, org: { select: { schoolName: true } } },
    });
    if (!row?.role) return sendError(res, 401, "That support code is invalid, used, or expired.");
    res.json(await loginSession(row.id, { override: { token: redeemed.token, support: { adminEmail: redeemed.support.adminEmail, expiresAt: redeemed.support.expiresAt } } }));
  } catch (error) {
    if (error instanceof SupportSessionError) return sendError(res, error.status, error.message);
    sendUnexpectedError(res, error, "Support login is unavailable.");
  }
});

/** Switch between a staff login's own role and its parent / teacher hat, without signing out. */
app.post("/api/v1/session/switch", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (user.support) return sendError(res, 403, "Switching is not available in a support session.");
  const wanted = String(req.body?.as || "").toUpperCase();
  const as = wanted === "PARENT" || wanted === "TEACHER" ? (wanted as "PARENT" | "TEACHER") : undefined;
  if (as && !(user.hats || []).includes(as)) {
    return sendError(res, 403, as === "PARENT" ? "This login is not a parent." : "This login is not set up to teach.");
  }
  try {
    res.json(await loginSession(user.id, { as }));
  } catch (error) {
    sendUnexpectedError(res, error, "Could not switch.");
  }
});

app.post("/api/v1/support/end", async (req, res) => {
  const user = await userFromAuthHeader(req.headers.authorization);
  if (user?.support) await endSupportSession(user.support.sessionId);
  res.json({ ok: true });
});

app.get("/api/v1/me", async (req, res) => {
  await ensureAccessRoles();
  const user = await requireUser(req, res);
  if (!user) return;
  res.json({
    user: serializeUser(user),
    nav: navForPortal(user.portal, user.permissions).map(publicNav),
  });
});

app.get("/api/v1/marksheet", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  try {
    const html = await marksheetHtmlForUser(user, {
      seriesId: String(req.query.seriesId || ""),
      examId: String(req.query.examId || ""),
      studentId: String(req.query.studentId || ""),
    });
    res.type("html").send(html);
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Marksheet unavailable");
  }
});

app.get("/api/v1/timetable/print", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    const html = await routineHtmlForUser(user, {
      classId: String(req.query.classId || ""),
      studentId: String(req.query.studentId || ""),
    });
    res.type("html").send(html);
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Routine unavailable");
  }
});

app.get("/api/v1/fee-register", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  if (!hasAny(user, ["fees.view"])) return sendError(res, 403, "No access.");
  try {
    res.json(await queryFeeRegister(user, (req.query || {}) as Record<string, unknown>));
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Fee register unavailable");
  }
});

app.get("/api/v1/record", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const allowed = hasAny(user, [
    "children.view",
    "self.view",
    "attendance.mark",
    "desk.view",
    "people.view",
    "onboarding.manage",
    "staff.view",
    "fees.view",
    "exams.view",
    "school.edit",
    "roles.manage",
    "timetable.view",
    "exams.teach",
    "papers.upload",
    "timetable.teach",
  ]);
  if (!allowed) return sendError(res, 403, "No access.");
  try {
    res.json(await recordPayload(user, typeof req.query.childId === "string" ? req.query.childId : null));
  } catch (e) {
    sendUnexpectedError(res, e);
  }
});

app.get("/api/v1/onboarding/template", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    const kind = String(req.query.kind || "");
    const sampleData = ["1", "true", "yes"].includes(String(req.query.sampleData || "").toLowerCase());
    const template = await onboardingSpreadsheetTemplate(user, kind, { sampleData });
    res.setHeader("Content-Type", template.contentType);
    res.setHeader("Content-Disposition", `attachment; filename="${template.fileName}"`);
    res.setHeader("Cache-Control", "no-store");
    res.send(template.buffer);
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Template unavailable");
  }
});

app.get("/api/v1/exams/past-template", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    const template = await pastExamTemplate(user, {
      sessionId: String(req.query.sessionId || ""),
      classId: String(req.query.classId || ""),
      planItemId: String(req.query.planItemId || ""),
      maxMarks: String(req.query.maxMarks || ""),
    });
    res.setHeader("Content-Type", template.contentType);
    res.setHeader("Content-Disposition", `attachment; filename="${template.fileName}"`);
    res.setHeader("Cache-Control", "no-store");
    res.send(template.buffer);
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Sheet unavailable");
  }
});

app.get("/api/v1/onboarding/google/callback", async (req, res) => {
  try {
    const auth = await finishOnboardingGoogleAuth({
      state: String(req.query.state || ""),
      code: String(req.query.code || ""),
    });
    const url = new URL(auth.returnTo);
    url.searchParams.set("googleSheets", "connected");
    url.searchParams.set("googleKind", auth.kind);
    res.redirect(url.toString());
  } catch (e) {
    const fallback = new URL(`${requestOrigin(req)}/onboarding`);
    fallback.searchParams.set("googleSheets", "error");
    fallback.searchParams.set("message", e instanceof Error ? e.message : "Google Sheets connection failed.");
    res.redirect(fallback.toString());
  }
});

app.get("/api/v1/subscription/invoices/:id/print", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const overview = await subscriptionOverviewForUser(user.id);
  if (!overview?.invoices.some((invoice) => invoice.id === String(req.params.id || ""))) {
    return sendError(res, 404, "Invoice not found.");
  }
  const pdf = await adminInvoicePdf(String(req.params.id || ""));
  if (!pdf) return sendError(res, 404, "Invoice not found.");
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="${pdf.filename}"`);
  res.send(pdf.buffer);
});

app.get("/api/v1/home", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  res.json(await homePayload(user, typeof req.query.childId === "string" ? req.query.childId : null));
});

app.get("/api/v1/notices", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  const notices = await noticesForUser(user);
  if (!hasAny(user, ["notices.view", "children.view", "attendance.mark", "self.view"])) {
    const exactNotices = notices.filter((notice) => notice.recipients.length > 0);
    if (!exactNotices.length) return sendError(res, 403, "No access.");
    return res.json({ notices: exactNotices.map(serializeNotice) });
  }
  res.json({ notices: notices.map(serializeNotice) });
});

app.get("/api/v1/inbox", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json({ threads: await listInboxThreads(user) });
  } catch (error) {
    sendError(res, 400, error instanceof Error ? error.message : "Could not load inbox.");
  }
});

app.get("/api/v1/parent-details", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json(await parentDetailsFor(user, String(req.query.studentId || "")));
  } catch (error) {
    sendError(res, 400, error instanceof Error ? error.message : "Could not load details.");
  }
});

app.get("/api/v1/profile-requests", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json({ requests: await pendingProfileRequests(user) });
  } catch (error) {
    sendError(res, 400, error instanceof Error ? error.message : "Could not load parent updates.");
  }
});

app.get("/api/v1/inbox/recipients", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json(await inboxRecipients(user, String(req.query.studentId || "")));
  } catch (error) {
    sendError(res, 400, error instanceof Error ? error.message : "Could not load recipients.");
  }
});

app.get("/api/v1/inbox/:id", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json(await inboxThreadDetail(user, req.params.id));
  } catch (error) {
    sendError(res, 404, error instanceof Error ? error.message : "Conversation not found.");
  }
});

app.post("/api/v1/act", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  const body = (req.body || {}) as Record<string, unknown>;
  if (user.support) {
    const op = actOp(body);
    // Never touch the real user's device registration; quietly succeed so app flows keep working.
    if (op === "savePushToken") return res.json({ ok: true });
    if (SUPPORT_BLOCKED_OPS.has(op)) return sendError(res, 403, "Not available during a support login.");
  }
  try {
    const result = await runAct(user, body);
    if (user.support) await recordSupportWrite(user, actOp(body));
    res.json(result);
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not save.");
  }
});

app.post("/api/v1/late-timing", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json(await runAct(user, { ...(req.body || {}), op: "saveSchoolPayrollRules" }));
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not save.");
  }
});

app.post("/api/files", upload.single("file"), async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  const file = req.file;
  if (!file?.buffer) return sendError(res, 400, "File required");
  try {
    const result = await handleFileUpload(
      user,
      { buf: file.buffer, name: file.originalname, mime: file.mimetype },
      (req.body || {}) as Record<string, string>
    );
    res.json({ ok: true, ...result });
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Upload failed");
  }
});

app.post("/api/files/presign", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  const body = (req.body || {}) as Record<string, unknown>;
  const fields = body.fields && typeof body.fields === "object"
    ? body.fields as Record<string, unknown>
    : {};
  try {
    res.json(await preparePresignedFileUpload(
      user,
      {
        name: String(body.fileName || ""),
        mime: String(body.fileType || "application/octet-stream"),
        size: Number(body.fileSize || 0),
      },
      fields
    ));
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not prepare upload");
  }
});

app.post("/api/files/complete", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    res.json({ ok: true, ...await completePresignedFileUpload(user, String(req.body?.completionToken || "")) });
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not complete upload");
  }
});

app.post("/api/files/view-url", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const rel = String(req.body?.path || "").replace(/^\/+/, "");
  try {
    resolveUploadPath(rel);
    const directUrl = await presignedReadUrl(rel);
    res.json({ url: directUrl || await readUploadDataUrl(rel) });
  } catch (e) {
    sendError(res, 404, e instanceof Error ? e.message : "File not found");
  }
});

app.get("/api/files/*rel", async (req, res) => {
  const param = req.params.rel;
  const rel = decodeURIComponent(Array.isArray(param) ? param.join("/") : String(param || ""));
  try {
    const { publicFile } = resolveUploadPath(rel);
    if (!publicFile) {
      const user = await userFromAuthHeader(req.headers.authorization);
      if (!user) return sendError(res, 401, "Unauthorized");
    }
    const directUrl = await presignedReadUrl(rel);
    if (directUrl) return res.redirect(302, directUrl);
    const { buf, type } = await readUpload(rel);
    res.setHeader("Content-Type", type);
    res.send(buf);
  } catch {
    sendError(res, 404, "Not found");
  }
});

app.get("/school/:slug", async (req, res) => {
  const html = await schoolWebsiteHtml(String(req.params.slug || ""), { preview: req.query.preview === "1" });
  if (!html) return sendError(res, 404, "School website not found");
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(html);
});

app.post("/school/:slug/upload/presign", async (req, res) => {
  try {
    res.json(await prepareAdmissionFileUpload(String(req.params.slug || ""), (req.body || {}) as Record<string, unknown>));
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not prepare admission upload.");
  }
});

app.post("/school/:slug/lead", upload.any(), async (req, res) => {
  try {
    await createAdmissionLeadFromWebsite(String(req.params.slug || ""), req.body || {}, Array.isArray(req.files) ? req.files : []);
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Enquiry sent</title><style>body{margin:0;background:#f5f8fc;font-family:Arial,sans-serif;color:#102a43}.card{max-width:520px;margin:12vh auto;background:white;border:1px solid #d9e2ec;border-radius:20px;padding:28px;text-align:center}a{display:inline-block;margin-top:16px;color:#1d4ed8;font-weight:700}</style></head><body><main class="card"><h1>Enquiry sent</h1><p>Thank you. The school office will contact you soon.</p><a href="/school/${encodeURIComponent(String(req.params.slug || ""))}">Back to school website</a></main></body></html>`);
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not send enquiry.");
  }
});

async function renderAdminPage(req: express.Request, res: express.Response) {
  const basePath = adminBase(req);
  const session = adminSession(req);
  if (!session) {
    return res.type("html").send(adminLoginHtml(basePath, String(req.query.authError || "")));
  }
  return res.type("html").send(
    await adminPortalHtml({
      basePath,
      session,
      view: typeof req.query.view === "string" ? req.query.view : "dashboard",
      id: typeof req.query.id === "string" ? req.query.id : "",
      q: typeof req.query.q === "string" ? req.query.q.trim() : "",
      tab: typeof req.query.tab === "string" ? req.query.tab : "",
      userQ: typeof req.query.uq === "string" ? req.query.uq : "",
      flash: typeof req.query.saved === "string" ? req.query.saved : "",
      error: typeof req.query.error === "string" ? req.query.error : "",
    })
  );
}

function adminRouteRequest(req: express.Request) {
  return isAdminHost(req) || req.path === "/anekio-admin" || req.path.startsWith("/anekio-admin/");
}

function requireAdminAction(req: express.Request, res: express.Response) {
  const session = adminSession(req);
  const basePath = adminBase(req);
  if (!session) {
    res.redirect(303, basePath || "/");
    return null;
  }
  if (!adminCsrf(req, session.csrf)) {
    res.status(403).type("html").send(adminLoginHtml(basePath, "The form expired. Refresh the page and try again."));
    return null;
  }
  return session;
}

app.post(["/login", "/anekio-admin/login"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const basePath = adminBase(req);
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  if (!verifyLocalAdminLogin(email, password)) {
    return res.redirect(303, `${basePath || "/"}?authError=${encodeURIComponent("Those local test credentials are not authorised.")}`);
  }
  res.setHeader(
    "Set-Cookie",
    cookieValue(ADMIN_SESSION_COOKIE, createAdminSession(email), {
      secure: adminSecureCookie(req),
      maxAgeSeconds: 60 * 60 * 12,
    })
  );
  res.redirect(303, basePath || "/");
});

app.get(["/auth/google", "/anekio-admin/auth/google"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  try {
    const basePath = adminBase(req);
    const redirectUri = `${requestOrigin(req)}${basePath}/auth/google/callback`;
    const auth = createGoogleAdminAuth(redirectUri, basePath);
    res.setHeader("Set-Cookie", cookieValue(ADMIN_OAUTH_COOKIE, auth.cookie, { secure: adminSecureCookie(req), maxAgeSeconds: 600 }));
    res.redirect(302, auth.url);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Sign-in is unavailable.";
    res.redirect(302, `${adminBase(req) || "/"}?authError=${encodeURIComponent(message)}`);
  }
});

app.get(["/auth/google/callback", "/anekio-admin/auth/google/callback"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const basePath = adminBase(req);
  try {
    const profile = await finishGoogleAdminAuth({
      cookieHeader: req.headers.cookie,
      state: String(req.query.state || ""),
      code: String(req.query.code || ""),
    });
    res.setHeader("Set-Cookie", [
      cookieValue(ADMIN_SESSION_COOKIE, createAdminSession(profile.email), { secure: adminSecureCookie(req), maxAgeSeconds: 60 * 60 * 12 }),
      clearCookie(ADMIN_OAUTH_COOKIE, adminSecureCookie(req)),
    ]);
    res.redirect(303, profile.basePath || "/");
  } catch (error) {
    const message = error instanceof Error ? error.message : "Sign-in could not be completed.";
    res.setHeader("Set-Cookie", clearCookie(ADMIN_OAUTH_COOKIE, adminSecureCookie(req)));
    res.redirect(303, `${basePath || "/"}?authError=${encodeURIComponent(message)}`);
  }
});

app.get(["/logout", "/anekio-admin/logout"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  res.setHeader("Set-Cookie", clearCookie(ADMIN_SESSION_COOKIE, adminSecureCookie(req)));
  res.redirect(303, adminBase(req) || "/");
});

app.get(["/favicon.png", "/favicon.ico"], (req, res) => {
  const dist = webRoot();
  const favicon = [
    dist ? path.join(dist, req.path.endsWith(".ico") ? "favicon.ico" : "favicon.png") : "",
    path.resolve(serverDir, "..", "mobile", "assets", "anekio-option-a-square.png"),
  ].find((candidate) => candidate && existsSync(candidate));
  if (!favicon) return res.sendStatus(404);
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.type(favicon.endsWith(".ico") ? "image/x-icon" : "image/png").sendFile(favicon);
});

app.get("/", async (req, res, next) => {
  if (isAdminHost(req)) return renderAdminPage(req, res);
  if (isAppHost(req) || isConnectHost(req)) return next();
  const slug = schoolSlugHost(req);
  if (slug) {
    const html = await schoolWebsiteHtml(slug);
    if (html) return res.type("html").send(html);
    return sendError(res, 404, "School website not found");
  }
  res.type("html").send(await marketingHtml());
});

app.get(["/features", "/pricing"], async (_req, res) => {
  res.type("html").send(await marketingHtml());
});

app.get("/privacy", (_req, res) => {
  res.setHeader("Cache-Control", "public, max-age=3600");
  res.type("html").send(privacyPolicyHtml());
});

app.get("/reset-password", (req, res) => {
  const token = typeof req.query.token === "string" ? req.query.token : "";
  res.type("html").send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Reset password | Anekio</title><style>body{margin:0;background:#f4f7fb;color:#0f172a;font:16px Inter,Arial,sans-serif}.card{max-width:400px;margin:10vh auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:32px;box-shadow:0 12px 32px #10203312}h1{margin:0 0 8px}p{color:#64748b;line-height:1.5}input,button{box-sizing:border-box;width:100%;padding:13px;border-radius:9px;font:inherit}input{border:1px solid #cbd5e1;margin:16px 0}button{border:0;background:#1d4ed8;color:#fff;font-weight:700;cursor:pointer}#message{margin-top:14px;font-size:14px}</style></head><body><main class="card"><strong>anekio</strong><h1>Reset your password</h1><p>Choose a new password for your account.</p><form id="form"><input id="password" type="password" minlength="8" required placeholder="New password (at least 8 characters)"><input id="confirm" type="password" minlength="8" required placeholder="Confirm new password"><button>Reset password</button></form><div id="message" role="status"></div></main><script>const token=${JSON.stringify(token)};const form=document.querySelector('#form');const message=document.querySelector('#message');form.addEventListener('submit',async(e)=>{e.preventDefault();const password=document.querySelector('#password').value;const confirm=document.querySelector('#confirm').value;if(password!==confirm){message.textContent='Passwords do not match.';return}const r=await fetch('/api/v1/login/password/link/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,password})});const d=await r.json().catch(()=>({}));message.textContent=r.ok?'Password reset. You can now sign in.':(d.error||'That reset link is invalid or has expired.');if(r.ok)form.hidden=true});</script></body></html>`);
});

app.get("/robots.txt", (_req, res) => {
  res.type("text/plain").send(robotsTxt());
});

app.get("/sitemap.xml", (_req, res) => {
  res.type("application/xml").send(sitemapXml());
});

app.get("/anekio/enquiry", async (_req, res) => {
  res.type("html").send(await marketingHtml());
});

app.post("/anekio/enquiry", async (req, res) => {
  try {
    await createSaasEnquiry(req.body || {});
    res.type("html").send(await marketingHtml("Thanks — enquiry saved. We will follow up with the school owner."));
  } catch (e) {
    res.status(400).type("html").send(await marketingHtml(e instanceof Error ? e.message : "Could not save enquiry."));
  }
});

app.get("/anekio-admin", renderAdminPage);

app.post("/orgs", async (req, res, next) => {
  if (!isAdminHost(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  try {
    const org = await createAdminOrganisation(req.body || {}, session.email);
    res.redirect(303, `/?view=org&id=${encodeURIComponent(org.id)}&saved=${encodeURIComponent("Organisation added.")}`);
  } catch (e) {
    res.redirect(303, `/?view=new-org&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not add organisation.")}`);
  }
});

app.post("/orgs/:id", async (req, res, next) => {
  if (!isAdminHost(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  try {
    const org = await updateAdminOrganisation(String(req.params.id || ""), req.body || {}, session.email);
    res.redirect(303, `/?view=org&id=${encodeURIComponent(org.id)}&saved=${encodeURIComponent("Organisation updated.")}`);
  } catch (e) {
    res.redirect(303, `/?view=edit-org&id=${encodeURIComponent(String(req.params.id || ""))}&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not update organisation.")}`);
  }
});

app.post("/anekio-admin/orgs", async (req, res) => {
  const session = requireAdminAction(req, res);
  if (!session) return;
  try {
    const org = await createAdminOrganisation(req.body || {}, session.email);
    res.redirect(303, `/anekio-admin?view=org&id=${encodeURIComponent(org.id)}&saved=${encodeURIComponent("Organisation added.")}`);
  } catch (e) {
    res.redirect(303, `/anekio-admin?view=new-org&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not add organisation.")}`);
  }
});

app.post("/anekio-admin/orgs/:id", async (req, res) => {
  const session = requireAdminAction(req, res);
  if (!session) return;
  try {
    const org = await updateAdminOrganisation(String(req.params.id || ""), req.body || {}, session.email);
    res.redirect(303, `/anekio-admin?view=org&id=${encodeURIComponent(org.id)}&saved=${encodeURIComponent("Organisation updated.")}`);
  } catch (e) {
    res.redirect(303, `/anekio-admin?view=edit-org&id=${encodeURIComponent(String(req.params.id || ""))}&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not update organisation.")}`);
  }
});

app.post(["/orgs/:id/support-code", "/anekio-admin/orgs/:id/support-code"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  const orgId = String(req.params.id || "");
  try {
    const created = await createSupportCode({
      adminEmail: session.email,
      orgId,
      userId: String(req.body?.userId || ""),
      reason: String(req.body?.reason || ""),
    });
    const appOrigin = trialEmailOrigins(hostName(req)).app;
    const plain = created.code.replace("-", "");
    res.setHeader("Cache-Control", "no-store");
    res.type("html").send(
      await renderAdminPortal({
        basePath,
        session,
        view: "org",
        id: orgId,
        tab: "users",
        flash: `Support code created for ${created.user.name}.`,
        supportCode: {
          code: created.code,
          userName: created.user.name,
          roleName: created.user.role.name,
          codeExpiresAt: created.codeExpiresAt,
          webUrl: `${appOrigin}/support-login?code=${plain}`,
          appUrl: `anekio://support-login?code=${plain}`,
        },
      })
    );
  } catch (e) {
    const message = e instanceof Error ? e.message : "Could not create a support login.";
    res.redirect(303, `${basePath || "/"}?view=org&id=${encodeURIComponent(orgId)}&tab=users&error=${encodeURIComponent(message)}`);
  }
});

app.post(["/orgs/:id/invoices", "/anekio-admin/orgs/:id/invoices"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    const invoice = await createAdminInvoice(String(req.params.id || ""), req.body || {}, session.email);
    res.redirect(303, `${basePath || "/"}?view=invoice&id=${encodeURIComponent(invoice.id)}&saved=${encodeURIComponent("Invoice draft created.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=new-invoice&id=${encodeURIComponent(String(req.params.id || ""))}&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not create invoice.")}`);
  }
});

app.post(["/invoices/:id/issue", "/anekio-admin/invoices/:id/issue"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    const invoice = await issueAdminInvoice(String(req.params.id || ""), session.email);
    res.redirect(303, `${basePath || "/"}?view=invoice&id=${encodeURIComponent(invoice.id)}&saved=${encodeURIComponent("Invoice issued.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=invoice&id=${encodeURIComponent(String(req.params.id || ""))}&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not issue invoice.")}`);
  }
});

app.post(["/invoices/:id/payments", "/anekio-admin/invoices/:id/payments"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    await recordAdminPayment(String(req.params.id || ""), req.body || {}, session.email);
    res.redirect(303, `${basePath || "/"}?view=invoice&id=${encodeURIComponent(String(req.params.id || ""))}&saved=${encodeURIComponent("Payment recorded.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=invoice&id=${encodeURIComponent(String(req.params.id || ""))}&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not record payment.")}`);
  }
});

app.get(["/invoices/:id/print", "/anekio-admin/invoices/:id/print"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  if (!adminSession(req)) return res.redirect(303, adminBase(req) || "/");
  const html = await adminInvoicePrintHtml(String(req.params.id || ""));
  if (!html) return res.status(404).send("Invoice not found");
  res.type("html").send(html);
});

app.post(["/settings/pricing", "/anekio-admin/settings/pricing"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    await updateSitePricing(req.body || {}, session.email);
    res.redirect(303, `${basePath || "/"}?view=pricing&saved=${encodeURIComponent("Landing page pricing published.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=pricing&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not save pricing.")}`);
  }
});

app.post(["/settings/app-version", "/anekio-admin/settings/app-version"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    await saveAppVersionRules(req.body || {}, session.email);
    res.redirect(303, `${basePath || "/"}?view=app-version&saved=${encodeURIComponent("App update rules saved. Apps pick them up within a minute.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=app-version&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not save app update rules.")}`);
  }
});

app.post(["/settings/email", "/anekio-admin/settings/email"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    await saveSaasEmailConfig(req.body || {}, session.email);
    res.redirect(303, `${basePath || "/"}?view=email&saved=${encodeURIComponent("Email delivery profile saved.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=email&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not save email delivery settings.")}`);
  }
});

app.post(["/settings/email/rules", "/anekio-admin/settings/email/rules"], async (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    await saveSaasEmailRule(req.body || {}, session.email);
    res.redirect(303, `${basePath || "/"}?view=email&saved=${encodeURIComponent("Email template saved.")}`);
  } catch (e) {
    res.redirect(303, `${basePath || "/"}?view=email&error=${encodeURIComponent(e instanceof Error ? e.message : "Could not save email template.")}`);
  }
});

function crmBack(req: express.Request, basePath: string, extra: Record<string, string> = {}) {
  const referer = String(req.get("referer") || "");
  if (referer) {
    try {
      const url = new URL(referer);
      if (url.hostname === String(req.headers.host || "").split(":")[0] || url.hostname.endsWith("localhost")) {
        for (const [key, value] of Object.entries(extra)) url.searchParams.set(key, value);
        return `${url.pathname}${url.search}`;
      }
    } catch {
      /* ignore */
    }
  }
  const url = new URL(basePath || "/", "http://admin.local");
  for (const [key, value] of Object.entries(extra)) url.searchParams.set(key, value);
  return `${url.pathname}${url.search}`;
}

async function handleCrm(req: express.Request, res: express.Response, kind: string, id: string, extraInput: Record<string, unknown> = {}) {
  const session = requireAdminAction(req, res);
  if (!session) return;
  const basePath = adminBase(req);
  try {
    await runAdminCrmAction(kind, id, { ...(req.body || {}), ...extraInput }, session.email);
    res.redirect(303, crmBack(req, basePath, { saved: "Saved." }));
  } catch (e) {
    res.redirect(303, crmBack(req, basePath, { error: e instanceof Error ? e.message : "Could not save." }));
  }
}

app.post(["/crm/support", "/anekio-admin/crm/support"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "support", String(req.body?.orgId || ""));
});
app.post(["/crm/demos/:id/complete", "/anekio-admin/crm/demos/:id/complete"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "demo-complete", String(req.params.id || ""));
});
app.post(["/crm/followups/:id/done", "/anekio-admin/crm/followups/:id/done"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "followup-done", String(req.params.id || ""));
});
app.post(["/crm/:id/stage", "/anekio-admin/crm/:id/stage"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "stage", String(req.params.id || ""));
});
app.post(["/crm/:id/notes", "/anekio-admin/crm/:id/notes"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "notes", String(req.params.id || ""));
});
app.post(["/crm/:id/demos", "/anekio-admin/crm/:id/demos"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "demos", String(req.params.id || ""));
});
app.post(["/crm/:id/followups", "/anekio-admin/crm/:id/followups"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "followups", String(req.params.id || ""));
});
app.post(["/crm/:id/onboarding/start", "/anekio-admin/crm/:id/onboarding/start"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "onboarding-start", String(req.params.id || ""));
});
app.post(["/crm/:id/onboarding/:key", "/anekio-admin/crm/:id/onboarding/:key"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "onboarding-toggle", String(req.params.id || ""), { key: String(req.params.key || "") });
});
app.post(["/crm/:id/plan", "/anekio-admin/crm/:id/plan"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "plan", String(req.params.id || ""));
});
app.post(["/crm/:id/cancel", "/anekio-admin/crm/:id/cancel"], (req, res, next) => {
  if (!adminRouteRequest(req)) return next();
  return handleCrm(req, res, "cancel", String(req.params.id || ""));
});

app.post("/api/saas/enquiry", async (req, res) => {
  try {
    // The public form has an off-screen honeypot. A successful no-op prevents
    // bots from learning that they were detected and keeps them out of CRM/mail.
    if (String(req.body?.website || "").trim()) return res.json({ ok: true });
    if (!allowPublicDemoRequest(req)) return sendError(res, 429, "Please wait a few minutes before booking another demo.");

    const booking = await createSaasDemoEnquiry(req.body || {});
    if (!booking) return res.json({ ok: true });

    const leadUrl = `${requestOrigin(req).replace(/\/$/, "")}/anekio-admin?view=lead&id=${encodeURIComponent(booking.org.id)}`;
    try {
      await sendSaasEmailEvent({
        event: "DEMO_BOOKED",
        orgId: booking.org.id,
        idempotencyKey: `demo:${booking.org.id}:${booking.demo.scheduledAt.toISOString()}`,
        host: hostName(req),
        variables: {
          schoolName: booking.org.schoolName,
          ownerName: booking.org.ownerName,
          ownerEmail: booking.org.ownerEmail,
          ownerPhone: booking.org.ownerPhone,
          city: booking.org.city,
          topic: booking.topic,
          demoSlotLabel: booking.slotLabel,
          demoScheduledAt: booking.demo.scheduledAt.toISOString(),
          leadUrl,
        },
      });
    } catch (error) {
      // Saving a legitimate lead must not turn into a failed booking if a mail
      // provider or mail table is temporarily unavailable. Delivery records
      // retain configuration/provider failures when the email layer is reached.
      console.error("Demo email delivery setup failed", error instanceof Error ? error.message : error);
    }
    res.json({ ok: true, org: booking.org, demo: booking.demo });
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not save enquiry.");
  }
});

app.post("/api/saas/trial", async (req, res) => {
  try {
    const { login, loginUrl, ...org } = await createSaasTrial(req.body || {});
    const leadUrl = `${requestOrigin(req).replace(/\/$/, "")}/anekio-admin?view=lead&id=${encodeURIComponent(org.id)}`;
    try {
      const emailOrigins = trialEmailOrigins(hostName(req));
      const passwordResetUrl = await createTrialWelcomeResetLink(org.id, org.ownerEmail, emailOrigins.site);
      await sendSaasEmailEvent({
        event: "TRIAL_STARTED",
        orgId: org.id,
        idempotencyKey: `trial:${org.id}`,
        host: hostName(req),
        variables: {
          schoolName: org.schoolName,
          ownerName: org.ownerName,
          ownerEmail: org.ownerEmail,
          ownerPhone: org.ownerPhone,
          city: org.city,
          trialDays: String(org.plan.match(/\d+/)?.[0] || "7"),
          loginUrl: `${emailOrigins.app}${loginUrl || "/login"}`,
          leadUrl,
        },
        customerVariables: { passwordResetUrl },
      });
    } catch (error) {
      console.error("Trial onboarding email delivery setup failed", error instanceof Error ? error.message : error);
    }
    if (!String(req.headers.accept || "").includes("application/json")) {
      return res.type("html").send(trialStartedHtml({ ...org, login, loginUrl }));
    }
    res.json({ ok: true, org, login, loginUrl });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Could not start trial.";
    const status = e instanceof ExistingTrialSignupError ? e.status : 400;
    if (!String(req.headers.accept || "").includes("application/json")) {
      return res.status(status).type("html").send(await marketingHtml(message));
    }
    res.status(status).json({
      error: message,
      loginUrl: e instanceof ExistingTrialSignupError ? e.loginUrl : undefined,
      conflictFields: e instanceof ExistingTrialSignupError ? e.conflictFields : undefined,
    });
  }
});

app.get("/anekio/renew", async (req, res) => {
  res.type("html").send(await saasRenewalHtml({ orgId: req.query.org, contact: req.query.contact }));
});

async function createSaasPaymentOrder(req: express.Request, res: express.Response) {
  try {
    const order = await createSaasRazorpayOrder(req.body || {});
    const wantsHtml = !String(req.headers.accept || "").includes("application/json");
    if (wantsHtml) {
      return res.type("html").send(saasCheckoutHtml(order));
    }
    res.json({ ok: true, order });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Could not create payment order.";
    if (!String(req.headers.accept || "").includes("application/json")) {
      return res.status(400).type("html").send(await marketingHtml(message));
    }
    sendError(res, 400, message);
  }
}

app.post("/api/saas/payment/order", createSaasPaymentOrder);
app.post("/api/saas/razorpay/order", createSaasPaymentOrder);

async function verifySaasPaymentOrder(req: express.Request, res: express.Response) {
  try {
    res.json(await verifySaasRazorpayPayment(req.body || {}));
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Could not verify payment.");
  }
}

app.post("/api/saas/payment/verify", verifySaasPaymentOrder);
app.post("/api/saas/razorpay/verify", verifySaasPaymentOrder);

app.post("/api/pay/order", async (req, res) => {
  const { token, studentToken, invoiceIds } = req.body || {};
  if (!token && !studentToken) return sendError(res, 400, "Token required");
  try {
    const origin = `${req.protocol}://${req.get("host")}`;
    const order = await createSchoolFeeOrder(token || studentToken || "", origin, {
      studentToken,
      invoiceIds,
    });
    res.json(order);
  } catch (err) {
    sendError(res, 400, err instanceof Error ? err.message : "Could not create order");
  }
});

app.post("/api/pay/verify", async (req, res) => {
  const body = req.body || {};
  if (!body.token && !body.studentToken) return sendError(res, 400, "Incomplete payment");
  try {
    await verifySchoolPayment(body);
    res.json({ ok: true });
  } catch (err) {
    sendError(res, 400, err instanceof Error ? err.message : "Could not record payment");
  }
});

app.post("/api/pay/webhook", async (req, res) => {
  const provider = String(req.query.provider || "razorpay");
  const raw = Buffer.isBuffer(req.body) ? req.body.toString("utf8") : typeof req.body === "string" ? req.body : JSON.stringify(req.body || {});
  try {
    if (provider === "cashfree") {
      const signature = String(req.headers["x-webhook-signature"] || "");
      const timestamp = String(req.headers["x-webhook-timestamp"] || "");
      if (!(await verifyCashfreeWebhook(raw, timestamp, signature))) return sendError(res, 400, "Bad signature");
      const event = JSON.parse(raw) as {
        type?: string;
        data?: { order?: { order_id?: string; order_tags?: { token?: string; invoiceId?: string } } };
      };
      if (event.type && !event.type.toLowerCase().includes("success") && event.type !== "PAYMENT_SUCCESS_WEBHOOK") {
        return res.json({ ok: true });
      }
      const orderId = event.data?.order?.order_id || "";
      const invoiceId =
        event.data?.order?.order_tags?.invoiceId ||
        (
          await prisma.feeInvoice.findUnique({
            where: { shareToken: event.data?.order?.order_tags?.token || "" },
            select: { id: true },
          })
        )?.id;
      if (orderId && invoiceId) await captureCashfreePayment({ invoiceId, orderId });
      return res.json({ ok: true });
    }
    const signature = String(req.headers["x-razorpay-signature"] || "");
    if (!(await verifyWebhookSignature(raw, signature))) return sendError(res, 400, "Bad signature");
    const event = JSON.parse(raw) as {
      event?: string;
      payload?: {
        payment?: {
          entity?: {
            id?: string;
            order_id?: string;
            notes?: { token?: string; invoiceId?: string; studentToken?: string; periods?: string; invoiceIds?: string };
          };
        };
      };
    };
    if (event.event !== "payment.captured") return res.json({ ok: true });
    const entity = event.payload?.payment?.entity;
    const paymentId = entity?.id || "";
    if (entity?.notes?.studentToken && (entity?.notes?.invoiceIds || entity?.notes?.periods)) {
      const invoiceIds = String(entity.notes.invoiceIds || "")
        .split(",")
        .map((id) => id.trim())
        .filter(Boolean);
      const months = invoiceIds.length
        ? await prisma.feeInvoice.findMany({ where: { id: { in: invoiceIds } }, select: { id: true } })
        : await invoicesFromPeriods(entity.notes.studentToken, entity.notes.periods || "");
      if (paymentId && months.length) {
        await captureRazorpayMonths({
          invoiceIds: months.map((m) => m.id),
          paymentId,
          orderId: entity?.order_id,
        });
      }
      return res.json({ ok: true });
    }
    const invoiceId =
      entity?.notes?.invoiceId ||
      (
        await prisma.feeInvoice.findUnique({
          where: { shareToken: entity?.notes?.token || "" },
          select: { id: true },
        })
      )?.id;
    if (!paymentId || !invoiceId) return res.json({ ok: true });
    await captureRazorpayPayment({ invoiceId, paymentId, orderId: entity?.order_id });
    res.json({ ok: true });
  } catch (e) {
    sendError(res, 400, e instanceof Error ? e.message : "Webhook failed");
  }
});

app.post("/api/razorpay/order", (req, res, next) => {
  req.url = "/api/pay/order";
  app._router.handle(req, res, next);
});
app.post("/api/razorpay/verify", (req, res, next) => {
  req.url = "/api/pay/verify";
  app._router.handle(req, res, next);
});
app.post("/api/razorpay/webhook", (req, res, next) => {
  req.url = "/api/pay/webhook";
  app._router.handle(req, res, next);
});

app.all("/api/cron/fees", async (req, res) => {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.authorization !== `Bearer ${secret}`) {
    return res.status(401).send("Unauthorized");
  }
  res.json(await issueDueFeesCore(new Date()));
});

app.all("/api/cron/leave", async (req, res) => {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.authorization !== `Bearer ${secret}`) {
    return res.status(401).send("Unauthorized");
  }
  const { runLeaveCredits } = await import("../lib/leave-balance");
  res.json(await runLeaveCredits(new Date()));
});

app.get("/api/v1/leave-balances", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  const { can } = await import("../lib/permissions");
  if (!can(user, "staff.edit")) return sendError(res, 403, "No access.");
  try {
    const { allLeaveBalances } = await import("../lib/leave-balance");
    res.json(await allLeaveBalances());
  } catch (error) {
    sendError(res, 400, error instanceof Error ? error.message : "Could not load balances.");
  }
});

app.get("/api/v1/leave-ledger", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!(await requireActiveSubscription(user.id, res))) return;
  try {
    let teacherId = String(req.query.teacherId || "");
    let staffId = String(req.query.staffId || "");
    if (req.query.me === "1") {
      const own = await prisma.teacher.findUnique({ where: { userId: user.id }, select: { id: true, teachingOnly: true } });
      teacherId = own && !own.teachingOnly ? own.id : "";
      staffId = teacherId ? "" : (await prisma.staffMember.findUnique({ where: { userId: user.id }, select: { id: true } }))?.id || "";
      if (!teacherId && !staffId) return res.json({ balances: [], ledger: [] });
    }
    const { can } = await import("../lib/permissions");
    const self =
      (teacherId && (await prisma.teacher.findFirst({ where: { id: teacherId, userId: user.id }, select: { id: true } }))) ||
      (staffId && (await prisma.staffMember.findFirst({ where: { id: staffId, userId: user.id }, select: { id: true } })));
    if (!self && !can(user, "staff.view") && !can(user, "staff.edit")) return sendError(res, 403, "No access.");
    const { leaveBalancesFor, leaveLedgerFor } = await import("../lib/leave-balance");
    const person = teacherId ? { teacherId } : { staffId };
    res.json({ balances: await leaveBalancesFor(person), ledger: await leaveLedgerFor(person) });
  } catch (error) {
    sendError(res, 400, error instanceof Error ? error.message : "Could not load leave.");
  }
});

app.post("/api/cron/exams", async (req, res) => {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.authorization !== `Bearer ${secret}`) {
    return res.status(401).send("Unauthorized");
  }
  res.json(await runExamCronNotifications(new Date()));
});

app.get("/pay/s/:token", async (req, res) => {
  const html = await renderStudentPayPage(
    req.params.token,
    String(req.query.m || ""),
    String(req.query.ids || ""),
    req.query.embed === "1",
    req.query.paid === "1"
  );
  if (!html) return res.status(404).send("Not found");
  res.type("html").send(html);
});

app.get("/pay/:token/return", async (req, res) => {
  const orderId = String(req.query.order_id || req.query.orderid || "");
  const provider = String(req.query.provider || "").toUpperCase();
  if (orderId && (provider === "CASHFREE" || provider === "BILLDESK")) {
    try {
      await verifySchoolPayment({ token: req.params.token, provider, orderId });
    } catch {
      // show latest invoice either way
    }
  }
  res.redirect(`/pay/${req.params.token}`);
});

app.get("/pay/:token", async (req, res) => {
  const html = await renderPayPage(req.params.token, req.query.embed === "1", req.query.paid === "1");
  if (!html) return res.status(404).send("Not found");
  res.type("html").send(html);
});

app.get("/i/:token", async (req, res) => {
  const html = await renderInvoicePage(req.params.token);
  if (!html) return res.status(404).send("Not found");
  res.type("html").send(html);
});

app.get("/verify/:token", async (req, res) => {
  const row = await findIssuedDocument(req.params.token);
  if (!row) {
    return res.status(404).type("html").send(missingIssuedScanHtml());
  }
  res.type("html").send(verificationHtml(row));
});

app.get("/attendance/scan/:token", async (req, res) => {
  const row = await findIssuedDocument(req.params.token);
  if (!row || row.type !== "STUDENT_ID") return res.status(404).type("html").send(missingIssuedScanHtml());
  res.type("html").send(identityScanHtml(row, "STUDENT_ID"));
});

app.get("/staff/scan/:token", async (req, res) => {
  const row = await findIssuedDocument(req.params.token);
  if (!row || row.type !== "EMPLOYEE_ID") return res.status(404).type("html").send(missingIssuedScanHtml());
  res.type("html").send(identityScanHtml(row, "EMPLOYEE_ID"));
});

app.get("/documents/:token/file", async (req, res) => {
  const row = await findIssuedDocument(req.params.token);
  if (!row || row.status === "REVOKED") return res.status(404).send("Document unavailable");
  const { filePath, fileName } = uploadedIssuedDocumentFile(row);
  if (!filePath) return res.status(404).send("Uploaded file unavailable");
  try {
    const { buf, type } = await readUpload(filePath);
    res.setHeader("Content-Type", type);
    if (fileName) res.setHeader("Content-Disposition", `inline; filename="${fileName.replace(/["\r\n]/g, "")}"`);
    res.send(buf);
  } catch {
    res.status(404).send("Uploaded file unavailable");
  }
});

app.get("/documents/:token", async (req, res) => {
  const row = await findIssuedDocument(req.params.token);
  if (!row || row.status === "REVOKED") return res.status(404).send("Document unavailable");
  res.type("html").send(row.renderedHtml);
});

app.get("/document-batches/:batchId", async (req, res) => {
  const rows = await findBatchDocuments(req.params.batchId);
  if (!rows.length) return res.status(404).send("Document batch unavailable");
  res.type("html").send(batchDocumentsHtml(rows));
});

app.get("/health", (_req, res) => res.json({ ok: true }));

const demoDir = [argvRoot, path.resolve(serverDir, ".."), process.cwd()]
  .filter(Boolean)
  .map((root) => path.join(root, "public", "demo"))
  .find((dir) => existsSync(dir));
if (demoDir) {
  app.use("/demo", express.static(demoDir));
}

function resolveWebDir() {
  return [argvRoot, path.resolve(serverDir, ".."), process.cwd()]
    .filter(Boolean)
    .map((root) => path.join(root, "mobile", "dist"))
    .find((dir) => existsSync(path.join(dir, "index.html")));
}

let webDir = resolveWebDir();
function webRoot() {
  return webDir || (webDir = resolveWebDir()) || "";
}
function sendAppShell(_req: express.Request, res: express.Response, next: express.NextFunction) {
  const dir = webRoot();
  if (!dir) return next();
  res.setHeader("Cache-Control", "no-store");
  res.sendFile(path.join(dir, "index.html"));
}
// Web app caching. Hashed bundles never change, so cache them for a year. The HTML shell and every
// un-hashed file must be re-checked on each load, or browsers keep an old index.html that points at
// bundles a new deploy removed (the "needs a hard refresh after deploy" bug). ETags are off because on
// serverless hosts files share a build mtime, so an unchanged size could wrongly answer 304.
const HASHED_ASSET = /[.-][0-9a-f]{16,}\.(?:js|css|map|wasm|png|jpe?g|webp|svg|ttf|otf|woff2?)$/i;
const webStatic = new Map<string, express.RequestHandler>();
function staticFor(dir: string) {
  let handler = webStatic.get(dir);
  if (!handler) {
    handler = express.static(dir, {
      index: false,
      etag: false,
      lastModified: false,
      setHeaders(res, filePath) {
        if (filePath.endsWith(".html")) res.setHeader("Cache-Control", "no-store");
        else if (HASHED_ASSET.test(filePath) || filePath.includes(`${path.sep}_expo${path.sep}static${path.sep}`)) {
          res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        } else res.setHeader("Cache-Control", "no-cache");
      },
    });
    webStatic.set(dir, handler);
  }
  return handler;
}
app.use((req, res, next) => {
  const dir = webRoot();
  if (!dir) return next();
  staticFor(dir)(req, res, next);
});
app.get(["/", ...appShellRoutes], sendAppShell);
app.use((req, res, next) => {
  if (req.method !== "GET" && req.method !== "HEAD") return next();
  if (path.extname(req.path)) return next();
  if (
    req.path.startsWith("/api") ||
    req.path.startsWith("/pay") ||
    req.path.startsWith("/i") ||
    req.path.startsWith("/verify") ||
    req.path.startsWith("/attendance/scan") ||
    req.path.startsWith("/staff/scan") ||
    req.path.startsWith("/documents") ||
    req.path.startsWith("/document-batches") ||
    req.path.startsWith("/demo") ||
    req.path === "/health"
  ) {
    return next();
  }
  sendAppShell(req, res, next);
});

app.use((error: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (res.headersSent) return next(error);
  if (req.path.startsWith("/api/")) return sendUnexpectedError(res, error);
  console.error("Unexpected web error", error);
  res.status(500).type("html").send("<h1>Something went wrong</h1><p>Please wait a moment and try again.</p>");
});

export default app;

if (!process.env.VERCEL && (process.env.NODE_ENV !== "test" || process.env.TEST_SERVER_LISTEN === "1")) {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Anekio API on http://localhost:${PORT}`);
  });
}

